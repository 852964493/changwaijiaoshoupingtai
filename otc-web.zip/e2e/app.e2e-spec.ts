import { LegionOtcWebPage } from './app.po';

describe('otc-web App', () => {
  let page: LegionOtcWebPage;

  beforeEach(() => {
    page = new LegionOtcWebPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
