export const environment = {
  production: true,
  loadingText: "正在加载,请稍候...",
  server: "http://otc-test.zhuwenda.com:8000/",
  // server: "http://legiontest.zhuwenda.com:12042/",
  // server: "http://legion-net.viphk.ngrok.org/",
  // server: "http://192.168.8.194:7027/",
  timeout: 60 * 1000,
  // sidebar  or   topnav
  layout: "topnav",
  pageSize: 10
};
