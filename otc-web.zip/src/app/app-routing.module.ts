import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LayoutComponent} from './pages/global/layout/layout.component';

import {AuthGuardService} from './services/auth-guard.service';


const routes: Routes = [
  {
    path: '',
    loadChildren: './pages/login/login.module#LoginModule'
  },
  {
    path: 'pages',
    component: LayoutComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: 'demo',
        loadChildren: './pages/demo/demo.module#DemoModule'
      },
      {
        path: 'consoler',
        loadChildren: './pages/consoler/consoler.module#ConsolerModule'
      },
      {
        path: 'bondDistribution',
        loadChildren: './pages/bond-distribution/bond-distribution.module#BondDistributionModule'
      },
      {
        path: 'newStock',
        loadChildren: './pages/new-stock/new-stock.module#NewStockModule'
      },
      {
        path: 'fundRedeem',
        loadChildren: './pages/fund-redeem/fund-redeem.module#FundRedeemModule'
      },
      {
        path: 'addressBook',
        loadChildren: './pages/address-book/address-book.module#AddressBookModule'
      },
      {
        path: 'interbank',
        loadChildren: './pages/interbank/interbank.module#InterbankModule'
      }
      , {
        path: 'deposit',
        loadChildren: './pages/deposit/deposit.module#DepositModule'
      }
      , {
        path: 'transferInstruction',
        loadChildren: './pages/transfer-instruction/transfer-instruction.module#TransferInstructionModule'
      }, {
        path: 'fundFavorite',
        loadChildren: './pages/fund-favorite/fund-favorite.module#FundFavoriteModule'
      }
    ]
  },
  // { path: '**', component: NoFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
