import {Pipe, PipeTransform} from '@angular/core';
import * as moment from "moment";

/**
 * 基于MomentJs的日期格式化管道
 * 具体格式化用法参考：http://momentjs.com/docs/
 */
@Pipe({
  name: 'moment'
})
export class MomentPipe implements PipeTransform {

  transform(value: any, format: string = 'YYYY-MM-DD'): any {
    return (value != null) ? moment(value + '').format(format) : '';
  }

}
