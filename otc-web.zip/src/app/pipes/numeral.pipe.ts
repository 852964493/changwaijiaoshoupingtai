import {Pipe, PipeTransform} from '@angular/core';
@Pipe({
  name: 'numeral'
})
export class NumeralPipe implements PipeTransform {
  /**
   * 对指定文字、数字进行数字格式化
   * @param value 目标源
   * @param format 格式化格式，具体可以查看文档http://numeraljs.com
   * @param positive 是否启用正数 '+' 号表示，默认false，不启用
   * @param emptyStrWhenZero 目标源的值为0时，是否返回空字符串，默认false，不启用
   * @param enableFormatNull 当目标源的值为null时，是否允许进行格式化，默认false，不允许
   * @return 格式化后的数字字符串
   */
  transform(value: any,
            format: string = '0,0.00',
            positive: boolean = false,
            emptyStrWhenZero: boolean = false,
            enableFormatNull: boolean = false): string {
    if (value == null && !enableFormatNull) {
      return "";
    }
    if (emptyStrWhenZero && (parseFloat(value) === 0)) {
      return "";
    }
    return window['numeral'](value).format(positive ? '+' + format : format);
  }

}
