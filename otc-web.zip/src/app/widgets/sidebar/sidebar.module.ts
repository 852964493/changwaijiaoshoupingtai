import { NgModule, ModuleWithProviders } from "@angular/core";
import { AppSidebarComponent } from "app/widgets/sidebar";
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [CommonModule],
    declarations: [AppSidebarComponent],
    exports: [AppSidebarComponent]
})
export class AppSideBarModule {
    public static forRoot(): ModuleWithProviders {
        return { ngModule: AppSideBarModule };
    }
}