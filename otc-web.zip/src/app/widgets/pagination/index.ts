/**
 * Created by chenjt on 2017/6/13.
 */
export {AppPaginationModule} from "./pagination.module";
export {
  AppPaginationComponent,
  PaginationModel,
  DEFAULT_PAGINATION_CONFIG,
  DEFAULT_PAGINATION_CLASS_CONFIG
} from "./pagination.component";
