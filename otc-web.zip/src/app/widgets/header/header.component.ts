import { Component, OnInit, Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class AppHeaderComponent implements OnInit {

	@Input() public layoutMode: String = "";

	@Input() public links: Array<any> = [];

	@Input() public currentUrl: String = "";

	@Input() public nav;

	constructor(
		public router: Router
	) {
	}

	ngOnInit() {
	}

}
