import { NgModule, ModuleWithProviders } from "@angular/core";
import { AppHeaderComponent } from "app/widgets/header";
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [CommonModule],
    declarations: [AppHeaderComponent],
    exports: [AppHeaderComponent]
})
export class AppHeaderModule {
    public static forRoot(): ModuleWithProviders {
        return { ngModule: AppHeaderModule };
    }
}