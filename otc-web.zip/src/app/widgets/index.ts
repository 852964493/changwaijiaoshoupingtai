import { ModuleWithProviders, NgModule } from "@angular/core";
import { AppPaginationModule } from "app/widgets/pagination";
import { AppSideBarModule } from "app/widgets/sidebar/sidebar.module";
import { AppHeaderModule } from "app/widgets/header/header.module";
import { AppFooterModule } from "app/widgets/footer/footer.module";
import { AppBreadcrumbModule } from "app/widgets/breadcrumb/breadcrumb.module";

const MODULES = [AppPaginationModule, AppSideBarModule,
    AppHeaderModule, AppFooterModule, AppBreadcrumbModule];

@NgModule({
    imports: [
        AppPaginationModule.forRoot(), AppSideBarModule.forRoot(),
        AppHeaderModule.forRoot(), AppFooterModule.forRoot(), AppBreadcrumbModule.forRoot()],
    exports: MODULES
})
export class AppWidgetsRootModule {
}

@NgModule({
    exports: MODULES
})
export class AppWidgetsModule {
    public static forRoot(): ModuleWithProviders {
        return { ngModule: AppWidgetsRootModule };
    }
}