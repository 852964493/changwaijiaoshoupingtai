import { NgModule, ModuleWithProviders } from "@angular/core";
import { AppFooterComponent } from "./footer.component";
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [CommonModule],
    declarations: [AppFooterComponent],
    exports: [AppFooterComponent]
})
export class AppFooterModule {
    public static forRoot(): ModuleWithProviders {
        return { ngModule: AppFooterModule };
    }
}