import { NgModule, ModuleWithProviders } from "@angular/core";
import { AppBreadcrumbComponent } from "./breadcrumb.component";
import { CommonModule } from "@angular/common";

@NgModule({
    imports: [CommonModule],
    declarations: [AppBreadcrumbComponent],
    exports: [AppBreadcrumbComponent]
})
export class AppBreadcrumbModule {
    public static forRoot(): ModuleWithProviders {
        return { ngModule: AppBreadcrumbModule };
    }
}