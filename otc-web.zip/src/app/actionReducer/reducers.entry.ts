/**
 * Created by chenjt on 2017/6/29.
 */

import {interbankToTransferModuleReducer} from "./interbank-to-transfer/interbank-to-transfer.reducer";
/**
 * ngrx 数据状态调度统一管理入口
 * @type {{interbankToTransferModule: string}}
 */
export const RX_ACTION_REDUCERS = {
  interbankToTransferModuleReducer: interbankToTransferModuleReducer
};
