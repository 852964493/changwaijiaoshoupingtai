/**
 * Created by chenjt on 2017/6/29.
 */

import {Action} from '@ngrx/store';

export const QUERY = 'QUERY';

export interface InterbankToTransferExchangeDataModel {
  transferInstructionIds: string[];
  [propName: string]: any;
}

/**
 * 银行间模块到划款指令管理模块的数据交互调度者
 * @param action
 */
export function interbankToTransferModuleReducer(state: InterbankToTransferExchangeDataModel = {transferInstructionIds: []}, action: Action) {
  switch (action.type) {
    case 'QUERY':
      return state = action.payload;
    default:
      return state = action.payload;
  }
};
