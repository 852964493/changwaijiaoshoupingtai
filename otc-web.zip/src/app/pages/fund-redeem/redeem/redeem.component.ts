import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
@Component({
	selector: 'fund-redeem-redeem',
	templateUrl: './redeem.component.html',
	styleUrls: ['./redeem.component.scss']
})
export class RedeemComponent implements OnInit {
	private $ = window['$'];

	constructor() {
	}

	ngOnInit() {
	}

	toggleModal(id) {
		var formatedId = "#" + id;
		this.$(formatedId).modal('toggle');
	}

	// 指令核对确认
	instructAlert() {
		window["swal"]({
			title: "",
			text: "恒生指令信息与申请单信息一致？",
			type: "info",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "确认",
			cancelButtonText: "取消",
			closeOnConfirm: true,
			closeOnCancel: true
		},
			function(isConfirm) {
				if (isConfirm) { // 确认
					//window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
				} else { // 取消
					//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
				}
			});
	}

	// 确认到账
	accountAlert() {
		window["swal"]({
			title: "",
			text: "确认划款已到账吗？",
			type: "info",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "确认",
			cancelButtonText: "取消",
			closeOnConfirm: true,
			closeOnCancel: true
		},
			function(isConfirm) {
				if (isConfirm) { // 确认
					//window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
				} else { // 取消
					//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
				}
			});
	}


	submitXj(id) {
		console.log("############submit");
		this.toggleModal(id);
	}

}
