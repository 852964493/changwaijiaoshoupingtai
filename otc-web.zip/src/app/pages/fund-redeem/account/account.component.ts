import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
@Component({
	selector: 'fund-redeem-account',
	templateUrl: './account.component.html',
	styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {
	private $ = window['$'];

	constructor() {
	}

	ngOnInit() {
	}

	toggleModal(id){
		var formatedId = "#" + id;
		this.$(formatedId).modal('toggle');
	}
	
	submitXj(id) {
		console.log("############submit");
		this.toggleModal(id);
	}

}
