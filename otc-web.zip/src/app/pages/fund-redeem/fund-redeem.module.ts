import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FundRedeemRoutingModule } from './fund-redeem-routing.module';
import { RedeemComponent } from './redeem/redeem.component';
import { AccountComponent } from './account/account.component';

import {FormsModule} from "@angular/forms";

@NgModule({
	imports: [
		CommonModule,
		FundRedeemRoutingModule,
		FormsModule
	],
	declarations: [RedeemComponent,AccountComponent]
})
export class FundRedeemModule { }
