import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {FormsModule} from '@angular/forms';
import {HttpClientService} from '../../../services/http-client.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public user = {
    username: "",
    password: ""
  };

  /**
   * 用户代码的正确性状态
   */
    // TODO
  public passwordIncorrectStatus: boolean = true;

  constructor(public httpClient: HttpClientService,
              public router: Router) {
  }

  ngOnInit() {
    window['$']('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  }

  login() {
    // TODO
    const isCanLoegin: boolean = this.passwordValidate(this.user.password, 'Legion01');
    if (!isCanLoegin) {
      this.passwordIncorrectStatus = isCanLoegin;
      return ;
    }

    let postBody = this.user;
    console.log(postBody);
    sessionStorage.setItem('username', this.user.username);
    this.router.navigateByUrl("pages");
    // this.httpClient.post('http://120.25.208.147:8168/api/otc/token.do', postBody, {
    // 	isAuthHttp: false
    // }).subscribe(data => {
    // 	// 测试数据
    // 	sessionStorage.setItem('username', this.user.username);
    // 	this.router.navigateByUrl("pages");
    // });
  }

  /**
   * 校验用户密码是否等于指定密码
   * @param {string} password
   * @param {string} targetPassword
   * @returns {boolean}
   */
  // TODO
  public passwordValidate(password: string, targetPassword: string): boolean {
    return (password === targetPassword ? true : false);
  }
}
