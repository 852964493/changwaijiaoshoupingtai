import {Component, OnInit} from '@angular/core';
import {Router, NavigationEnd} from '@angular/router';
import {environment} from '../../../../environments/environment';
import * as _ from 'lodash';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  public sidebarLinks: Array<any> = [];

  public currentUrl: string = "";

  // sidebar  or   topnav
  public layoutMode: String = environment.layout;

  constructor(public router: Router) {
    this.router.events.subscribe((evt: NavigationEnd) => {
      this.currentUrl = evt.url;
    });
    if (this.layoutMode == 'topnav') {
      window["$"]("body").removeClass();
      window["$"]("body").addClass("hold-transition skin-blue layout-top-nav login-page");
    }
  }

  nav(item, subItem) {
    var currentItem = item;
    if (subItem) {
      currentItem = subItem;
    }
    if (!currentItem.sublinks) {
      if (currentItem.external) {
        if (currentItem.target == '_blank') {
          window.open(currentItem.link);
        } else {
          window.location.href = currentItem.link;
        }
        // 打开新连接
      } else {
        this.router.navigate(currentItem.link);
        var breadcrumbList = _.without([item, subItem], null);
        sessionStorage.setItem('breadcrumbList', JSON.stringify(breadcrumbList));
      }
    }
  }

  ngOnInit() {
    // 解决footer浮动问题
    window['$'](window).resize();
    // var demo = {
    // 	'title': 'External Link',
    // 	'icon': 'google',
    // 	'link': ['http://google.com'],
    // 	'external': true,
    // 	'target': '_blank'
    // }
    this.sidebarLinks = [
      {
        'title': '工作台',
        'icon': 'dashboard',
        'link': ['/pages/consoler/entry']
      },
      {
        'title': '银行间',
        'icon': 'bank',
        'sublinks': [
          {
            'title': '银行间',
            'link': ['/pages/interbank']
          },
          {
            'title': '历史交易',
            'link': ['/pages/interbank/history']
          },
          {
            'title': '组合流水',
            'link': ['/pages/interbank/turnover']
          },
          {
            'title': '银行间支付参数配置',
            'link': ['/pages/interbank/fundConfig']
          }
        ]
      },
      {
        'title': '债券分销',
        'icon': 'sitemap',
        'link': ['/pages/bondDistribution/distribution']
      },
      {
        'title': '基金申赎',
        'icon': 'usd',
        'sublinks': [
          {
            'title': '基金申赎',
            'link': ['/pages/fundRedeem/redeem'],
          },
          {
            'title': '基金账户管理',
            'link': ['/pages/fundRedeem/account'],
          }
        ]
      },
      {
        'title': '网下新股',
        'icon': 'cubes',
        'sublinks': [
          // {
          // 	'title': '询价管理',
          // 	'link': ['/pages/newStock/purchase'],
          // },
          {
            'title': '网下新股申购',
            'link': ['/pages/newStock/purchase'],
          },
          {
            'title': '新股上市管理',
            'link': ['/pages/newStock/listed'],
          },
          {
            'title': '中签缴款管理',
            'link': ['/pages/newStock/zq'],
          },
          {
            'title': '自愿锁定期查询',
            'link': ['/pages/newStock/lockQuery'],
          },
          {
            'title': '基金打新管理',
            'link': ['/pages/newStock/dx'],
          },
          {
            'title': '配售对象管理',
            'link': ['/pages/newStock/allotment'],
          },
          {
            'title': '关联方管理',
            'link': ['/pages/newStock/bankRef'],
          }
        ]
      },
      {
        'title': '存款',
        'icon': 'credit-card-alt',
        'sublinks': [
          {
            'title': '存款账户管理',
            'link': ['/pages/deposit/accountManage'],
          },
          {
            'title': '存款协议管理',
            'link': ['/pages/deposit/timeDeposit'],
          }
        ]
      }, {
        'title': '头寸',
        'icon': 'money',
        'sublinks': [
          {
            'title': '头寸管理',
            'link': [''],
          },
          {
            'title': '头寸冻结管理',
            'link': [''],
          }, {
            'title': '临时冻结管理',
            'link': [''],
          }
        ]
      }, {
        'title': '其它业务',
        'icon': 'bars',
        'sublinks': [
          {
            'title': '转托管',
            'link': [''],
          },
          {
            'title': '转托管账户管理',
            'link': [''],
          }, {
            'title': '协议回购',
            'link': [''],
          }, {
            'title': '非担保业务',
            'link': [''],
          }
        ]
      },{
        'title': '划款指令',
        'icon': 'transfer',
        'sublinks': [
          {
            'title': '划款指令管理',
            'link': ['/pages/transferInstruction/transferList'],
          },
          {
            'title': '划款指令配置',
            'link': ['/pages/transferInstruction/transferOption'],
          },
          {
            'title': '收款银行账号管理',
            'link': ['/pages/transferInstruction/bankAccountManage'],
          }
        ]
      },{
        'title': '个人组合',
        'link': ['/pages/fundFavorite/']
      },{
        'title': '系统设置',
        'icon': 'cogs',
        'link': ['']
      },
    ];
  }
}
