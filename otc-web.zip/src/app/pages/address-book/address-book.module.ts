import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddressBookRoutingModule } from './address-book-routing.module';
import { AddressBookComponent } from './address-book.component';

@NgModule({
  imports: [
    CommonModule,
    AddressBookRoutingModule
  ],
  declarations: [AddressBookComponent]
})
export class AddressBookModule { }
