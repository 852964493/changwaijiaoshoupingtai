import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundFavoriteComponent } from './fund-favorite.component';

describe('FundFavoriteComponent', () => {
  let component: FundFavoriteComponent;
  let fixture: ComponentFixture<FundFavoriteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundFavoriteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundFavoriteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
