import { TestBed, inject } from '@angular/core/testing';

import { FundFavoriteService } from './fund-favorite.service';

describe('FundFavoriteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FundFavoriteService]
    });
  });

  it('should ...', inject([FundFavoriteService], (service: FundFavoriteService) => {
    expect(service).toBeTruthy();
  }));
});
