import {Injectable} from '@angular/core';
import {HttpClientService} from "../../services/http-client.service";
import {Observable} from "rxjs/Observable";
import {FundFavoriteDetailModel, FundFavoriteModel} from "./fund-favorite.model";

@Injectable()
export class FundFavoriteService {

  constructor(public http: HttpClientService) {
  }


  /**
   * 查询指定模块下的【个人组合】的分类列表
   * @param {string} model
   * @param {string} userid
   * @param {string | number} page
   * @param {string | number} pageSize
   * @returns {Observable<any>}
   */
  public queryModelFundFavoriteList(model: string, userid: string,
                                    page: string | number = 1,
                                    pageSize: string | number = 20): Observable<any> {
    const reqBody: any = {page, pageSize};
    return this.http.get(`otc/v1/fundfavorite/query/${userid}/${model}`, reqBody);
  }

  /**
   * 根据分类ID查询【个人组合】分类对象信息
   * @param {string} objid
   * @param {string | number} page
   * @param {string | number} pageSize
   * @returns {Observable<any>}
   */
  public queryFundFavorite(objid: string,
                           page: string | number = 1,
                           pageSize: string | number = 20): Observable<any> {
    const reqBody: any = {page, pageSize};
    return this.http.get(`otc/v1/fundfavorite/query/${objid}`, reqBody);
  }

  /**
   * 删除分类ID删除对应的【个人组合】分类数据
   * @param {string} objid
   * @param {string} userid
   * @returns {Observable<any>}
   */
  public deleteFundFavorite(objid: string, userid: string): Observable<any> {
    return this.http.delete(`otc/v1/fundfavorite/delete/${userid}/${objid}`);
  }

  /**
   * 新增【个人组合】分类
   * @param {FundFavoriteModel} data
   * @param {string} userid
   * @returns {Observable<any>}
   */
  public insertFundFavorite(data: FundFavoriteModel, userid: string): Observable<any> {
    return this.http.put(`otc/v1/fundfavorite/insert/${userid}`, data, {
      isAuthHttp: false
    });
  }

  /**
   * 根据数据更新对应的【个人组合】分类
   * @param {FundFavoriteModel} data
   * @param {string} userid
   * @returns {Observable<any>}
   */
  public updateFundFavorite(data: FundFavoriteModel, userid: string): Observable<any> {
    return this.http.put(`otc/v1/fundfavorite/update/${userid}`, data, {
      isAuthHttp: false
    });
  }

  /**
   * 根据用户ID查询出其所有可以查看的权限组合
   * @param {string} userid
   * @param {string | number} page
   * @param {string | number} pageSize
   * @returns {Observable<any>}
   */
  public queryAccessibleFundList(userid: string,
                                 page: string | number = 1,
                                 pageSize: string | number = 20): Observable<any> {
    const reqBody: any = {page, pageSize};
    return this.http.get(`otc/v1/fundfavorite/fundlist/${userid}`, reqBody);
  }

  /**
   * 根据【个人组合】分类的ID，查询出与其相钩稽的基金信息
   * @param {string} objid
   * @param {string | number} page
   * @param {string | number} pageSize
   * @returns {Observable<any>}
   */
  public queryFundFavoriteDetailList(objid: string,
                                     page: string | number = 1,
                                     pageSize: string | number = 20): Observable<any> {
    return this.http.get(`otc/v1/fundfavoritedetail/query/${objid}`, {page, pageSize});
  }

  /**
   * 更新指定ID的【个人组合】分类钩稽的基金列表
   * @param {string} option
   * @param {string} objid
   * @param {Array<any>} data
   * @returns {Observable<any>}
   */
  public updateFundFavoriteDetail(option: string, objid: string, data: Array<FundFavoriteDetailModel>): Observable<any> {
    return this.http.put(`otc/v1/fundfavoritedetail/update/${objid}/${option}`, data, {
      isAuthHttp: false
    });
  }

  /**
   * 删除与指定ID个人组合分类相钩稽的基金列表信息，相当于清空指定ID的【个人组合】分类钩稽的基金列表
   * @param {string} objid
   * @returns {Observable<any>}
   */
  public deleteFundFavoriteDetail(objid: string): Observable<any> {
    return this.http.delete(`otc/v1/fundfavoritedetail/delete/${objid}}`);
  }
}
