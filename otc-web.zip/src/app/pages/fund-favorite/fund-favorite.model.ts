/**
 * 个人组合分类数据模型
 */
export interface FundFavoriteModel {
  objid?: string;
  objname?: string;
  userid?: string;
  model?: string;
  remark?: string;
  stat?: string;
  sort?: string;
  isdefault?: boolean;
  modtime?: string;
}

/**
 * 个人组合分类下基金信息数据模型
 */
export interface FundFavoriteDetailModel {
  fundcode?: string;
  fundname?: string;
  sort?: string;
  remark?: string;
  [propName: string]: any;
}

/**
 * 用户有权访问的基金数据模型
 */
export interface FundModel {
  vc_fund_code?: string;
  vc_fund_name?: string;
  fundcode?: string;
  fundname?: string;
  sort?: string;
  remark?: string;
  [propName: string]: any;
}
