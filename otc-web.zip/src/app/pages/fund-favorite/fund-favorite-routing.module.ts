import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {FundFavoriteComponent} from "./fund-favorite.component";

const routes: Routes = [{
  path: "",
  component: FundFavoriteComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundFavoriteRoutingModule { }
