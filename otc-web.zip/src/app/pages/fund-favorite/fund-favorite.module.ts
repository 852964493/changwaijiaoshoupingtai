import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {FundFavoriteRoutingModule} from './fund-favorite-routing.module';
import {FundFavoriteComponent} from './fund-favorite.component';
import {FundFavoriteService} from "./fund-favorite.service";
import {AppPaginationModule} from "../../widgets/pagination/pagination.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FundFavoriteRoutingModule,
    AppPaginationModule
  ],
  providers: [FundFavoriteService],
  declarations: [FundFavoriteComponent]
})
export class FundFavoriteModule {
}
