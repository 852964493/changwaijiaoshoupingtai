import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DemoDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
