import { TestBed, inject } from '@angular/core/testing';

import { DemoListService } from './list.service';

describe('DemoListService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [DemoListService]
		});
	});

	it('should ...', inject([DemoListService], (service: DemoListService) => {
		expect(service).toBeTruthy();
	}));
});
