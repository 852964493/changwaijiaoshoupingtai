import { Component, OnInit } from '@angular/core';

import { DemoListService } from './list.service';

import * as moment from 'moment';
import * as _ from 'lodash'

@Component({
	selector: 'demo-list',
	templateUrl: './list.component.html',
	styleUrls: ['./list.component.scss'],
	providers: [DemoListService]
})
export class DemoListComponent implements OnInit {

	public list = [];

	constructor(
		private demoListService: DemoListService
	) { }

	ngOnInit() {
		this.demoListService.sayHello().subscribe(data => {
			if(data){
				console.info(data);
				this.list = data;
			}
		});
	}

}
