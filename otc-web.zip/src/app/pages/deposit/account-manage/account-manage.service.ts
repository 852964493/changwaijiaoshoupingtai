import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class AccountManageService{
    constructor(public httpClient: HttpClientService) {

    }

    // 基金信息
    getFundInfoList(){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/FundInfoList?token=2');
    }

    // 获取账户列表
    getAccountInfo(searchInfo){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit?token=2',searchInfo);
    }

    // 查询指定账户
    getAccount(depositid){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/'+depositid+'?token=2');
    }

    // 新增账户
    addAccount(account){
        let postBody:any= {
            vcFundName: account.fundname,
            empid: account.empid,
            vcFundNo: account.fundno,
            vcFundCode: account.fundcode,
            vcAmount: account.amount,
            vcIntRate: account.intrate,
            vcCurrencyName: account.currencyName,
            vcZhmaxpay: account.zhmaxpay,
            vcZhcode: account.zhcode,
            vcZhname: account.zhname,
            vcFullbankkname: account.fullbankkname
        }
        return this.httpClient.post('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit?token=2', postBody);
    }

    // 编辑账户信息
    editAccount(accountlist){
        let postBody= accountlist;
		return this.httpClient.put('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/'+accountlist.lDepositNo+'?token=2', postBody);
    }
    
    // 删除账户
    delAccount(lDepositNo){
        return this.httpClient.delete('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/'+lDepositNo+'?token=2');
    }

    // 文件下载
    downLoadFile(fileId){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/TimeDeposit/download/'+fileId+'?token=2');
    }

    // 基金经理确认
    managerConfirm(lDepositNo){
        return this.httpClient.put('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/confirm/'+lDepositNo+'?token=2');
    }

    // 定期存款存单信息
    getTradeInfo(postBody){
        let vcFundCode=postBody.vcFundCode;
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/ListByFundCode/'+vcFundCode+'?token=2',postBody);
    }

    // 历史交易
    getTradeList(postBody){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/TradeList?token=2',postBody);
    }
}