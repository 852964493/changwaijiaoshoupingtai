import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileUploadModule } from 'ng2-file-upload';
import { DepositRoutingModule } from './deposit-routing.module';
import { AccountManageComponent } from './account-manage/account-manage.component';
import { TimeDepositComponent } from './time-deposit/time-deposit.component';
import {FormsModule} from "@angular/forms";
import { AppPaginationModule } from '../../widgets/pagination/pagination.module';
import { AccountManageService } from "./account-manage/account-manage.service";

@NgModule({
	imports: [
		CommonModule,
		DepositRoutingModule,
		FormsModule,
		AppPaginationModule,
		FileUploadModule
	],
	declarations: [AccountManageComponent,TimeDepositComponent]
})
export class DepositModule { }
