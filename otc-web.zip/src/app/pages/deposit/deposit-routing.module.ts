import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountManageComponent } from './account-manage/account-manage.component';
import { TimeDepositComponent } from './time-deposit/time-deposit.component';

const routes: Routes = [
	{
		path: '',
		redirectTo: 'accountManage',
		pathMatch: 'full'
	},{
		path: "accountManage",
		component: AccountManageComponent
	},{
		path: "timeDeposit",
		component: TimeDepositComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class DepositRoutingModule { }
