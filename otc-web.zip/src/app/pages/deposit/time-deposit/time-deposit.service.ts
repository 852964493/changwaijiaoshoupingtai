import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class AgreementService{
    constructor(private httpClient: HttpClientService) {}

    // 获取提前支取列表
    getAdvenceList(searchInfo){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence?token=2',searchInfo);
    }
    // 指定ID查询提前支取
    getAdvence(searchId){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence/'+searchId+'?token=2');
    }
    // 新增提前支取
    addAdvence(postBody){
        return this.httpClient.post('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence?token=2',postBody);
    }
    // 新增-获取定存信息
	getDepositList(postBody){
        let vcFundCode=postBody.vcFundCode;
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/ListByFundCode/'+vcFundCode+'?token=2',postBody);
    }
    // 基金经理确认
    managerConfirm(lAdvenceNo){
		return this.httpClient.put('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence/confirm/'+lAdvenceNo+'?token=2');
    }
    // 会计核对
    accountingCheck(lAdvenceNo){
        return this.httpClient.put('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence/check/'+lAdvenceNo+'?token=2');
    }
    // 获取定存协议列表
    getAgreeList(){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositAgree/AgreeList?token=2');
    }
    // 查询定存协议信息
    getAgreeInfo(lAgreeNo){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositAgree/'+lAgreeNo+'?token=2');
    }
    // 新增定存协议信息
    addAgreeInfo(postBody){
        return this.httpClient.post('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositAgree?token=2',postBody);
    }
    // 复核定存协议信息
    fhAgreeInfo(postBody){
        return this.httpClient.post('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositAgree?token=2',postBody);
    }
    // 新增定存银行账户配置
    addDepositBankInfo(postBody){
        return this.httpClient.post('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositBank?token=2',postBody);
    }
    // 根据基金代码查询定存银行账户信息
    getBankInfoByFundCode(vcFundCode){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositBank/BankInfoByFundCode/'+vcFundCode+'?token=2');
    }
    // 根据银行ID查询定存银行账户信息
    getBankInfoByBankId(lBankNo){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/DepositBank/BankInfoByBankNo/'+lBankNo+'?token=2');
    }
    // 剩余金额
    getLeftMoney(vcFundCode){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence/LeftMoney/'+vcFundCode+'?token=2');
    }
    // 获取提前支取存单信息列表
    getDepositAdvenceList(vcDepositNo){
        return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDeposit/Advence/ListByDepositNo/'+vcDepositNo+'?token=2');
    }
    // 上传协议文件
    // uploadFile(lAgreeNo){
    //     return this.httpClient.get('http://legiontest.zhuwenda.com:12042/otc/v1/TimeDepost/DepositAgree/InputAgree/'+lAgreeNo+'?token=2');
    // }
}