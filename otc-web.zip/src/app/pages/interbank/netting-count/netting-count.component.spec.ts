import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NettingCountComponent } from './netting-count.component';

describe('NettingCountComponent', () => {
  let component: NettingCountComponent;
  let fixture: ComponentFixture<NettingCountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NettingCountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NettingCountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
