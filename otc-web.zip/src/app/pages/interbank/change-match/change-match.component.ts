import {Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {Util} from "../../../common/util";
import {InterbankService} from "../interbank.service";

/**
 * 银行间-----变更匹配组件
 */
@Component({
  selector: 'interbank-change-match',
  templateUrl: './change-match.component.html',
  styleUrls: ['./change-match.component.scss']
})
export class ChangeMatchComponent implements OnInit {

  /**
   * 上清/中债登待匹配列表数据
   */
  @Input()
  public otcBondTrade: any = {};

  /**
   * O32指令列表数据
   * @type {Array}
   */
  @Input()
  public trdBondTradeList: Array<any> = [];

  /**
   * 质押券列表数据----质押券列表模态框要显示的数据
   * @type {Array}
   */
  public pledgeListData: Array<any> = [];

  /**
   * 已选o32指令唯一表示符
   * @type {string}
   */
  public selectedTrdDateSerialNo = "";

  @Output()
  public save: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild("modal")
  public modal: ElementRef;

  @ViewChild('pledgeListModal')
  public pledgeListModal: ElementRef;

  constructor(public service: InterbankService) {
  }

  ngOnInit() {
  }

  /**
   * 打开变更匹配模态框，并请求对应的o32指令列表数据
   */
  public openModal() {
    return Util.$(this.modal.nativeElement).modal("show");
  }

  /**
   * 关闭变更匹配模态框，并清空组件模态框的数据
   */
  public closeModal() {
    setTimeout(() => {
      this.clearAllData();
    }, 0);
    return Util.$(this.modal.nativeElement).modal("hide");
  }

  /**
   * 打开质押券列表模态框
   * @returns {any}
   */
  public openPledgeListModal() {
    const $pledgeListModal = Util.$(this.pledgeListModal.nativeElement);
    $pledgeListModal.modal('show');
    return $pledgeListModal;
  }

  /**
   * 关闭质押券列表模态框
   * @returns {any}
   */
  public clasePledgeListModal() {
    const $pledgeListModal = Util.$(this.pledgeListModal.nativeElement);
    $pledgeListModal.modal('hide');
    Util.$(this.modal.nativeElement).css({
      "overflow-y": "auto",
      "overflow-x": "auto",
    });
    this.pledgeListData = [];
    return $pledgeListModal;
  }

  /**
   * 获取与指定交易单ID相关的上清所／中债登质押券信息，并打开质押券列表模态框
   * @param tradeId
   */
  public otcOpenPledgeListModal(tradeId: string) {
    this.pledgeListData = [];
    this.service
      .getOtcPledgeInfoDataList(tradeId)
      .subscribe((data) => {
        if (data != null) {
          this.pledgeListData = data;
        }
        this.openPledgeListModal();
      });
  }

  /**
   * 获取与指定交易单ID相关的O32质押券信息，并打开质押券列表模态框
   * @param dateSerialNo
   */
  public o32OpenPledgeListModal(dateSerialNo: string) {
    this.pledgeListData = [];
    this.service
      .getO32PledgeInfoDataList(dateSerialNo)
      .subscribe((data) => {
        if (data != null) {
          this.pledgeListData = data;
        }
        this.openPledgeListModal();
      });
  }

  /**
   * 根据指令列表明细的选择状况设置已选指令唯一标识符
   * @param $event
   * @param selectedTrdDateSerialNo
   */
  public setSelectedTrdDateSerialNo($event, selectedTrdDateSerialNo: string) {
    if ($event.target.checked) {
      this.selectedTrdDateSerialNo = selectedTrdDateSerialNo;
    }
  }

  /**
   * 清空组件模态框的数据
   */
  public clearAllData() {
    this.otcBondTrade = {};
    this.trdBondTradeList = [];
    this.pledgeListData = [];
    this.selectedTrdDateSerialNo = "";
  }

  /**
   * 保存指令配置结果
   */
  public saveDirectiveMatch() {
    const beMatchTradeData = (this.otcBondTrade != null) ? this.otcBondTrade : {};
    this.service
      .updateChangeMatchData(
        beMatchTradeData.orderSerialNo,
        this.selectedTrdDateSerialNo)
      .subscribe((data) => {
        this.closeModal();
        this.save.emit(true);
      });
  }

}
