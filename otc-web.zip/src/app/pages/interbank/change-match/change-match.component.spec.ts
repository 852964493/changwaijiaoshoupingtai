import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeMatchComponent } from './change-match.component';

describe('ChangeMatchComponent', () => {
  let component: ChangeMatchComponent;
  let fixture: ComponentFixture<ChangeMatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeMatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeMatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
