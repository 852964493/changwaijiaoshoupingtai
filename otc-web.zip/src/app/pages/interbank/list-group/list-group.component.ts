import {
  AfterViewInit,
  Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, QueryList, SimpleChanges,
  ViewChildren
} from '@angular/core';
import {IBTListColumnDisplayConfigModel, ListComponent} from "../list/list.component";

/**
 * 银行间银行间债券交易列表展示折叠状态数据模型
 */
export interface ListComponentFoldStatusModel {
  /**
   *资产组合
   */
  fundCode: string;
  /**
   * ListComponent列表组件折叠状态，true表示折叠，false表示展开
   */
  foldStatus: boolean;
}

@Component({
  selector: 'interbank-list-group',
  templateUrl: './list-group.component.html',
  styleUrls: ['./list-group.component.scss']
})
export class ListGroupComponent implements OnInit, OnChanges, AfterViewInit {

  public loading = false;

  /**
   * 列表配置
   * @type {{color: boolean; file: boolean; select: boolean}}
   */
  public listConfig: IBTListColumnDisplayConfigModel = {
    trdFundName: false,
    trdTradeType: false,
    trdProductCode: false,
    trdProductName: false,
    trdSettleBalance: false,
    trdPledgeMatchStatus: false
  };

  @Input()
  public data: Array<any>;

  @Output()
  public uploadFile: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  public removeFile: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  public urgent: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  public getPledgeAllData: EventEmitter<any> = new EventEmitter<any>();

  @ViewChildren(ListComponent)
  public listComponents: QueryList<ListComponent> = new QueryList<ListComponent>();

  @ViewChildren('foldIcon')
  public foldIcons: QueryList<ElementRef>;

  constructor() {
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    setTimeout(() => {
      this.resetFixedTableLayout();
    }, 0);
  }

  ngAfterViewInit(): void {
    this.resetFixedTableLayout();
  }

  /**
   * 动态生成ListGroupComponent分组视图列表组件的子组件ListComponent
   */
  public dynamicCreateListComponents() {

  }

  /**
   * 将所有明细组件修改为打开显示状态
   */
  public toggleAllListOpen(): void {
    this.listComponents.map(list => list.toggleOpen());
    setTimeout(() => {
      this.resetFixedTableLayout();
    }, 0);
  }

  /**
   * 将所有明细组件修改为隐藏关闭状态
   */
  public toggleAllListClose(): void {
    this.listComponents.map(list => list.toggleClose());
  }

  /**
   * 根据指定索引值，将其对应的明细组件修改为打开显示状态
   * @param index 索引值
   */
  public toggleListOpenByIndex(index: number): void {
    this.listComponents.find((item, pos) => {
      return pos === index;
    }).toggleOpen();
  }

  /**
   * 根据指定索引值，将其对应的明细组件修改为隐藏关闭状态
   * @param index 索引值
   */
  public toggleListCloseByIndex(index: number): void {
    this.listComponents.find((item, pos) => {
      return pos === index;
    }).toggleClose();
  }

  /**
   * 根据指定索引值，将其对应的明细组件修改状态
   * @param index 索引值
   */
  public toggleListByIndex(index: number): void {
    const targetListComponent: ListComponent = this.listComponents.find((item, pos) => {
      return pos === index;
    })
    setTimeout(() => {
      targetListComponent.resetFixedTableLayout();
    }, 0);
    targetListComponent.toggleFold();
  }

  /**
   * 获取明细组件已经被勾选的数据
   * @returns {Array<any>}
   */
  public getSelectedDatas(): Array<any> {
    const result = [];
    this.listComponents.forEach((item) => {
      const data = item.getSelectedDatas();
      if (data.length > 0) {
        result.push(data);
      }
    });
    return result;
  }

  /**
   * 获取当前银行间银行间债券交易列表展示折叠状态数据模型集合
   * @param {string|string[]}fundCode
   * @returns {Array<ListComponentFoldStatusModel>}
   */
  public getListComponentFoldStatusModuleList(fundCode?: string | string[]): Array<ListComponentFoldStatusModel> {
    let result: Array<ListComponentFoldStatusModel> = [];
    let fundCodes: string[] = [];
    if (fundCode) {
      if (typeof fundCode === 'string') {
        fundCodes.push(fundCode);
      } else {
        fundCodes = fundCode;
      }
    }
    result = this.listComponents
      .filter(item => {
        let condition: boolean = (item.data && item.data.fundCode) ? true : false;
        if (fundCodes.length > 0) {
          const index = fundCodes.findIndex((acc) => {
            return item.data.fundCode === acc;
          });
          condition = condition && ((index !== -1) ? true : false);
        }
        return condition;
      })
      .map(item => {
        return {
          fundCode: item.data.fundCode,
          foldStatus: item.fold
        };
      });
    return result;
  }

  /**
   * 获取当前银行间银行间债券交易列表处于折叠状态明细的资产组合组成的数组
   * @param fundCode
   * @returns {string[]}
   */
  public getFoldListComponentFundCodeList(fundCode?: string | string[]): string[] {
    return this.getListComponentFundCodeList(fundCode, true);
  }

  /**
   * 获取当前银行间银行间债券交易列表处于打开显示状态明细的资产组合组成的数组
   * @param fundCode
   * @returns {string[]}
   */
  public getOpenListComponentFundCodeList(fundCode?: string | string[]): string[] {
    return this.getListComponentFundCodeList(fundCode, false);
  }

  /**
   * 获取当前银行间银行间债券交易列表明细的资产组合组成的数组
   * @param fundCode
   * @param fold 折叠状态 true表示要获取折叠状态的，false表示要获取展开状态的，不传参表示获取全部状态的
   * @returns {[string,string,string,string,string]}
   */
  public getListComponentFundCodeList(fundCode?: string | string[], fold?: boolean): string[] {
    if (arguments.length <= 1) {
      return this.getListComponentFoldStatusModuleList(fundCode).map(item => item.fundCode);
    } else {
      return this.getListComponentFoldStatusModuleList()
        .filter(item => item.foldStatus === fold)
        .map(item => item.fundCode);
    }
  }

  /**
   * 发布上传附件事件
   * @param uploadFileObj
   */
  public uploadFileAction(uploadFileObj: any) {
    this.uploadFile.emit(uploadFileObj);
  }

  /**
   * 发布删除附件事件
   * @param orderSerialNo
   */
  public removeFileAction(orderSerialNo: string) {
    this.removeFile.emit(orderSerialNo);
  }

  /**
   * 发布加急事件
   * @param settlementOrderId
   */
  public urgentAction(settlementOrderId: string) {
    this.urgent.emit(settlementOrderId);
  }

  /**
   * 发布获取全部质押券信息数据事件
   * @param orderSerialNo
   */
  public getPledgeAllDataAction(orderSerialNo: string) {
    this.getPledgeAllData.emit(orderSerialNo);
  }

  /**
   * ListComponent列表组件o32相关列折叠状态切换事件监听事件
   * @param o32FoldStatus
   */
  public o32FoldStautsChangedAction(o32FoldStatus: boolean) {
    this.listComponents.forEach(lc => lc.o32Fold = o32FoldStatus);
  }

  /**
   * 重新设置每一个ListComponent固定列的布局
   */
  public resetFixedTableLayout() {
    if (this.listComponents && this.listComponents.length > 0) {
      this.listComponents.forEach(lc => lc.resetFixedTableLayout());
    }
  }
}
