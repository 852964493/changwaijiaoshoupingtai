import { TestBed, inject } from '@angular/core/testing';

import { InterbankService } from './interbank.service';

describe('InterbankService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InterbankService]
    });
  });

  it('should ...', inject([InterbankService], (service: InterbankService) => {
    expect(service).toBeTruthy();
  }));
});
