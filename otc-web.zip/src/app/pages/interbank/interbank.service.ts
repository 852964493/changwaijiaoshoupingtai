import {Injectable} from '@angular/core';
import {HttpClientService} from "../../services/http-client.service";
import {Observable} from "rxjs/Observable";
import {IBTSearchModel} from "./interbank.component";
import {IBTHistorySearchModel} from "./history/history.component";
import {IBTTurnoverSearchModel} from "./turnover/turnover.component";
import * as _ from "lodash";

@Injectable()
export class InterbankService {

  constructor(public http: HttpClientService) {
  }

  /**
   * 获取银行间----债券交易分组列表数据
   * @param search 搜索条件模型对象
   * @param page 查询页码
   * @param pageSize 每页记录
   * @returns {any}
   */
  public getGroupListData(search: IBTSearchModel = {}, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      search.page = page;
    }
    if (pageSize != null) {
      search.pageSize = pageSize;
    }

    return this.http.get("otc/v1/chinamoney/bond-trade-groupview", search, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * 获取银行间----债券交易不分组列表数据
   * @param search 搜索条件模型对象
   * @param page 查询页码
   * @param pageSize 每页记录
   * @returns {any}
   */
  public getListData(search: IBTSearchModel = {}, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      search.page = page;
    } else {
      search.page = 0;
    }
    if (pageSize != null) {
      search.pageSize = pageSize;
    } else {
      search.pageSize = 0;
    }
    return this.http.get("otc/v1/chinamoney/bond-trade", search, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * 银行间债券交易列表------确定交收对比
   * @param settlementOrderIdList
   * @returns {any}
   */
  public settlementComparation(settlementOrderIdList: Array<any>): Observable<any> {
    return this.http.post('otc/v1/chinamoney/settleComparation', settlementOrderIdList, {
      isAuthHttp: false
    });
  }

  /**
   * 银行间债券交易列表-----手动作废单据
   * @param {Array<any>} settlementOrderIds 成交单ID组成的数组
   * @returns {any}
   */
  public invalidBill(settlementOrderIds: Array<any>): Observable<any> {
    return this.http.post(`otc/v1/chinamoney/cancel`, settlementOrderIds, {
      isAuthHttp: false
    });
  }

  /**
   * 银行间债券交易列表-----取消手动作废单据
   * @param settlementOrderIds 成交单ID组成的数组
   * @returns {any}
   */
  public cancelInvalidBill(settlementOrderIds: Array<any>): Observable<any> {
    return this.http.post(`otc/v1/chinamoney/no-cancel`, settlementOrderIds, {
      isAuthHttp: false
    });
  }

  /**
   * 银行间债券交易列表-----手动逾期单据
   * @param datas
   * @returns {Observable<T>|Promise<R>|Promise<T>}
   */
  public overdue(datas: Array<{ date: string, settlementOrderId: string }>): Observable<any> {
    return this.http.post('otc/v1/chinamoney/overdue', datas, {
      isAuthHttp: false
    });
  }

  /**
   * 银行间债券交易列表-----取消手动逾期单据
   * @param settlementOrderIds
   * @returns {any}
   */
  public cancelOverdue(settlementOrderIds: Array<any>): Observable<any> {
    return this.http.post(`otc/v1/chinamoney/no-overdue`, settlementOrderIds, {
      isAuthHttp: false
    });
  }

  /**
   * 银行间债券交易列表-----保存轧差计算结果
   * @param {Array<any>} orderSerialNoList
   * @param {boolean} isExecute
   * @returns {Observable<any>}
   */
  public nettingCount(orderSerialNoList: Array<any> = [], isExecute: boolean = false): Observable<any> {
    const reqBody = orderSerialNoList;
    const queryParamters = (isExecute === true) ? 'Y' : 'N';
    return this.http.post(`otc/v1/chinamoney/netting-cross-market/calc?isExecute=${queryParamters}`, reqBody, {
      isAuthHttp: false
    });
  }

  /**
   * 获取组合列表数据----搜索框
   * @returns {Observable<T>|Promise<R>|Promise<T>}
   */
  public getFundInfoListData(): Observable<any> {
    return this.http.get(`otc/V1/chinamoney/fundInfo`, {}, {
      isAuthHttp: false
    });
  }

  /**
   * 获取交易对手列表数据----搜索框
   * @returns {Promise<T>|Promise<R>|Observable<T>}
   */
  public getOppoHolderAccountListData(): Observable<any> {
    return this.http.get(`otc/V1/chinamoney/oppoHolderAccount`, {}, {
      isAuthHttp: false
    });
  }

  /**
   * 删除附件
   * @param orderSerialNo
   * @returns {Observable<T>|Promise<T>|Promise<R>}
   */
  public removeFile(orderSerialNo: string): Observable<any> {
    return this.http.delete(`otc/v1/chinamoney/tradeOrderFile/${orderSerialNo}`, {}, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * 获取银行间----历史交易列表数据
   * @param search 搜索条件模型对象
   * @param page 查询页码
   * @param pageSize 每页记录
   * @returns {any}
   */
  public getHisttoryListData(search: IBTHistorySearchModel = {}, page?: string | number, pageSize?: string | number): Observable<any> {
    return this.getListData(<IBTSearchModel>search, page, pageSize);
  }

  /**
   * 获取银行间----组合流水概览视图列表数据
   * @param search 搜索条件模型对象
   * @returns {any}
   */
  public getTurnoverOverviewListData(search: IBTTurnoverSearchModel = {}): Observable<any> {
    return this.http.get(`otc/V1/chinamoney/fund-account/statistics`, search, {
      isAuthHttp: false
    });
  }

  /**
   * 获取银行间----组合流水详细视图列表数据
   * @param search
   * @return {any}
   */
  public getTurnoverDetailListData(search: IBTTurnoverSearchModel = {}): Observable<any> {
    return this.http.get(`otc/V1/chinamoney/fund-account/detail`, search, {
      isAuthHttp: false
    });
  }

  /**
   * 获取支付参数配置的托管行列表
   * @returns {Observable<T>|Promise<T>|Promise<R>}
   */
  public getConfigBankListData(): Observable<any> {
    return this.http.get(`otc/v1/chinamoney/config/bank`, {}, {
      isAuthHttp: false
    });
  }

  /**
   * 根据托管行ID和分页信息查询相关基金支付参数配置列表数据
   * @param bankId
   * @param page
   * @param pageSize
   * @param fundName
   */
  public getFundsConfigListDataByBankId(bankId: string,
                                        page: string | number,
                                        pageSize: string | number,
                                        fundName?: string): Observable<any> {
    const reqBody = (pageSize === null || pageSize === '') ? {page: page + ''} : {
      page: page + '',
      pageSize: pageSize + ''
    };
    if (fundName) {
      reqBody['fundName'] = fundName.trim();
    }
    return this.http.get(`otc/v1/chinamoney/config/bank/${bankId}/fund`, reqBody, {
      isAuthHttp: false
    });
  }

  /**
   * 更新指定托管行支付参数配置
   * @param bankId
   * @param toSendTradeOrder
   * @param paymentMethod
   * @param note
   * @returns {Promise<R>|Promise<T>|Observable<T>}
   */
  public updateBankGlobalConfig(bankId: string, toSendTradeOrder: string, paymentMethod: string, note: string): Observable<any> {
    const reqBody = {
      bankId,
      toSendTradeOrder,
      paymentMethod,
      note
    };
    return this.http.put(`otc/v1/chinamoney/config/bank`, [reqBody], {
      isAuthHttp: false
    });
  }

  /**
   * 更新指定基金的支付参数配置
   * @param {string} bankId
   * @param {string} fundCode
   * @param {string} toSendTradeOrder
   * @param {string} paymentMethod
   * @param {string} note
   * @returns {Observable<any>}
   */
  public updateFundConfig(bankId: string,
                          fundCode: string,
                          toSendTradeOrder: string,
                          paymentMethod: string,
                          note: string): Observable<any> {
    const reqBody = {
      fundCode,
      toSendTradeOrder,
      paymentMethod,
      note
    };
    return this.http.put(`otc/v1/chinamoney/config/bank/${bankId}/fund`, [reqBody], {
      isAuthHttp: false
    });
  }

  /**
   * 删除指定基金支付参数配置
   * @param bankId 托管行ID
   * @param fundCodeList 基金代码列表字符串，逗号分隔
   */
  public deleteFundConfig(bankId: string, fundCodeList: string): Observable<any> {
    const reqBody = {};
    return this.http.delete(`/otc/v1/chinamoney/config/bank/${bankId}/fund/${fundCodeList}`, reqBody, {
      isAuthHttp: false
    });
  }


  /**
   * 获取加急处理人数据
   * @returns {any}
   */
  public getDealManDataList(): Observable<any> {
    // TODO
    const data = [
      {
        id: '0001',
        text: '张三'
      },
      {
        id: '0002',
        text: '李四'
      },
      {
        id: '0003',
        text: '王五'
      },
      {
        id: '0004',
        text: '赵六'
      },
      {
        id: '0005',
        text: '罗七'
      },
      {
        id: '0006',
        text: '杨八'
      }
    ];
    return Observable.create((ob) => ob.next(data));
  }

  /**
   * 设置加急事件处理人
   * @param datas
   * @returns {Observable<T>|Promise<R>|Promise<T>}
   */
  public urgent(datas: Array<{ dealMan: string, settlementOrderId: string }>): Observable<any> {
    return this.http.post(`otc/V1/chinamoney/urgent`, datas, {
      isAuthHttp: false
    });
  }


  /**
   * 根据成交单指令ID查询出与之相关的质押券信息数据，包含o32和上清所／中债等的质押券信息
   * @param orderSerialNo
   */
  public getPledgeAllData(orderSerialNo: string): Observable<any> {
    return this.http.get(`otc/V1/chinamoney/pledgeInfo/all/${orderSerialNo}`, {}, {
      isAuthHttp: false
    });
  }


  /**
   * 根据成交单ID和结算单ID查询与之现对应可以进行变更匹配的数据
   * @param {string} orderSerialNo
   * @returns {Observable<any>}
   */
  public getChangeMatchData(orderSerialNo: string): Observable<any> {
    const reqBody = {
      orderSerialNo
    };
    return this.http.get(`otc/V1/chinamoney/trade-rematch`, reqBody, {
      isAuthHttp: false
    });
  }

  /**
   * 更新与指定成交单相关的变更匹配数据
   * @param orderSerialNo
   * @param dateSerialNo
   * @returns {Promise<T>|Observable<T>|Promise<R>}
   */
  public updateChangeMatchData(orderSerialNo: string, dateSerialNo: string): Observable<any> {
    const reqBody = {
      orderSerialNo,
      dateSerialNo
    };
    return this.http.put(`otc/V1/chinamoney/trade-rematch`, reqBody, {
      isAuthHttp: false
    });
  }

  /**
   * 根据成交单ID查询相关上清所／中债登相关的质押券列表数据
   * @param tradeId
   */
  public getOtcPledgeInfoDataList(tradeId: string): Observable<any> {
    const reqBody = {};
    return this.http.get(`otc/v1/chinamoney/pledgeInfo/otc/${tradeId}`, reqBody, {
      isAuthHttp: false
    });
  }

  /**
   * 根据成交单ID查询相关o32相关的质押券列表数据
   * @param dateSerialNo
   */
  public getO32PledgeInfoDataList(dateSerialNo: string): Observable<any> {
    const reqBody = {};
    return this.http.get(`otc/v1/chinamoney/pledgeInfo/trd/${dateSerialNo}`, reqBody, {
      isAuthHttp: false
    });
  }

  /**
   * 获取个人组合列表数据
   * @param {string} model
   * @param {number} page
   * @param {number} pageSize
   * @param {string} userid
   * @returns {Observable<any>}
   */
  // TODO model临时默认为ALL，后端之后可能会定义一些枚举值来维护，pageSize临时为9999，后端后期可能有不分页接口， userid后端之后有可能会去掉
  public getFundFavoriteTagIdList(model: string = 'ALL',
                                  page: number = 1,
                                  pageSize: number = 9999,
                                  userid: string = sessionStorage.getItem('username')): Observable<any> {
    const reqBody: any = {page, pageSize};
    return this.http.get(`otc/v1/fundfavorite/query/${userid}/${model}`, reqBody);
  }
}
