import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundConfigComponent } from './fund-config.component';

describe('FundConfigComponent', () => {
  let component: FundConfigComponent;
  let fixture: ComponentFixture<FundConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
