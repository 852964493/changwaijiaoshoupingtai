import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {InterbankComponent} from "./interbank.component";
import {HistoryComponent} from "./history/history.component";
import {TurnoverComponent} from "./turnover/turnover.component";
import {TableConfigComponent} from "./table-config/table-config.component";
import {ChangeMatchComponent} from "./change-match/change-match.component";
import {FundConfigComponent} from "./fund-config/fund-config.component";

const routes: Routes = [
  {
    path: "",
    component: InterbankComponent
  },
  {
    path: "history",
    component: HistoryComponent
  },
  {
    path: "turnover",
    component: TurnoverComponent
  },
  {
    path: "tableConfig",
    component: TableConfigComponent
  },
  {
    path: 'fundConfig',
    component: FundConfigComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InterbankRoutingModule {
}
