import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {InterbankRoutingModule} from './interbank-routing.module';
import {ListComponent} from './list/list.component';
import {InterbankComponent} from "./interbank.component";
import {ListGroupComponent} from './list-group/list-group.component';
import {InterbankService} from "./interbank.service";
import {NettingCountComponent} from './netting-count/netting-count.component';
import {ChangeMatchComponent} from './change-match/change-match.component';
import {HistoryComponent} from './history/history.component';
import {TurnoverComponent} from './turnover/turnover.component';
import {TableConfigComponent} from './table-config/table-config.component';
import {DragulaModule, DragulaService} from "ng2-dragula";
import {FormsModule} from "@angular/forms";
import {NumeralPipe} from "../../pipes/numeral.pipe";
import {MomentPipe} from "../../pipes/moment.pipe";
import {FileUploadComponent} from './file-upload/file-upload.component';
import {FileUploadModule} from "ng2-file-upload";
import {FundConfigComponent} from './fund-config/fund-config.component';
import {AppPaginationModule} from "../../widgets/pagination/pagination.module";
import {AppWidgetsModule, AppWidgetsRootModule} from "../../widgets/index";


@NgModule({
  imports: [
    CommonModule,
    InterbankRoutingModule,
    DragulaModule,
    FormsModule,
    FileUploadModule,
    AppPaginationModule
  ],
  declarations: [InterbankComponent, ListComponent, ListGroupComponent, NettingCountComponent,
    ChangeMatchComponent, HistoryComponent, TurnoverComponent, TableConfigComponent, NumeralPipe,
    MomentPipe, FileUploadComponent, FundConfigComponent],
  providers: [InterbankService, DragulaService],
  exports: []
})
export class InterbankModule {
}
