import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Observable";

@Injectable()
export class ListService {

  constructor() {

  }

  public getListData(): Observable<any> {
    return Observable.create(function (ob) {
        setTimeout(() => {
          ob.next({
            yhj: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            zqfx: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            cwjj: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            wxxg: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            qh: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            dc: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            ztg: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            xyhg: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            },
            fdb: {
              hsUnMatch: 6,
              error: 8,
              unDoDirective: 12,
              unDoContract: 12,
              hsUnsettle: 23,
              negativeCash: 5,
              total: 56
            }
          });
        }, 500);
      }
    );
  }
}
