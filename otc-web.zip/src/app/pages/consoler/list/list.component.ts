import {Component, OnInit} from '@angular/core';
import {ListService} from "./list.service";

@Component({
  selector: "consoler-list",
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  providers: [ListService]
})
export class ListComponent implements OnInit {
  public loading: boolean = false;

  public listData: any;

  constructor(private listService: ListService) {
  }

  ngOnInit() {
    this.updateListData();
  }

  public updateListData() {
    this.loading = true;
    this.listService.getListData()
      .subscribe(data => {
        this.listData = data;
        this.loading = false;
      });
  }
}
