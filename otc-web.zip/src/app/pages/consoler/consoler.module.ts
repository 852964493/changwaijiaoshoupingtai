import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {ConsolerRoutingModule} from './consoler-routing.module';
import {ConsolerComponent} from "./consoler.component";
import {ListComponent} from "./list/list.component";
import {TimelineComponent} from './timeline/timeline.component';
import {FormsModule} from "@angular/forms";


@NgModule({
  imports: [
    CommonModule,
    ConsolerRoutingModule,
    FormsModule
  ],
  declarations: [ConsolerComponent, ListComponent, TimelineComponent]
})
export class ConsolerModule {
}
