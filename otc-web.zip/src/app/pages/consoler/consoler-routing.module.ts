import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ConsolerComponent} from "./consoler.component";

const routes: Routes = [
  {
    path: '',
    redirectTo: "entry"
  },
  {
    path: "entry",
    component: ConsolerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConsolerRoutingModule {
}
