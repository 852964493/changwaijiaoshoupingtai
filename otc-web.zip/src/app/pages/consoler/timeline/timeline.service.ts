import {Injectable} from '@angular/core';
import {Observable} from "rxjs/Observable";

@Injectable()
export class TimelineService {

  private data = [
    {
      time: "8:00",
      matter: "关键业务时间点"
    },
    {
      time: "9:00",
      matter: ""
    },
    {
      time: "11:00",
      matter: "重要业务事项"
    },
    {
      time: "12:00",
      matter: ""
    }, {
      time: "13:00",
      matter: ""
    }, {
      time: "14:00",
      matter: "头寸监控、交割提醒"
    }, {
      time: "15:00",
      matter: "重要业务事项"
    },
    {
      time: "16:00",
      matter: ""
    },
    {
      time: "17:00",
      matter: "重要业务事项"
    },
    {
      time: "18:00",
      matter: ""
    },
    {
      time: "19:00",
      matter: ""
    },
    {
      time: "20:00",
      matter: ""
    },
    {
      time: "21:00",
      matter: ""
    },
    {
      time: "22:00",
      matter: ""
    },
    {
      time: "23:00",
      matter: ""
    },
    {
      time: "24:00",
      matter: ""
    }
  ];

  constructor() {
  }

  public getTimelineData() {
    return Observable.create(ob => {
      setTimeout(() => {
        ob.next(this.data);
      }, 500);
    });
  }

  public addTimeLineData(newData) {
    this.data.push(newData);
  }

}
