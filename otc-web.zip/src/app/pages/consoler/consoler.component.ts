import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'consoler',
  templateUrl: './consoler.component.html',
  styleUrls: ['./consoler.component.scss']
})
export class ConsolerComponent implements OnInit {
  ngOnInit(): void {

  }
}
