import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload';

import { TransferInstructionRoutingModule } from './transfer-instruction-routing.module';
import { ListComponent } from './transfer-instructionManage/list/list.component';
import { DetailModalComponent } from './transfer-instructionManage/detail-modal/detail-modal.component';
import { TransferInstructionManageComponent } from "./transfer-instructionManage/transfer-instructionManage.component";
import { TransferInstructionManageService } from "./transfer-instructionManage/transfer-instructionManage.service";
import { DetailModalService } from './transfer-instructionManage/detail-modal/detail-modal.service';

import { TransferInstructionOptionComponent } from './transfer-instructionOption/transfer-instructionOption.component';
import { TransferInstructionOptionService } from './transfer-instructionOption/transfer-instructionOption.service';

import { BankAccountManageComponent } from './bank-accountManage/bank-accountManage.component';
import { BankAccountManageService } from './bank-accountManage/bank-accountManage.service';

// import { ZdAccountManageComponent } from './zd-accountManage/zd-accountManage.component';
// import { ZdAccountManageService } from './zd-accountManage/zd-accountManage.service';

import { AppPaginationModule } from "../../widgets/pagination/pagination.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FileUploadModule,
    TransferInstructionRoutingModule,
    AppPaginationModule
  ],
  declarations: [
    ListComponent,
    DetailModalComponent,
    TransferInstructionManageComponent,
    TransferInstructionOptionComponent,
    BankAccountManageComponent,
    // ZdAccountManageComponent
  ],
  providers: [
    TransferInstructionManageService,
    DetailModalService,
    TransferInstructionOptionService,
    BankAccountManageService,
    // ZdAccountManageService
  ]
})

export class TransferInstructionModule {

}
