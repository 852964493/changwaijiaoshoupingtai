import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {TransferInstructionManageComponent} from "./transfer-instructionManage/transfer-instructionManage.component";
import {TransferInstructionOptionComponent} from './transfer-instructionOption/transfer-instructionOption.component';
import {BankAccountManageComponent} from './bank-accountManage/bank-accountManage.component';
// import {ZdAccountManageComponent} from './zd-accountManage/zd-accountManage.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'transferList'
  },
  {
    path: 'transferList',
    component: TransferInstructionManageComponent
  },
  {
    path: 'transferList/exchange/:flag',
    component: TransferInstructionManageComponent
  },
  {
    path: 'transferOption',
    component:  TransferInstructionOptionComponent
  },
  {
    path: 'bankAccountManage',
    component: BankAccountManageComponent
  },
  // {
  //   path: 'zdAccountManage',
  //   component: ZdAccountManageComponent
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class TransferInstructionRoutingModule {
}
