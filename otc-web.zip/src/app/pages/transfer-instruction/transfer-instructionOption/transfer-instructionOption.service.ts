import {Injectable} from '@angular/core';
import {HttpClientService} from "../../../services/http-client.service";
import {Observable} from "rxjs/Observable";


@Injectable()
export class TransferInstructionOptionService {
  
  constructor(public http: HttpClientService) {
  }


  /**
   * 获取划款指令参数配置列表数据
   * @param {TFISeacrhModel} [param={}] 搜索条件模型对象
   * @param {(string | number)} [page] 查询页码
   * @param {(string | number)} [pageSize] 每页记录
   * @returns {Observable<any>}
   * @memberof TransferInstructionManageService
   */
  public getListData(param:any = {}, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    return this.http.get("otc/v1/btm/selecthksendtype", param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * 获取银行列表
   * @param {any} param 
   * @returns {Observable<any>} 
   * @memberof TransferInstructionOptionService
  * */
  public getBankList(param): Observable<any>{
    return this.http.get("otc/v1/btm/selectbank", param, {
      isAuthHttp: false
    });
  }

  // 新增或更新基金配置
  public addORUpdateFundConfig(param,type):Observable<any>{
    if(type==="add"){
      return this.http.post("otc/v1/btm/addhksendtype",param,{
        isAuthHttp: false
      });
    }
    if(type==="update"){
      return this.http.put("otc/v1/btm/updatehksendtype",param,{
        isAuthHttp: false
      });
    }
  }

  // 删除基金配置
  public deleteFundConfig(param):Observable<any>{
    return this.http.delete("otc/v1/btm/deletehksendtype",param,{
      isAuthHttp: false
    });
  }
 
  // 搜索模态框内基金列表
  public searchFundList(param):Observable<any>{
    return this.http.get("otc/v1/btm/selectfundcode",param,{
      isAuthHttp: false
    });
  }

}
