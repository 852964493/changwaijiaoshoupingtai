import {Injectable} from '@angular/core';
import {HttpClientService} from "../../../services/http-client.service";
import {Observable} from "rxjs/Observable";
import {TFISeacrhModel} from "./transfer-instructionManage.component";


@Injectable()
export class TransferInstructionManageService {
  constructor(public http: HttpClientService) {
  }

  // 通用请求函数
  public sendCommonRequest(search,url,method) {
    return this.http[method](`otc/v1/btm/${url}`,search.hkInstructionId,{
      isAuthHttp: false,
      isReturnOriginal:true
    })
  }

  /**
   * 获取划款指令列表数据
   * @param {TFISeacrhModel} [search={}] 搜索条件模型对象
   * @param {(string | number)} [page] 查询页码
   * @param {(string | number)} [pageSize] 每页记录
   * @returns {Observable<any>}
   * @memberof TransferInstructionManageService
   */
  public getListData(search: TFISeacrhModel = {}, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      search.page = page;
    } else {
      search.page = 0;
    }
    if (pageSize != null) {
      search.pageSize = pageSize;
    } else {
      search.pageSize = 0;
    }
    return this.http.get("otc/v1/btm/conditionselecthkinstruction", search, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }
}
