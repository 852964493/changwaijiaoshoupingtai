import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {numeral} from 'numeral';
import {Util} from "../../../../common/util";
import {environment} from "environments/environment";
import {FileUploader} from 'ng2-file-upload';
import {FileItem, FileUploaderOptions, ParsedResponseHeaders} from "ng2-file-upload";
import { DetailModalService} from './detail-modal.service'


@Component({
  selector: 'transfer-detail-modal',
  templateUrl: './detail-modal.component.html',
  styleUrls: ['./detail-modal.component.scss']
})
export class DetailModalComponent implements OnInit {

  public $ = window['$'];

  public uploader: FileUploader;

  // 修改指令变量对象
  public updateData = {
    hkInstructionId:"",
    hkTypeId : "",
    bizType : "",
    marketNo : "",
    hkInstructionStatus : "",
    fundCode : "",
    stockCode : "",
    paymentAmount : "",
    paymentUsage : "",
    paymentDesc : "",
    paymentArrivalDate : "",
    payee : "",
    payeeBank : "",
    payer : "",
    payerBank : "",
    payerAccount : "",
    instructionDate : "",
    instructionUser : "",
    instructionConfirmDate : "",
    instructionConfirmUser : "",
    instructionCheckDate : "",
    instructionCheckUser : "",
    instructionRecheckDate : "",
    instructionRecheckUser : "",
    instructionSendDate : "",
    orderId:"",
    instructionManualconfirmDate : "",
    instructionManualconfirmUser : "",
    instructionSendoutescrowUser : "",
    sendType : "",
    instructionSendoutescrowDate : "",
    vcEmergencyDegree : "",
    vcRevocationCause : "",
    currency : "",
    payerBankKeyNo : "",
    payeeLargeNo : "",
    payeeBankKeyNo : "",
    payerLargeNo : "",
    vcFaxNo : "",
    fundCompanyNo : "",
    bankFaxNo : ""
  }

  /**
   * 从list表格返回的数据
   * @type {Data}
   * @memberof ListComponent
   */
  @Input()
  public acceptData: any = {};

  @Output()
  public returnData: EventEmitter<any> = new EventEmitter<any>();

  constructor(public service:DetailModalService) {
    this.uploader = new FileUploader(this.defaultConfig);
  }

  ngOnInit() {
  }


  /**
   * 初始化上传配置
   * @type {FileUploaderOptions}
   * @memberof DetailModalComponent
   */
  public defaultConfig: FileUploaderOptions = {
    autoUpload: false,
    url: "",
    method: 'post',
    itemAlias: 'file'
  };

  public selectedFileOnChanged() {
    window["swal"]("提示", "上传成功", "info");
  };

  /**
   * 模态框关闭
   * @memberof DetailModalComponent
   */
  public closeModal() {
    this.$("#transferDetailModal").modal('toggle');
  }

  /**
   * 保存模态框事件
   */
  public saveModal() {
    this.$("#transferDetailModal").modal('toggle');
    var data = this.copyData(this.acceptData,this.updateData);
    this.service.modifyTransferInstruction(data).subscribe(result=>{
      if(result){
        window['swal']({
          title: "提示",
          text: `<div>操作成功！</div>`,
          html: true,
          type: result
        });
      }
    });
    this.returnDataAction(this.acceptData);
  }

  public copyData(p, c){
    for(let i in p){
      for(let a in c)
      if(i === a){
        c[a] = p[i];
      }
    }
    return c;
  }
  /**
   * 模态框往上派发数据动作
   * @param {*} item
   * @memberof DetailModalComponent
   */
  public returnDataAction(item: any) {
    this.returnData.emit({
      item: item
    });
  }

}
