import {Injectable} from '@angular/core';
import {HttpClientService} from "../../../../services/http-client.service";
import {Observable} from "rxjs/Observable";



@Injectable()
export class DetailModalService {
  constructor(public http: HttpClientService) {
  }

  // 划款指令修改请求
  public modifyTransferInstruction(param): Observable<any> {
    return this.http.put(`otc/v1/btm/updatehkinstruction`, param, {
      isAuthHttp: false
    });
  }

}
