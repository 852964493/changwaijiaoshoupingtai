import {Injectable} from '@angular/core';
import {HttpClientService} from "../../../services/http-client.service";
import {Observable} from "rxjs/Observable";


@Injectable()
export class BankAccountManageService {
  
  constructor(public http: HttpClientService) {
  }

  // 获取模态框内下拉列表
  public getModalSelectData():Observable<any>{
    return this.http.get("otc/v1/receivingaccount/hktypelist",null,{
      isAuthHttp:false
    });
  }

  /**
   * 获取银行账户列表数据
   * @param {TFISeacrhModel} [param={}] 搜索条件模型对象
   * @param {(string | number)} [page] 查询页码
   * @param {(string | number)} [pageSize] 每页记录
   * @returns {Observable<any>}
   * @memberof TransferInstructionManageService
   */
  public getListData(param:any = {}, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    return this.http.get("otc/v1/receivingaccount/querycondition", param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  public deleteAccount(param):Observable<any>{
    return this.http.delete("otc/v1/receivingaccount/delete",param,{
      isAuthHttp: false,
    })
  }

  // 新增或编辑账户设置
  public addORUpdateAccountConfig(param,type):Observable<any>{
    if(type==="add"){
      return this.http.post("otc/v1/receivingaccount/insert",param,{
        isAuthHttp: false
      });
    }
    if(type==="update"){
      return this.http.put("otc/v1/receivingaccount/update",param,{
        isAuthHttp: false
      });
    }
  }

  // 搜索模态框内基金列表
  public searchFundList(param):Observable<any>{
    return this.http.get("otc/v1/receivingaccount/trustAccount",param,{
      isAuthHttp: false
    });
  }
  

}
