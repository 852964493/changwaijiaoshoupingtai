import { FileUploadModule } from 'ng2-file-upload';
import { AppPaginationModule } from './../../widgets/pagination/pagination.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BondDistributionRoutingModule } from './bond-distribution-routing.module';
import { DistributionComponent } from './distribution/distribution.component';

import {FormsModule} from "@angular/forms";

import {DistributionService} from './distribution/distribution.service';

@NgModule({
	imports: [
		CommonModule,
		BondDistributionRoutingModule,
    FormsModule,
    AppPaginationModule,
    FileUploadModule
	],
  declarations: [DistributionComponent],
  providers:[DistributionService]
})
export class BondDistributionModule { }
