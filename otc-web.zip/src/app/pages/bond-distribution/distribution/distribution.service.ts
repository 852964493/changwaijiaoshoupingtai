import {Observable} from "rxjs/Observable";
import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';
import { environment } from "../../../../environments/environment";
import {TFISeacrhModel} from './distribution.component'
@Injectable()
export class DistributionService {

  constructor(
    public httpClient: HttpClientService
  ) { }

  public ckAlert(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/moneyState",param.distributionId,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }
  //首页列表文件上传
  public upload(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/tradeOrderFile/upload",param,{
      isAuthHttp: false,
    });
  }
  //债券管理列表数据删除
  public deleteBondManData(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/deleteNewBond",param.id,{
      isAuthHttp: false,
    });
  }
  //首页列表文件删除
  public deleteFile(param): Observable<any> {
    return this.httpClient.delete("otc/v1/newbond/tradeOrderFile/deleteFile",param,{
      isAuthHttp: false,
      // isReturnOriginal: true
    });
  }
  //债券管理编辑提交
  public editSubmit(param): Observable<any> {
    return this.httpClient.put("otc/v1/newbond/updateNewBond",param,{
      isAuthHttp: false,
    });
  }
  //发起缴款
  public initiatePayment(param): Observable<any> {
    return this.httpClient.put("otc/v1/newbond/initiatePayment",param.distributionId,{
      isAuthHttp: false,
      // isReturnOriginal: true
    });
  }
   //债券管理多文件下载
  public bondsManfileDownl(param): Observable<any> {
    return this.httpClient.get("otc/v1/newbond/queryFileId",param,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }
   //债券管理撤销标记
  public undoMark(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/revocationFlag",param.id,{
      isAuthHttp: false,
    });
  }
  //交易场所信息获取
  public dealPlace(): Observable<any> {
    return this.httpClient.get("otc/v1/newbond/queryAllMarket",{
      isAuthHttp: false,
    });
  }
   //债券管理标记白名单
  public tagWhiteList(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/tagWhitelist",param.id,{
      isAuthHttp: false,
    });
  }
   //债券管理标记白名单
  public tagBlacklist(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/tagBlacklist",param.id,{
      isAuthHttp: false,
    });
  }
  //缴款管理
  public paymentManage(param, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    return this.httpClient.get("otc/v1/newbond/paymentManagement", param , {
      isAuthHttp: false,
    });
  }
  //通知FA
  public noticeFA(param): Observable<any> {
    return this.httpClient.put("otc/v1/newbond/noticeFA",param.distributionId,{
      isAuthHttp: false,

    });
  }
  //补充承销商收款账号
  public AddcollecAccount(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/supplementCollectionAccount",param,{
      isAuthHttp: false,

    });
  }
  public ckUnconfirm(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/underwriting", param.distributionId, {
      isAuthHttp: false,
    });
  }
  public ckDelete(param): Observable<any> {
    return this.httpClient.delete(`otc/v1/newbond/delete/${param.distributionId}`, {
      isAuthHttp: false,
    });
  }
  public getBondinfo(param): Observable<any> {
    return this.httpClient.get("otc/v1/newbond/information", param, {
      isAuthHttp: false,
    });
  }
  public getBondManaInfo(param, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    return this.httpClient.get("otc/v1/newbond/managementByCondition", param, {
      isAuthHttp: false,
    });
  }
  public exportExcelData(): Observable<any> {
    return this.httpClient.get("otc/v1/newbond/downloadExcel", {
      isAuthHttp: false,
    });
  }
  public zqManagExportData(): Observable<any> {
    return this.httpClient.get("otc/v1/newbond/infomationDownloadExcel", {
      isAuthHttp: false,
    });
  }
  //缴款申请提交
  public submitJKApply(param): Observable<any> {
    return this.httpClient.post("otc/v1/newbond/payment", param, {
      isAuthHttp: false,
    });
  }
  //待缴款记录查询
  public recordQuery(param, page?: string | number, pageSize?: string | number): Observable<any> {
     if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    return this.httpClient.get("otc/v1/newbond/needPayment",param, {
      isAuthHttp: false,
    });
  }

  //确认加急
  public confirmQ(param): Observable<any> {
    return this.httpClient.put("otc/v1/newbond/urgent?"+"distributionId="+param.distributionId , {
      isAuthHttp: false,
    });
  }
  //列表数据分组
  public listDataGroup(param,page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }

    return this.httpClient.get("otc/v1/newbond/combinationAll",param, {
      isAuthHttp: false,
    });
  }
  //历史交易
  public historicalDeal(param, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    return this.httpClient.get("otc/v1/newbond/historicalByCondition", param, {
      isAuthHttp: false,
    });
  }

  /**
   * 获取划款指令列表数据
   * @param {TFISeacrhModel} [search={}] 搜索条件模型对象
   * @param {(string | number)} [page] 查询页码
   * @param {(string | number)} [pageSize] 每页记录
   * @returns {Observable<any>}
   * @memberof TransferInstructionService
   */
  getListData(param, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }
    // param.type = 3;

    // console.log(JSON.stringify(postBody))
    return this.httpClient.get('otc/v1/newbond/querybond', param, {
      isAuthHttp: false
    });
  }
}
