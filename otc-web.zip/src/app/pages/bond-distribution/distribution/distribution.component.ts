import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DistributionService } from './distribution.service';
import { Util } from "../../../common/util";
import { Subscription } from "rxjs/Subscription";
import { AppPaginationComponent, PaginationModel } from "../../../widgets/pagination/pagination.component";
import * as _ from 'lodash';
import { environment } from '../../../../environments/environment';
import { FileUploadModule } from 'ng2-file-upload';
import {FileUploader} from "ng2-file-upload";

//债券分销搜索模型
export interface TFISeacrhModel {
  /**
   * 债券名称
   */
  // BondsName?: string;
  /**
  * 组合名称
  */
  // fundName?: string;
  /**
  * 交易场所
  */
  // TradingPlace?: string;
  /**
   * 债券利率
   */
  // BondsRate?: string;
  /**
   * 指令开始日期
   */
  // initiateDateStart?: string;
  /**
   * 指令结束日期
   */
  // initiateDateEnd?: string;



}

@Component({
  selector: 'bond-distribution-distribution',
  templateUrl: './distribution.component.html',
  styleUrls: ['./distribution.component.scss']
})
export class DistributionComponent implements OnInit {

  public investmentPool = {
    "1":"默认",
    "2":"黑名单",
    "3":"白名单"
  };
  public dealPosition = {
    "SH":"上海",
    "SZ":"深圳",
  };

  // B: 初始化定义uploader变量,用来配置input中的uploader属性
  public uploader: FileUploader = new FileUploader({});

  // 上传配置
  public uploadConfig:any = {
    modalTile: "", // modal title
    title: "", // titel
    url: "", // url
    method: "", // POST OR GET
    itemAlias: "", // file alias
    formDatas: [] // POST 参数
  };

  //列表查询按钮显示
  displaySearch = 'homePage';

  //债券管理多文件下载接收对象
  bondsManfileDownlist ;

  //首页列表分组视图
  unDisplayGroup =true;

  // 上传文件名称
  public fileName = "";

  //首页上传债券数据
  public uploadBonds;

  //不同列表数据删除按钮显示
  public deleteButton='';

  //债券管理数据
  public bondManageList;

  //隐藏分组按钮
  public hideGroup =true;

  //债券管理编辑数据
  public bondManageEditList:any = {
      isChecked : false
  };

  //交易场所信息获取
  public dealPlace;

  //显示出款和到账按钮
  DisplayPayMan= false;

  //显示划款指令ID
  dispPayforID= false;

  // 列表当前页全选标记
  public isCheckedAll = false;

  // 分页列表全选标记
  public groupIsCheckedAll = false;

  // 债券管理列表全选标记
  public isManagisCheckedAll = false;

  //缴款申请债券代码查询
  public bondCode = '';

  //加急选中股票对象
  public ckeckedBonds;

  //补充承销商和收款账号选取对象
  public AddcollecAccountBonds;

  //相关文件操作显示
  public showFileOperation =true;

  //列表数据分组显示
  public groupList =false;

  //显示添加收款账号操作
  dispAddcollecAccount =false;

  private $ = window['$'];

  //分组列表显示图标
  changeIco=false;

  // 缴款申请债券代码信息
  public bondCodeInfo: any = {
    //债券代码
    bondCode:'',
    //发行人全称
    issueName :'',
    //债券利率
    bondRate :'',
    //交易场所
    tradingPlace:'',
    //年付息次数
    aInterestPayments:'',
    //债券起息日
    bondValueDate:'',
    //发行总量
    totalIssued:'',
    //债券到息日
    bondInterestDate:'',
    //利率类型
    rateType:'',
    //债项评级
    bondRating:'',
    //主体评级
    subjectRating:'',
    //申请对象
    applyobj:'',
    //币种
    currency:'',
    //缴款日期
    paymentDate:'',
    //债券名称
    bondName:'',
    //组合名称
    fundName:'',
    //组合代码
    fundCode:'',
    //缴款金额
    paymentAmount:'',
    //付息类型
    interestType:'',
    //文件id
    attachs:''
  };
  //缴款申请组合
    payinGroup =[];
  //历史交易显示
  DisplayHistory = true;
  /**
   * 分页数据模型
   * @type {PaginationModel}
   * @memberof TransferInstructionComponent
   */
  // 首页列表分页配置
  public pageInfo: PaginationModel = {
    currentPageNum: 1,
    pageSize: 10,
    totalPages: 1,
    total: 0,
    pagesShow: 5,
    startRow: 0,
    endRow: 0,
    pageList: [5, 10, 25, 50, 100]
  };

  // 待缴款分页配置
  public recordQueryPageInfo: PaginationModel = {
    currentPageNum: 1,
    pageSize: 10,
    totalPages: 1,
    total: 0,
    pagesShow: 5,
    startRow: 0,
    endRow: 0,
    pageList: [5, 10, 25, 50, 100]
  };

  // 缴款管理分页配置
  public paymentManagePageInfo: PaginationModel = {
    currentPageNum: 1,
    pageSize: 10,
    totalPages: 1,
    total: 0,
    pagesShow: 5,
    startRow: 0,
    endRow: 0,
    pageList: [5, 10, 25, 50, 100]
  };

  // 历史交易分页配置
  public goHistoryPageInfo: PaginationModel = {
    currentPageNum: 1,
    pageSize: 10,
    totalPages: 1,
    total: 0,
    pagesShow: 5,
    startRow: 0,
    endRow: 0,
    pageList: [5, 10, 25, 50, 100]
  };

  /**
   * 改变首页列表显示记录数
   * @param {pageSize}
   */
  public pageSizeChange(pageSize: number) {
    if (pageSize !== this.pageInfo.pageSize) {
      this.pageInfo.pageSize = pageSize;
      this.pageInfo.currentPageNum = 1;
      this.search();
    }
  }

   /**
   * 改变缴款管理列表显示记录数
   * @param {pageSize}
   */
  public paymentManagePageSizeChange(pageSize: number) {
    if (pageSize !== this.paymentManagePageInfo.pageSize) {
      this.paymentManagePageInfo.pageSize = pageSize;
      this.paymentManagePageInfo.currentPageNum = 1;
      this.paymentManage();
    }
  }

  /**
   * 改变历史交易列表显示记录数
   * @param {pageSize}
   */
  public goHistoryPageSizeChange(pageSize: number) {
    if (pageSize !== this.goHistoryPageInfo.pageSize) {
      this.goHistoryPageInfo.pageSize = pageSize;
      this.goHistoryPageInfo.currentPageNum = 1;
      this.historicalSearch();
    }
  }

   /**
   * 改变待缴款列表显示记录数
   * @param {pageSize}
   */
  public recordQueryPageSizeChange(pageSize: number) {
    if (pageSize !== this.recordQueryPageInfo.pageSize) {
      this.recordQueryPageInfo.pageSize = pageSize;
      this.recordQueryPageInfo.currentPageNum = 1;
      this.recordQuery();
    }
  }

   /**
   * 改变债券管理列表显示记录数
   * @param {pageSize}
   */
  public bondsManpageSizeChange(pageSize: number) {
    if (pageSize !== this.bondsManpageInfo.pageSize) {
      this.bondsManpageInfo.pageSize = pageSize;
      // this.bondsManpageInfo.currentPageNum = 1;
      this.searchManageCondi();
    }
  }

  // 债券管理分页配置
  public bondsManpageInfo: PaginationModel = {
    currentPageNum: 1,
    pageSize: 10,
    totalPages: 1,
    total: 0,
    pagesShow: 5,
    startRow: 0,
    endRow: 0,
    pageList: [5, 10, 25, 50, 100]
  };
  /**
  * 根据页码请求查询相关配置列表数据,如果当前活动页码就是目标页码，则不进行任何查询
  * 直接返回
  */
  public pageNavigation(currentPageNum: number) {
    this.pageInfo.currentPageNum = currentPageNum;
    this.getRemittanceList(
      this.warpperSearchModule(),
      this.pageInfo.currentPageNum,
      this.pageInfo.pageSize);
  }
  //首页列表分组分页
  public groupPageNavigation(currentPageNum: number){
    this.pageInfo.currentPageNum = currentPageNum;
    this.switchListView(this.pageInfo.currentPageNum,
      this.pageInfo.pageSize)
  }
  //历史交易分页功能
  public HisPageNavigation(currentPageNum: number){
    this.goHistoryPageInfo.currentPageNum = currentPageNum;
    this.goHistory(this.goHistoryPageInfo.currentPageNum,
      this.goHistoryPageInfo.pageSize,'changePage')
  }
    //待缴款记录分页
    public unpayforNavigation(currentPageNum: number){
    this.recordQueryPageInfo.currentPageNum = currentPageNum;
    this.recordQuery(this.recordQueryPageInfo.currentPageNum,
      this.recordQueryPageInfo.pageSize)
  }
  //缴款管理分页
    public payforManNavigation(currentPageNum: number){
    this.paymentManagePageInfo.currentPageNum = currentPageNum;
    this.paymentManage(this.paymentManagePageInfo.currentPageNum,
      this.paymentManagePageInfo.pageSize)
  }

    //债券管理分页
    public bondsManPageNavigation(currentPageNum: number){
      this.bondsManpageInfo.currentPageNum = currentPageNum;
      this.searchManageCondi(this.bondsManpageInfo.currentPageNum,
      this.bondsManpageInfo.pageSize)
    }
  /**
 * 划款指令查询请求返回的列表数据
 * @type {{list:Array}}
 */
  public data: any = {
    list: []
  };

  // 列表
  public BondsList: Array<any>;

  public unGroupList : any;

  constructor(public service: DistributionService) {
  }

  ngOnInit() {
    // 调用时间插件
    Util.daterangepickerPluginInit(".daterangepicker-plugin");
    Util.datepickerPluginInit(".daterangepicker-single");
    this.search()
    this.searchManageCondi();

  }

  public checkAll() {
    if (this.isCheckedAll) { // 更新为全选
      _.forEach(this.BondsList, item => {
        item.isChecked = true;
      });
    } else { // 更新为不全选
      _.forEach(this.BondsList, item => {
        item.isChecked = false;
      });
    }
  }
    public groupCheckAll(groupBonds) {
    if (this.groupIsCheckedAll) { // 更新为全选
      // this.unGroupList.forEach((item)=>{
      //    item.distributionsList.forEach((item)=>{
      //      item.isChecked = true
      //    })
      // })
      groupBonds.distributionsList.forEach((item)=>{
           item.isChecked = true
         })
    }else { // 更新为不全选
      // this.unGroupList.forEach((item)=>{
      //    item.distributionsList.forEach((item)=>{
      //      item.isChecked = false
      //    })
      // })
      groupBonds.distributionsList.forEach((item)=>{
           item.isChecked = false
         })
    }
  }
  public ManagisCheckedAll() {
    if (this.isManagisCheckedAll) { // 更新为全选
      _.forEach(this.bondManageList, item => {
        item.isChecked = true;
      });
    } else { // 更新为不全选
      _.forEach(this.bondManageList, item => {
        item.isChecked = false;
      });
    }
  }

  //首页数据列表上传
  upoloadFile(){

  }
  //缴款信息录入新增数据
  addData(){
    let newDate = window['$']('#addDataDate').val().split('-').join('');
    this.bondCodeInfo.paymentDate = newDate;
    this.payinGroup.push(Util.$.extend(true,{},this.bondCodeInfo));
    window["$"]('#PaymentPlus').modal('toggle');


  }

  //缴款申请新增删除
  deleteApplyData(i){
      this.payinGroup.splice(i,1)
  }
  //缴款申请提交
  submitJKApply(){

    const param = this.payinGroup;

    this.service.submitJKApply(param).subscribe(result => {
              if (result) {
                window["swal"]("成功!", "", "success");
                this.search();
                window['$']("#applyUpFile").val('')
                window["$"]('#paymentModal').modal('toggle');
              }
            });

     //清空表单输入框
    this.bondCodeInfo.bondCode='';
    this.bondCodeInfo.issueName='';
    this.bondCodeInfo.bondRate='';
    this.bondCodeInfo.tradingPlace='';
    this.bondCodeInfo.aInterestPayments='';
    this.bondCodeInfo.bondValueDate='';
    this.bondCodeInfo.totalIssued='';
    this.bondCodeInfo.bondInterestDate='';
    this.bondCodeInfo.bondRating='';
    this.bondCodeInfo.subjectRating='';
    this.bondCodeInfo.currency='';
    this.bondCodeInfo.bondName='';
    this.bondCodeInfo.fundName='';
    this.bondCodeInfo.fundCode='';
    this.bondCodeInfo.paymentAmount='';
    this.bondCodeInfo.interestType='';
    this.bondCodeInfo.rateType='';
    this.bondCodeInfo.attachs='';

            this.payinGroup =[];
  }



  //待缴款记录查询
  recordQuery(currentPageNum: number = this.recordQueryPageInfo.currentPageNum,
    pageSize: number = this.recordQueryPageInfo.pageSize){
      const $ = window["$"];
      const param: TFISeacrhModel = {
    };
      $(".ibt-search-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
      if (id && id !== "") {
        if (id === "Time") {
          param[`start${id}`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`end${id}`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else if (id === 'paymentDate') {
          param[`${id}StartTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            param[id] = value;
          }
        }
      }
      if (type === 'checkbox' && item.checked) {

        param[item.name] = value;

      } else if (type === 'radio' && item.checked) {
        param[item.name] = value;
      }
    })

    this.service.recordQuery(param, currentPageNum, pageSize).subscribe(result => {
              if (result) {
                this.BondsList = result.list;
                this.recordQueryPageInfo.currentPageNum = result.pageNum;
                this.recordQueryPageInfo.totalPages = result.pages;
                this.recordQueryPageInfo.total = result.total; // 总记录数
                this.recordQueryPageInfo.startRow = result.startRow;
                this.recordQueryPageInfo.endRow = result.endRow;

                this.dispPayforID = false;

                this.deleteButton='unPayfor';
              }
            });
    this.dispAddcollecAccount = true;
    this.DisplayPayMan =false;
    this.displaySearch = 'unPayfor'
    this.hideGroup= false;

    this.showFileOperation =false;

     //切换回不分组视图
     this.groupList = false;
     this.unDisplayGroup=true;
  }

  /**
   * 切换显示列表视图,视图切换
   */
    public switchListView(currentPageNum: number = this.pageInfo.currentPageNum,
    pageSize: number = this.pageInfo.pageSize) {
    this.groupList = true;
    this.unDisplayGroup=false;

    const $ = window["$"];
    const param: TFISeacrhModel = {
    };
    $(".ibt-search-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
      if (id && id !== "") {
        if (id === "Time") {
          param[`start${id}`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`end${id}`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else if (id === 'paymentDate') {
          param[`${id}StartTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            param[id] = value;
          }
        }
      }
      if (type === 'checkbox' && item.checked) {

        param[item.name] = value;

      } else if (type === 'radio' && item.checked) {
        param[item.name] = value;
      }
    })
    this.service.listDataGroup(param,currentPageNum,pageSize).subscribe(result => {
      if (result) {
        result.forEach((item)=>{
          item.distributionsList.forEach((itemt)=>{
              itemt.isChecked = false;
              console.log(itemt)
          })
        })

        this.unGroupList = result;

       // 构建分页
        this.pageInfo.currentPageNum = result.pageNum;
        this.pageInfo.totalPages = result.pages;
        this.pageInfo.total = result.total; // 总记录数

      }
    })
    this.displaySearch = 'groupHomePage'
  }


  switchListViewChange(){
    this.groupList = false;
    this.unDisplayGroup=true;
    this.search();
  }
  /**
   * 判断是否选中函数
   * @param item 点击时目标行的数据
   */
  public checked(item) {
    if (item.isChecked) {
      const temp = _.find(this.BondsList, { isChecked: false });
      if (!temp) { // 全选重置为 true
        this.isCheckedAll = true;
      }
    } else { // 全选重置为 false
      this.isCheckedAll = false;
    }
  }
  //获取债券信息
  getbondCode() {
    const param = {
      bondCode: "",
      tradingPlace:''
    };
    param.bondCode = this.bondCodeInfo.bondCode;

    param.tradingPlace = this.bondCodeInfo.tradingPlace;
    if(param.bondCode != ''){
        this.service.getBondinfo(param).subscribe(result => {
      if (result) {
        this.bondCodeInfo.bondCode =result.bondCode,
        this.bondCodeInfo.issueName =result.issueName,
        this.bondCodeInfo.bondRate =result.bondRate,
        this.bondCodeInfo.tradingPlace =result.tradingPlace,
        this.bondCodeInfo.aInterestPayments =result.aInterestPayments,
        this.bondCodeInfo.bondValueDate =result.bondValueDate,
        this.bondCodeInfo.totalIssued =result.totalIssued,
        this.bondCodeInfo.bondInterestDate =result.bondInterestDate,
        this.bondCodeInfo.rateType =result.rateType,
        this.bondCodeInfo.applyobj =result.applyobj,
        this.bondCodeInfo.currency =result.currency,
        this.bondCodeInfo.bondName = result.bondName,
        this.bondCodeInfo.bondRating =result.bondRating,
        this.bondCodeInfo.subjectRating =result.subjectRating,
        this.bondCodeInfo.interestType = result.interestType,
        this.bondCodeInfo.currency = result.currency
      }else{
        window["swal"]("失败!", "没有查询到符合该债券代码的债券信息！", "warning");
      }
    })
    }

  }
  //删除
  deleteData() {
    let that = this;
    let checkedData = _.filter(that.BondsList, { isChecked: true });
    if(checkedData.length !=0){
      let validatePass=checkedData.find((e)=>{
        return e.o32Status == "Y"
    })
      if(validatePass){
        window["swal"]("失败!", "已下单的数据不能删除.", "warning");
      }
    if(!validatePass){
       window["swal"]({
          title: "",
          text: "确认删除吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
              distributionId: "",
              distribution: []
            };
            checkedData.forEach((e) => {
              // param.distributionId.push({distributionId :e.distributionId,userId:e.userId})
              param.distribution.push(e.distributionId);

            })
            param.distributionId = param.distribution.join()
            that.service.ckDelete(param).subscribe(result => {
              if (result) {
                if(that.deleteButton == 'homePage'){
                  that.search()
                }else if(that.deleteButton == 'unPayfor'){
                      that.recordQuery()
                }else if(that.deleteButton == 'payforMan'){
                  that.paymentManage()
                }

                window["swal"]("成功!", "删除成功.", "success");
              }
            });
            // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }else{
      window["swal"]("错误", "请选择需要删除的数据！", "warning");
    }
  }

  //删除
  groupDeleteData() {
    let that = this;
    let checkedData =[];
     this.unGroupList.forEach((item)=>{
         item.distributionsList.forEach((item)=>{
           if(item.isChecked){
             checkedData.push(item)
           }
         })

    });
    if(checkedData.length !=0){
      let validatePass=checkedData.find((e)=>{
        return e.o32Status == "Y"
    })
      if(validatePass){
        window["swal"]("失败!", "已下单的数据不能删除.", "warning");
      }
    if(!validatePass){
       window["swal"]({
          title: "",
          text: "确认删除吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
              distributionId: "",
              distribution: []
            };
            checkedData.forEach((e) => {
              // param.distributionId.push({distributionId :e.distributionId,userId:e.userId})
              param.distribution.push(e.distributionId);

            })
            param.distributionId = param.distribution.join()
            that.service.ckDelete(param).subscribe(result => {
              if (result) {
                that.switchListView()
                window["swal"]("成功!", "删除成功.", "success");
              }
            });
            // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }
  }

  //债券管理列表数据删除
  deleteBondManData(bondManage){
        let that = this;
        // const param = {
        //   distributionId: []
        // };
        // param.distributionId.push({ distributionId: bondManage.distributionId })
        // this.service.deleteBondManData(param).subscribe(result => {
        //   if (result) {
        //     window["swal"]("成功!", "", "success");
        //   }
        // });


        window["swal"]({
      title: "",
      text: "是否确定删除数据",
      type: "info",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "确认",
      cancelButtonText: "取消",
      html: true,
      closeOnConfirm: true,
      closeOnCancel: true
    }, function (isConfirm) {
      if (isConfirm) { // 确认
        const param = {
          id: []
        };
        param.id.push({ id: bondManage.id })
        that.service.deleteBondManData(param).subscribe(result => {
          if (result) {
            that.searchManageCondi()
            window["swal"]("成功!", "", "success");

          }
        });
        // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
      } else { // 取消
        // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
      }
    });
  }

  //首页列表文件删除
    deleteFile(Bonds){
      let that = this;
      // console.log(Bonds.distributionId)
      window["swal"]({
        title: "",
        text: "确定删除文件吗？",
        type: "info",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        html: true,
        closeOnConfirm: true,
        closeOnCancel: true
      }, function (isConfirm) {
        if (isConfirm) { // 确认
          const param = {
            distributionId: ''
          };
          param.distributionId=Bonds.distributionId;
          that.service.deleteFile(param).subscribe(result => {
            if (result) {
              window["swal"]("成功!", "", "success");
              that.search()
            }else{
              window["swal"]("失败!",'未上传任何文件', "error");
            }
          });
          // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
        } else { // 取消
          // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
    }

  //发起缴款
  initiatePayment(){
    let that = this;
    let checkedData = _.filter(that.BondsList, { isChecked: true });
    if(checkedData.length !=0){
        window["swal"]({
        title: "",
        text: '你已经选项了'+checkedData.length+'条数据,'+"是否进行缴款确认？",
        type: "info",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        html: true,
        closeOnConfirm: true,
        closeOnCancel: true
      }, function (isConfirm) {
        if (isConfirm) { // 确认
          const param = {
            distributionId: []
          };
          checkedData.forEach((e) => {
            param.distributionId.push({ distributionId: e.distributionId })
            // param.distributionId = e.distributionId
          })
          that.service.initiatePayment(param).subscribe(result => {
            if (result) {
              window["swal"]("成功!", "", "success");
              that.recordQuery()
            }else{
              window["swal"]("失败!", "没有找到划款账户配置", "error");
            }
          });
          // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
        } else { // 取消
          // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
    }
  }
  //缴款管理
  paymentManage(currentPageNum: number = this.paymentManagePageInfo.currentPageNum,
    pageSize: number = this.paymentManagePageInfo.pageSize){
      const $ = window["$"];
      const param: TFISeacrhModel = {
    };
    $(".ibt-search-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
      if (id && id !== "") {
        if (id === "Time") {
          param[`start${id}`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`end${id}`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else if (id === 'paymentDate') {
          param[`${id}StratTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            param[id] = value;
          }
        }
      }
      if (type === 'checkbox' && item.checked) {

        param[item.name] = value;

      } else if (type === 'radio' && item.checked) {
        param[item.name] = value;
      }
    });
    this.service.paymentManage(param,currentPageNum,pageSize).subscribe(result => {
              if (result) {
                this.BondsList = result.list;

                this.paymentManagePageInfo.currentPageNum = result.pageNum;
                this.paymentManagePageInfo.totalPages = result.pages;
                this.paymentManagePageInfo.total = result.total; // 总记录数
                this.paymentManagePageInfo.startRow = result.startRow;
                this.paymentManagePageInfo.endRow = result.endRow;

                this.DisplayPayMan = true;
                this.dispAddcollecAccount = false ;
                this.dispPayforID = true;

                this.deleteButton='payforMan'

              }
            });
            this.displaySearch = 'payforMan'
            this.hideGroup=false;
            this.showFileOperation =false;

            //切换回不分组视图
             this.groupList = false;
              this.unDisplayGroup=true;
  }
  //债券管理撤销标记
  undoMark(){
    let that = this;
    let checkedData:any = _.filter(that.bondManageList, {isChecked: true });
    if(checkedData.length !=0){
      let validatePass=checkedData.find((e)=>{
        return e.investmentPool == "1"
    })
      if(validatePass){
        window["swal"]("失败!", "不能重复撤销标记.", "warning");
      }
      if(!validatePass){
        window["swal"]({
          title: "",
          text: '你已经选项了'+checkedData.length+'条数据,'+"确认撤销标记吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
                id: []
              };
            checkedData.forEach((item) => {
          param.id.push({ id: item.id })
        })
        that.service.undoMark(param).subscribe(result => {
          if (result) {
            window["swal"]("成功!", "撤销标记成功", "success");
            that.searchManageCondi()
          }
        });
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }else{
      window["swal"]("失败", "请选择需要撤销标记的数据", "warning");
    }
  }
  //债券管理标记白名单
  tagWhiteList(){
    let that = this;
    let checkedData:any = _.filter(that.bondManageList, {isChecked: true });
    if(checkedData.length !=0){
      let validatePass=checkedData.find((e)=>{
        return e.investmentPool == "3"
    })
      if(validatePass){
        window["swal"]("失败!", "不能重复标记白名单.", "warning");
      }
      if(!validatePass){
        window["swal"]({
          title: "",
          text: '你已经选项了'+checkedData.length+'条数据,'+"确认标记白名单吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
                id: []
              };
              checkedData.forEach((item) => {
                param.id.push({ id: item.id })
              })
              that.service.tagWhiteList(param).subscribe(result => {
                if (result) {
                  window["swal"]("成功!", "标记白名单成功", "success");
                  that.searchManageCondi()
                }
              });
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }else{
      window["swal"]("失败", "请选择需要标记白名单的数据", "warning");
    }
  }

  //债券管理标记黑名单
  tagBlacklist(){
    let that = this;
    let checkedData:any = _.filter(that.bondManageList, {isChecked: true });
    if(checkedData.length !=0){
      let validatePass=checkedData.find((e)=>{
        return e.investmentPool == "2";
    })
      if(validatePass){
        window["swal"]("失败!", "不能重复标记黑名单.", "warning");
      }
      if(!validatePass){
          window["swal"]({
          title: "",
          text: '你已经选项了'+checkedData.length+'条数据,'+"确认标记黑名单吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
          id: []
        };
        checkedData.forEach((item) => {
          param.id.push({ id: item.id })
        })
        that.service.tagBlacklist(param).subscribe(result => {
          if (result) {
            window["swal"]("成功!", "标记黑名单成功", "success");
            that.searchManageCondi()
          }
        });
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }else{
      window["swal"]("失败", "请选择需要标记黑名单的数据", "warning");
    }
    // const param = {
    //       id: []
    //     };
    //     checkedData.forEach((item) => {
    //       param.id.push({ id: item.id })
    //     })
    //     that.service.tagBlacklist(param).subscribe(result => {
    //       if (result) {
    //         // window["swal"]("成功!", "出款确认成功", "success");
    //         that.searchManageCondi()
    //       }
    //     });
  }
  //通知FA
  noticeFA() {
    let that = this;
    // let checkedData =[];
    //  this.unGroupList.forEach((item)=>{
    //      item.distributionsList.forEach((item)=>{
    //        if(item.isChecked){
    //          checkedData.push(item)
    //        }
    //      })

    // });
    let checkedData = _.filter(that.BondsList, { isChecked: true });
    if (checkedData.length != 0) {
      let validatePass = checkedData.find((e)=>{
             return e.operation != null;
      })
    if (validatePass) {
        window["swal"]("失败!", "不能重复通知.", "warning");
    }
      if (!validatePass){
        window["swal"]({
          title: "",
          text: '你已经选项了'+checkedData.length+'条数据,'+"确认通知吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
              distributionId: [],
            };
            checkedData.forEach((e) => {
              param.distributionId.push({distributionId :e.distributionId})
            })
            that.service.noticeFA(param).subscribe(result => {
              if (result) {
                that.search()
                window["swal"]("成功!", "通知成功.", "success");
              }
            });
            // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }else{
      window["swal"]("错误", "请选择需要通知FA的数据！", "warning");
    }
  }

  //分组通知FA
  groupNoticeFA() {
    let that = this;
    let checkedData =[];
     this.unGroupList.forEach((item)=>{
         item.distributionsList.forEach((item)=>{
           if(item.isChecked){
             checkedData.push(item)
           }
         })

    });
    if (checkedData.length != 0) {
      let validatePass = checkedData.find((e)=>{
             return e.operation != null;
      })
    if (validatePass) {
        window["swal"]("失败!", "不能重复通知.", "warning");
    }
      if (!validatePass)  {
        window["swal"]({
          title: "",
          text: '你已经选项了'+checkedData.length+'条数据,'+"确认通知吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
            const param = {
              distributionId: [],
            };
            checkedData.forEach((e) => {
              param.distributionId.push({distributionId :e.distributionId})
            })
            that.service.noticeFA(param).subscribe(result => {
              if (result) {
                that.switchListView()
                window["swal"]("成功!", "通知成功.", "success");
              }
            });
            // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
          } else { // 取消
            // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        })
      }
    }
  }

  //展开分组列表数组
  allOpen(){
    for(let i=0;i<this.unGroupList.length;i++){
        window['$']('#ipo'+i).fadeIn()
    }
      this.changeIco=true;
      window['$']('span.glyphicon').attr('class','glyphicon glyphicon-minus-sign')
  }

  openList(i){

        window['$']('#ipo'+i).fadeToggle()
        // this.changeIco=! this.changeIco;
        if(window['$']('#os'+i).attr('class') =='glyphicon glyphicon-minus-sign'){
            window['$']('#os'+i).attr('class','glyphicon glyphicon-plus-sign')
            // this.changeIco=! this.changeIco;
        }else{
          window['$']('#os'+i).attr('class','glyphicon glyphicon-minus-sign')
          // this.changeIco=! this.changeIco;
        }
  }

  //关闭分组列表数据
  allClose(){
    for(let i=0;i<this.unGroupList.length;i++){
        window['$']('#ipo'+i).fadeOut()
    }
      this.changeIco=false;
      window['$']('span.glyphicon').attr('class','glyphicon glyphicon-plus-sign')
  }

  // 出款确认
  ckAlert() {
    let that = this;
    let checkedData = _.filter(that.BondsList, { isChecked: true });
    if(checkedData.length !=0){
      let validatePass=checkedData.find((e)=>{
        return e.cashFlowStatus == "Y"
    })
      if (validatePass) {
        window["swal"]("失败!", "已出款不能重复出款", "warning");
      }
         if (!validatePass) {
           window["swal"]({
            title: "",
            text: '你已经选项了'+checkedData.length+'条数据,'+"确认出款吗？",
            type: "info",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "确认",
            cancelButtonText: "取消",
            html: true,
            closeOnConfirm: true,
            closeOnCancel: true
          }, function (isConfirm) {
            if (isConfirm) { // 确认
              const param = {
                distributionId: []
              };
              checkedData.forEach((e) => {
                param.distributionId.push({ distributionId: e.distributionId })
                // param.distributionId = e.distributionId
              })
              that.service.ckAlert(param).subscribe(result => {
                if (result) {
                  // window["swal"]("成功!", "出款确认成功", "success");
                  console.log(result)
                  that.paymentManage()
                }
              });
              // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
            } else { // 取消
              // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
            }
          });
         }
    }else{
      window["swal"]("警告", "请选择需要出款的数据", "warning");
    }

  }

  // 承销状态确认
  underwritingAlert() {
    let that = this;
    let checkedData = _.filter(that.BondsList, { isChecked: true });

    if(checkedData.length !=0){
      let validatePass = checkedData.find((e)=>{
             return e.underwritingStatus == 'Y';
      })
    if (validatePass) {
        window["swal"]("失败!", "不能重复确认.", "warning");
    }
      if(!validatePass){
          window["swal"]({
            title: "",
            text: '你已经选项了'+checkedData.length+'条数据,'+"确认承销状态？",
            type: "info",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "确认",
            cancelButtonText: "取消",
            closeOnConfirm: true,
            closeOnCancel: true
          },
            function (isConfirm) {
              if (isConfirm) { // 确认
                let param = {
                  distributionId: []
                };
                checkedData.forEach((e) => {
                  param.distributionId.push({ distributionId: e.distributionId })
                })
                that.service.ckUnconfirm(param).subscribe(result => {
                  if (result) {
                    window["swal"]("成功!", "到账确认成功", "success");
                    that.paymentManage()
                  }
                });
                //window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
              } else { // 取消
                // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
              }
            });
      }

    }else{
      window["swal"]("警告!", "请选择需要确认的数据.", "warning");
    }





  }
  //导出Excel
  exportExcel(path, method) {

    const $ = window["$"];
    if (method === 'get') {
      // TODO 下载文件使用iframe的标签，临时解决方案。
      const iframe = $("<iframe id='downloadiframe'>");   // 定义一个iframe
      iframe.attr('style', 'display:none');
      iframe.attr('src', environment.server + path + '?token=2');
      $('body').append(iframe);                           // 将iframe放置在web中
      setTimeout("$('#downloadiframe').remove()", 5000);
    }
    if (method === 'post') {
      const options = {
        url: environment.server + path,
        data: {
          token: 2
        }
      };
      // this.downLoadFileForPost(options);
    }
  }
   //下载文件
  downloadFile(path, method,Bonds) {
    let distributionId =Bonds.distributionId
    const $ = window["$"];

    if(Bonds.attachs){
      window["swal"]({
          title: "",
          text: "确认下载文件吗？",
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确认",
          cancelButtonText: "取消",
          html: true,
          closeOnConfirm: true,
          closeOnCancel: true
        }, function (isConfirm) {
          if (isConfirm) { // 确认
             if (method === 'get') {
                // TODO 下载文件使用iframe的标签，临时解决方案。
                  const iframe = $("<iframe id='downloadiframe'>");   // 定义一个iframe
                  iframe.attr('style', 'display:none');
                  iframe.attr('src', environment.server + path + '?token=2&distributionId='+distributionId);
                  $('body').append(iframe);  // 将iframe放置在web中
                  setTimeout("$('#downloadiframe').remove()", 5000);
                }
                if (method === 'post') {
                  const options = {
                    url: environment.server + path,
                    data: {
                      token: 2
                    }
                  };
                }
            // window["swal"]("Deleted!", "Your imaginary file has been deleted.", "success");
          } else {
            // window["swal"]("警告！", "没有上传文件", "warning");
          }
        })
    }else{
      window["swal"]("警告！", "没有上传文件", "warning");
    }

  }
  //债券管理文件下载
    bondsManDownl(path, method,fileId){
        const $ = window["$"];
        if (method === 'get') {
          const iframe = $("<iframe id='downloadiframe'>");
          iframe.attr('style', 'display:none');
          iframe.attr('src', environment.server + path+'/'+fileId +'?token=2');
          $('body').append(iframe);
          setTimeout("$('#downloadiframe').remove()", 5000);
        }
    }


   //债券管理下载文件
  downloadManFile(path, method,Bonds) {
    let id =Bonds.id;
    const $ = window["$"];
    if (method === 'get') {
      // TODO 下载文件使用iframe的标签，临时解决方案。
      const iframe = $("<iframe id='downloadiframe'>");   // 定义一个iframe
      iframe.attr('style', 'display:none');
      iframe.attr('src', environment.server + path + '?token=2&id='+id);
      $('body').append(iframe);  // 将iframe放置在web中
      setTimeout("$('#downloadiframe').remove()", 5000);
    }
  }

  //文件上传changes事件
  selectedFileOnChanged(event: any) {
    this.fileName = event.target.value;
}
  //文件上传
  public uploadFile(){
    const that = this;

    const fileItem = _.last(this.uploader.queue); // 上传最后一个选择的文件

    fileItem.url = this.uploadConfig.url;
    fileItem.method = this.uploadConfig.method;
    fileItem.alias = this.uploadConfig.itemAlias;

    // 为了测试，上线要去掉
    fileItem.headers = [{name: 'token', value: sessionStorage.getItem('username')}];

    // 添加 POST 其他参数
    this.uploader.onBuildItemForm = (item, form) => {
      if (this.uploadConfig.formDatas) {
        _.forEach(this.uploadConfig.formDatas, item => {
          form.append(item.key, item.value);
          _.keys(item).forEach(function(key){
            form.append(key,item[key])
          })
        });
      }
      // 文件名称   TODO: 待优化
      if (form["filename"]) {
        form["filename"] = fileItem.file.name; // 文件名称
      } else {
        form.append('fileName', fileItem.file.name); // 文件名称
      }
    };

    fileItem.onSuccess = function (response, status, headers) {
      const retVal = JSON.parse(response);
      // 上传文件成功
      if (retVal.code + "" === "0") {
        // 上传文件后获取服务器返回的数据
        window["swal"]("导入成功", "", "success");
        // 上传成功
        that.clearFileQueue();
        window["$"]('#uploadF').val('')
        that.search();
      }else {
        // 上传文件后获取服务器返回的数据错误
        window["swal"]("导入失败", retVal.detailMsg, "error");
        window["$"]('#uploadF').val('')
      }
    };

    fileItem.upload(); // 开始上传
  }

  public clearFileQueue() {
    this.uploader.clearQueue();
  }

  //缴款申请文件上传
  // B: 初始化定义uploader变量,用来配置input中的uploader属性
    public upLoader:FileUploader = new FileUploader({
        url: "http://legiontest.zhuwenda.com:12042/otc/v1/newbond/tradeOrderFile/uploadFile",
        method: "POST",
        itemAlias: "uploadedfile",

    });
  upLoadFile(){
    let that=this;
     // 上传
     const fileItem = _.last(this.upLoader.queue); // 上传最后一个选择的文件

     if(fileItem){
        fileItem.alias = "file";

       // 添加 POST 其他参数
    this.uploader.onBuildItemForm = (item, form) => {
      if (this.uploadConfig.formDatas) {
        _.forEach(this.uploadConfig.formDatas, item => {
          form.append(item.key, item.value);
          _.keys(item).forEach(function(key){
            form.append(key,item[key])
          })
        });
      }
      // 文件名称   TODO: 待优化
      if (form["filename"]) {
        form["filename"] = fileItem.file.name; // 文件名称
      } else {
        form.append('fileName', fileItem.file.name); // 文件名称
      }
    };


        // 为了测试，上线要去掉
        fileItem.headers = [{name: 'token', value: sessionStorage.getItem('username')}];

        this.upLoader.queue[0].onSuccess = function (response, status, headers) {
            // 上传文件成功
            if (status == 200) {
                // 上传文件后获取服务器返回的数据
                let tempRes = JSON.parse(response);
                that.bondCodeInfo.attachs=tempRes.data.attachs;
                window["swal"]("成功!", "", "success");
                // console.log(that.bondCodeInfo.attachs)
            } else {
                // 上传文件后获取服务器返回的数据错误
                alert("");
            }
        };
        this.upLoader.queue[0].upload(); // 开始上传
     }
  }

  //债券管理查询
  searchManageCondi(currentPageNum: number = this.bondsManpageInfo.currentPageNum,
    pageSize: number = this.bondsManpageInfo.pageSize) {
    const $ = window["$"];
    const param = {
    };
    $(".ibt-Masearch-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
        if (id === "bondInterestDate") {
          param[`${id}StartTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            param[item.name] = value;
          }
        }

      if (type === 'checkbox' && item.checked) {

        param[item.name] = value;

      }
    });
    this.service.getBondManaInfo(param,currentPageNum,pageSize).subscribe(result => {
      if (result) {
        // 添加是否选择状态， 默认否
        _.forEach(result.list, item => {
          item.isChecked = false;
        });
        this.bondManageList = result.list;

        // 构建分页
        this.bondsManpageInfo.currentPageNum = result.pageNum;
        this.bondsManpageInfo.totalPages = result.pages;
        this.bondsManpageInfo.total = result.total; // 总记录数
        this.bondsManpageInfo.startRow = result.startRow;
        this.bondsManpageInfo.endRow = result.endRow;

      }
    })
  }

  toggleModal(id, Bonds?) {

    var formatedId = "#" + id;
    this.$(formatedId).modal('toggle');
    this.ckeckedBonds = Bonds;
    this.AddcollecAccountBonds = Bonds
  }
   togglePayforInfoModal(id, Bonds?) {

    var formatedId = "#" + id;
    this.$(formatedId).modal('toggle');
    this.service.dealPlace().subscribe(result => {
        if (result) {
          this.dealPlace = result;
            // console.log(this.dealPlace)
        }
      });

  }


  toggleBondManModal(id, Bonds?) {
    var formatedId = "#" + id;
    this.$(formatedId).modal('toggle');
    // this.bondManageEditList =  this.$.extend(true,{},Bonds);
    this.bondManageEditList =  _.clone(Bonds)
    delete this.bondManageEditList.isChecked;
  }

  toggleFileDownlModal(id, Bonds?) {
    var formatedId = "#" + id;
    // this.$(formatedId).modal('toggle');
    let param =  {
      id:''
    }
    param.id=Bonds.id;
        this.service.bondsManfileDownl(param).subscribe((result)=>{
          if(result.data){

            this.bondsManfileDownlist=result.data;
            this.$(formatedId).modal('toggle');
          }else{
            //  console.log(result)
            this.bondsManfileDownlist =[];
            window["swal"]("警告!", result.detailMsg, "warning");
          }
      })
  }
  clearList(){
    this.bondsManfileDownlist =[];
  }

  toggleuoLoadFileModal(id, Bonds?) {
    var formatedId = "#" + id;
    this.$(formatedId).modal('toggle');
    let param = {
      distributionId: Bonds.distributionId,
    };

    this.uploadConfig = {
      modalTile: "上传文件", // modal title
      title: "上传文件", // titel
      url: environment.server + "otc/v1/newbond/tradeOrderFile/upload", // url
      method: "POST", // POST OR GET
      itemAlias: "file", // file alias
      formDatas: [param] // POST 参数
    };
    this.uploadBonds = Bonds;
  }
  //债券管理编辑提交
  editSubmit(){
      let param = {};
      param = this.bondManageEditList;
      this.service.editSubmit(param).subscribe(result => {
        if (result) {
         window["swal"]("成功!", "", "success");
          this.searchManageCondi()
        }
      });
  }


  //是否加急
  submitXj(id) {

    if (window['$']('#confirmQ').val() == 'y') {
      const param = {
        distributionId: ''
      };
      param.distributionId = this.ckeckedBonds.distributionId;
      this.service.confirmQ(param).subscribe(result => {
        if (result) {
          // console.info(result);
          window["swal"]("成功!", "", "success");
          this.search()
        }
      });
    }
    this.toggleModal(id, '');

  }
  //补充承销商和收款账号
  AddcollecAccount(){
    const param = {
        distributionId: '',
        collectionAccount :'',
        underwriter:'',
      };
      param.distributionId = this.AddcollecAccountBonds.distributionId.toString()
      param.underwriter = window["$"]('#underwriter').val()
      param.collectionAccount = window["$"]('#collectionAccount').val()
      this.service.AddcollecAccount(param).subscribe(result => {
        if (result) {
          // console.info(result);
          // this.search()
          this.recordQuery()
          window["swal"]("成功!", "", "success");
        }
      });
  }
  search() {
    this.getRemittanceList(this.warpperSearchModule());
    this.dispAddcollecAccount = false;
    this.DisplayPayMan =false;
    this.dispPayforID =false;
    this.hideGroup=true;
    this.showFileOperation=true;

    this.deleteButton='homePage'

    //查询按钮显示
    this.displaySearch = 'homePage';
  }

  /**
 * [resetSearch 重置查询条件]
 */
  resetSearch() {
    window["$"](".ibt-search-input[type='text']").each(function () {
      this.value = "";
    });
    window["$"](".ibt-Masearch-input[type='text']").each(function () {
      this.value = "";
    });
    window["$"](".ibt-search-input").prop("checked", false);
    window["$"](".ibt-Masearch-input").prop("checked", false);
    window["$"]("#investmentPool option[value='']").attr("selected",true);
    window["$"]("#investmentPoolT option[value='']").attr("selected",true);
    window["$"]('#investmentPool').value='';

  }

  // 包装查询条件
  public warpperSearchModule() {
    const $ = window["$"];
    const data: TFISeacrhModel = {
    };
    $(".ibt-search-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
      if (id && id !== "") {
        if (id === "Time") {
          data[`start${id}`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          data[`end${id}`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else if (id === 'paymentDate') {
          data[`${id}StratTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          data[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            data[id] = value;
          }
        }
      }
      if (type === 'checkbox' && item.checked) {

        data[item.name] = value;

      } else if (type === 'radio' && item.checked) {
        data[item.name] = value;
      }
    });
    // if ($('#inlineCheckbox1').checked && $('#inlineCheckbox2').checked){
    //       data['o32Status'] = null;
    // }
    return data;
  }

  //历史交易
  goHistory(currentPageNum: number = this.goHistoryPageInfo.currentPageNum,
    pageSize: number = this.goHistoryPageInfo.pageSize,changePage?) {
      this.displaySearch = 'historyDeal'
      if(changePage){

      }else{
          this.DisplayHistory = !this.DisplayHistory;
      }
      this.dispAddcollecAccount =false;
    const $ = window["$"];
    const param: TFISeacrhModel = {
    };
    $(".ibt-search-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
      if (id && id !== "") {
        if (id === "Time") {
          param[`start${id}`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`end${id}`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else if (id === 'paymentDate') {
          param[`${id}StartTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            param[id] = value;
          }
        }
      }
      if (type === 'checkbox' && item.checked) {

        param[item.name] = value;

      } else if (type === 'radio' && item.checked) {
        param[item.name] = value;
      }
    })

    this.service.historicalDeal(param, currentPageNum, pageSize).subscribe(data => {
      if (data) {
        this.BondsList = data.list;
        this.goHistoryPageInfo.currentPageNum = data.pageNum;
        this.goHistoryPageInfo.totalPages = data.pages;
        this.goHistoryPageInfo.total = data.total; // 总记录数
        this.goHistoryPageInfo.startRow = data.startRow;
        this.goHistoryPageInfo.endRow = data.endRow;
      }
    });

    this.showFileOperation=false;

    //切换回不分组视图
     this.groupList = false;
     this.unDisplayGroup=true;

  }
  goBackHistory() {
    this.DisplayHistory = !this.DisplayHistory;
    this.search()
  }
  //历史交易查询
  historicalSearch() {
    const $ = window["$"];
    const param: TFISeacrhModel = {
    };
    $(".ibt-search-input").each((index, item) => {
      const $item = Util.$(item);
      const type = item.type;
      const id = item.id;
      const value = item.value;
      const daterangepicker = $item.data('daterangepicker');
      if (id && id !== "") {
        if (id === "Time") {
          param[`start${id}`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`end${id}`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";

        } else if (id === 'paymentDate') {
          param[`${id}StartTime`] = (value != null && value.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
          param[`${id}EndTime`] = (value != null && value.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
        } else {
          if (type === 'text' || type === 'select' || type === 'select-one') {
            param[id] = value;
          }
        }
      }
      if (type === 'checkbox' && item.checked) {

        param[item.name] = value;

      } else if (type === 'radio' && item.checked) {
        param[item.name] = value;
      }
    })

    this.service.historicalDeal(param).subscribe(data => {
      if (data) {
        this.BondsList = data.list;
        // console.log(data)
      }
    });
  }
  getRemittanceList(search: TFISeacrhModel, currentPageNum: number = this.pageInfo.currentPageNum,
    pageSize: number = this.pageInfo.pageSize) {
    this.service.getListData(search, currentPageNum, pageSize).subscribe(data => {
      if (data) {
        // 添加是否选择状态， 默认否
        _.forEach(data.list, item => {
          item.isChecked = false;
        });

        this.BondsList = data.list;

        // 构建分页
        this.pageInfo.currentPageNum = data.pageNum;
        this.pageInfo.totalPages = data.pages;
        this.pageInfo.total = data.total; // 总记录数
        this.pageInfo.startRow = data.startRow;
        this.pageInfo.endRow = data.endRow;
      }
    });
  }



}
