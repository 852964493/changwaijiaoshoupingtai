import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { BankRefService } from './bank-ref.service';
import { FileUploadNormalComponent } from '../purchase/file-upload-normal/file-upload-normal.component';
import { AppPaginationComponent, PaginationModel } from '../../../widgets/pagination/pagination.component';
import { environment } from '../../../../environments/environment';
import { Util } from "../../../common/util";
import * as moment from 'moment';
import * as _ from 'lodash'

@Component({
	selector: 'new-stock-bank-ref',
	templateUrl: './bank-ref.component.html',
	styleUrls: ['./bank-ref.component.scss'],
	providers: [BankRefService]
})
export class BankRefComponent implements OnInit {

	public bankRefList: Array<any>;

	// 打新信息
	public bankRef = {
		lBankrefNo: "",
		vcBank: "", // 托管行（可为空，表示关联所有银行）
		vcLeadUnderwriter: "" // 承销商
	}

	// 分页数据模型
	public pageInfo: PaginationModel = {
		currentPageNum: 1,
		pageSize: 10,
		totalPages: 1,
		total: 0,
		pagesShow: 5,
		startRow: 0,
		endRow: 0,
		pageList: [5, 10, 25, 50, 100]
	};

		// 查询条件
	public searchBody = {
		page: 1, // 页码
		pageSize: this.pageInfo.pageSize,
		underwriter: "", // 主承商
		bank: "" // 托管行
	}

	// 分页组件
	@ViewChild(AppPaginationComponent)
	public paginationComponent: AppPaginationComponent;

	public modalStatus: boolean;

	@ViewChild("modal")
	public modal: ElementRef;

	// 用于标记新增操作-false, 更新操作-true
	public isUpdate: boolean = false;


	constructor(
		private bankRefService: BankRefService
	) {
		
	}

	ngOnInit() {
		this.getBankRefList();
	}

	/**
	 * [reflesh 刷新列表]
	 * @param {[type]} event [description]
	 */
	reflesh(event?) {
		this.getBankRefList();
	}

	public openModal(lNewstockNo?): void {
		this.modalStatus = true;
		Util.$(this.modal.nativeElement).modal('show');
	}

	public closeModal(): void {
		this.modalStatus = false;
		Util.$(this.modal.nativeElement).modal('hide');
	}

	public toggleModal(): void {
		this.modalStatus = !this.modalStatus;
		Util.$(this.modal.nativeElement).modal('toggle');
	}

	/**
	 * [resetSearch 重置查询条件]
	 */
	resetSearch() {
		this.searchBody = {
			page: 1, // 页码
			pageSize: environment.pageSize,
			underwriter: "", // 主承商
			bank: "" // 托管行
		}
	}

	/**
	 * [getBankRefList 查询打新列表]
	 */
	getBankRefList() {
		// 设置查询条件页码
		this.searchBody.page = this.pageInfo.currentPageNum;
		this.searchBody.pageSize = this.pageInfo.pageSize;
		this.bankRefService.getBankRefList(this.searchBody).subscribe(data => {
			if (data) {
				this.bankRefList = _.pull(data.list, null);

				// 构建分页
				this.pageInfo.totalPages = data.pages;
				this.pageInfo.total = data.total;
				this.pageInfo.startRow = data.startRow;
				this.pageInfo.endRow = data.endRow;
			}
		});
	}

	/**
	 * [deleteBankRef 删除打新信息]
	 * @param {[type]} bankRef [{
	 *    lBankrefNo: "",
	 *    vcBank: "", // 托管行（可为空，表示关联所有银行）
	 *    vcLeadUnderwriter: "" // 承销商
	}]
	 */
	deleteBankRef(bankRef) {
		var that = this;
		window["swal"]({
			title: "提示",
			text: "是否确定删除 " + bankRef.vcBank + " 关联方信息?",
			type: "info",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "确认",
			cancelButtonText: "取消",
			closeOnConfirm: false,
			closeOnCancel: true,
      showLoaderOnConfirm: true
		},
			function(isConfirm) {
				if (isConfirm) { // 确认
					console.log("删除的对象：" + JSON.stringify(bankRef));
					that.bankRefService.deleteBankRef(bankRef).subscribe(data => {
						if (data) {
							window["swal"]("删除成功", "", "success");
							// 重新加载列表数据
							that.getBankRefList();
						}
					});
				} else { // 取消
					//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
				}
			});

	}

	/**
	 * [adBankRef 新增关联方配置信息]
	 */
	addBankRef() {
		var that = this;
		if(that.bankRef.vcBank==="" || that.bankRef.vcLeadUnderwriter===""){
			return window["swal"]("提示", "关联方信息请填写完整！", "info");
		}
		window["swal"]({
			title: "提示",
			text: "是否确定要新增关联方信息?",
			type: "info",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "确认",
			cancelButtonText: "取消",
			closeOnConfirm: false,
			closeOnCancel: false
		},
			function(isConfirm) {
				if (isConfirm) { // 确认
					console.log("新增关联方信息：" + JSON.stringify(that.bankRef));
					that.bankRefService.addBankRef(that.bankRef).subscribe(data => {
						if (data) {
							window["swal"]("新增成功", "", "success");
							that.closeModal();
							that.getBankRefList(); // 重新加载列表数据
						}
					});
				} else { // 取消
					//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
				}
			});
	}

	/**
	 * [updateBankRef 修改关联方]
	 * @param {[type]} bankRef [{
	 * 	   lBankrefNo: // 关联码
	 *     vcBank: , // 托管行（可为空，表示关联所有银行）
	 *     vcLeadUnderwriter: // 承销商
	 * }]
	 */
	updateBankRef() {
		var that = this;
		window["swal"]({
			title: "提示",
			text: "是否确定要更新关联方信息？",
			type: "info",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "确认",
			cancelButtonText: "取消",
			closeOnConfirm: false,
			closeOnCancel: true,
      showLoaderOnConfirm: true
		},
			function(isConfirm) {
				if (isConfirm) { // 确认
					that.bankRefService.updateBankRef(that.bankRef).subscribe(data => {
						if (data) {
							window["swal"]("关联方信息更新成功", "", "success");
							that.closeModal();
						}
					});
				} else { // 取消
					//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
				}
			});
	}

	/**
	 * [toggleUpdateModal 打开更新modal]
	 * @param {[type]} bankRef [description]
	 */
	toggleUpdateModal(bankRef) {
		this.isUpdate = true;
		this.bankRef = bankRef;
		this.openModal();
	}

    /**
     * [toggleAddModal 打开更新modal]
     */
	toggleAddModal() {
		this.isUpdate = false;
		// 重置
		this.bankRef = {
			lBankrefNo: "",
			vcBank: "", // 托管行（可为空，表示关联所有银行）
			vcLeadUnderwriter: "" // 承销商
		}

		this.openModal();
	}

	/**
	 * 根据页码请求查询相关配置列表数据,如果当前活动页码就是目标页码，则不进行任何查询
	 * 直接返回
	 * @param {currentPageNum}
	 */
	public pageNavigation(currentPageNum: number) {
		this.pageInfo.currentPageNum = currentPageNum;
		this.getBankRefList();
	}

	/**
	 * 改变每页显示记录数
	 * @param {pageSize}
	 */
	public pageSizeChange(pageSize: number) {
		if (pageSize !== this.pageInfo.pageSize) {
		this.pageInfo.pageSize = pageSize;
		this.pageInfo.currentPageNum = 1;
		this.getBankRefList();
		}
	}

}
