import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankRefComponent } from './bank-ref.component';

describe('BankRefComponent', () => {
  let component: BankRefComponent;
  let fixture: ComponentFixture<BankRefComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankRefComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
