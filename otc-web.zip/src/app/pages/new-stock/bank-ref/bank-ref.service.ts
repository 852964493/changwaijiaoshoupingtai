import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class BankRefService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [getBankRefList 查询关联方列表]
	 * @param {[type]} param [{
	 *     page:, // 
	 *     pageSize:, // 
	 *     underwriter:, // 主承商
	 *     bank: // 托管行	
	 * }]
	 */
	getBankRefList(param) {
		let postBody = param;
		return this.httpClient.get('otc/v1/Newstock/BankRef', postBody, {
			isAuthHttp: false
		});
	}


	/**
	 * [addBankRef 新增关联方配置信息]
	 * @param {[type]} bankRef [{
	 *     vcBank: , // 托管行（可为空，表示关联所有银行）
	 *     vcLeadUnderwriter: // 承销商
	 * }]
	 */
	addBankRef(bankRef){
		let postBody = {
			lBankrefNo:null,
			vcBank: bankRef.vcBank,
			vcLeadUnderwriter: bankRef.vcLeadUnderwriter
		}
		return this.httpClient.post('otc/v1/Newstock/BankRef', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [updateBankRef 修改关联方]
	 * @param {[type]} bankRef [{
	 *     lBankrefNo: // 关联码
	 *     vcBank: , // 托管行（可为空，表示关联所有银行）
	 *     vcLeadUnderwriter: // 承销商
	 * }]
	 */
	updateBankRef(bankRef){
		let postBody = {
			lBankrefNo: bankRef.lBankrefNo,
			vcBank: bankRef.vcBank,
			vcLeadUnderwriter: bankRef.vcLeadUnderwriter
		}
		return this.httpClient.post('otc/v1/Newstock/BankRef/' + bankRef.lBankrefNo, postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [deleteBankRef 删除指定的关联方配置信息]
	 * @param {[type]} bankRef [{
	 *     lBankrefNo: // 关联码
	 *     vcBank: , // 托管行（可为空，表示关联所有银行）
	 *     vcLeadUnderwriter: // 承销商
	 * }]
	 */
	deleteBankRef(bankRef){
		let postBody = {
		}
		return this.httpClient.delete('otc/v1/Newstock/BankRef/' + bankRef.lBankrefNo, postBody, {
			isAuthHttp: false
		});
	}

}
