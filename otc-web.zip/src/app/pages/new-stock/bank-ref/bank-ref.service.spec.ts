import { TestBed, inject } from '@angular/core/testing';

import { BankRefService } from './bank-ref.service';

describe('BankRefService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [BankRefService]
		});
	});

	it('should ...', inject([BankRefService], (service: BankRefService) => {
		expect(service).toBeTruthy();
	}));
});
