import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PurchaseComponent } from './purchase/purchase.component';
import { FundDXComponent } from './fund-dx/fund-dx.component';
import { ListedComponent } from './listed/listed.component';
import { ZQComponent } from './zq/zq.component';
import { LockQueryComponent } from './lock-query/lock-query.component';
import { AllotmentComponent } from './allotment/allotment.component';
import { BankRefComponent } from './bank-ref/bank-ref.component';
const routes: Routes = [
	{
		path: '',
		redirectTo: 'purchase',
		pathMatch: 'full'
	},{
		path: "purchase",
		component: PurchaseComponent
	},{
		path: "zq",
		component: ZQComponent
	},{
		path: "dx",
		component: FundDXComponent
	},{
		path: "listed",
		component: ListedComponent
	},{
		path: "lockQuery",
		component: LockQueryComponent
	},{
		path: "allotment",
		component: AllotmentComponent
	},{
		path: "bankRef",
		component: BankRefComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class NewStockRoutingModule { }
