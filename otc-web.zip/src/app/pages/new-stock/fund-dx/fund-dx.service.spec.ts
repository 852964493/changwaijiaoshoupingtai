import { TestBed, inject } from '@angular/core/testing';

import { FundDXService } from './fund-dx.service';

describe('FundDXService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [FundDXService]
		});
	});

	it('should ...', inject([FundDXService], (service: FundDXService) => {
		expect(service).toBeTruthy();
	}));
});
