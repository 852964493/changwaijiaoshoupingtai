import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FundDXService } from './fund-dx.service';
import { FileUploadNormalComponent } from '../purchase/file-upload-normal/file-upload-normal.component';
import { AppPaginationComponent, PaginationModel } from '../../../widgets/pagination/pagination.component';
import { environment } from '../../../../environments/environment';
import { Util } from "../../../common/util";
import * as moment from 'moment';
import * as _ from 'lodash'

@Component({
	selector: 'new-stock-fund-dx',
	templateUrl: './fund-dx.component.html',
	styleUrls: ['./fund-dx.component.scss'],
	providers: [FundDXService]
})
export class FundDXComponent implements OnInit {

	public iPOInfoList: Array<any>;

	// add - 新增， update - 修改
	public type = "add";

	// 打新信息
	public iPOInfo:any = {
		fundcode: "",
		fundname: "",
		isnewipo: ""
	}

	// 查询条件
	public searchBody = {
		vcFundCode: "",
		vcFundName: "",
		page: 1, // 页码
		pageSize: environment.pageSize
	}

	// 文件上传modal配置信息
	public fileUploadModal = {
		modalTile: "", // modal title
		title: "", // titel
		url: "", // url
		method: "", // POST OR GET
		itemAlias: "", // file alias
		formDatas: [] // POST 参数
	};

	// 分页数据模型
	public pageInfo: PaginationModel = {
		currentPageNum: 1,
		pageSize: 10,
		totalPages: 1,
		total: 0,
		pagesShow: 5,
		startRow: 0,
		endRow: 0,
		pageList: [5, 10, 25, 50, 100]
	};

	// 分页组件
	@ViewChild(AppPaginationComponent)
	public paginationComponent: AppPaginationComponent;

	// 导入配售对象
	@ViewChild(FileUploadNormalComponent)
	private fileUploadNormalComponent: FileUploadNormalComponent;


	constructor(
		private fundDXService: FundDXService
	) {
	}

	ngOnInit() {
		this.getIPOInfo();
	}

	public resetSearch() {
		this.searchBody = {
			vcFundCode: "",
			vcFundName: "",
			page: this.pageInfo.currentPageNum, // 当前页码
			pageSize: environment.pageSize
		}
	}

	/**
	 * [reflesh 刷新列表]
	 * @param {[type]} event [description]
	 */
	reflesh(event?) {
		this.getIPOInfo();
	}

	/**
	 * [toggleModal 新增修改询价]
	 * @param {[type]} type        [add-新增，update-修改]
	 * @param {[type]} iPOInfo [大新信息]
	 */
	public toggleModal(type,iPOInfo?) {
		this.type = type;
		if(iPOInfo) {
			this.iPOInfo = iPOInfo;
		}
		Util.$('#dxModal').modal({
			keyboard: false,
			backdrop: false
		  });
		//Util.$("#reservation").daterangepicker();
	}

	/**
	 * [toggleRWModalOpen 导入]
	 */
	toggleDRModalOpen() {
		this.fileUploadModal = {
			modalTile: "导入打新信息",
			title: "请选择上传打新信息",
			url: environment.server+"otc/v1/Newstock/IPOInfo/IPOList",
			method: "POST",
			itemAlias: "file",
			formDatas: []
		};

		this.fileUploadNormalComponent.openModal();
	}

	/**
	 * [getIPOInfo 查询打新列表]
	 */
	getIPOInfo() {
		// 设置查询条件页码
		this.searchBody.page = this.pageInfo.currentPageNum;
		this.searchBody.pageSize = this.pageInfo.pageSize;
		this.fundDXService.getIPOInfo(this.searchBody).subscribe(data => {
			if(data){
				this.iPOInfoList = _.pull(data.list,null);

				// 构建分页
				this.pageInfo.totalPages = data.pages;
				this.pageInfo.total = data.total;
				this.pageInfo.startRow = data.startRow;
				this.pageInfo.endRow = data.endRow;
			}
		});
	}

	/**
	 * [deleteIPOInfo 删除打新信息]
	 * @param {[type]} iPOInfo [{
	 *    fundcode：
	 *    fundname：
	 *    isnewipo：                   
	 * }]
	 */
	deleteIPOInfo(iPOInfo) {
		var that = this; 
		window["swal"]({
			title: "提示",
			text: "是否确定删除 " + iPOInfo.fundname + " 打新信息?",
			type: "info",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "确认",
			cancelButtonText: "取消",
			closeOnConfirm: false,
			closeOnCancel: true,
            showLoaderOnConfirm: true
		},
		function(isConfirm) {
			if (isConfirm) { // 确认
				console.log("删除的对象：" + JSON.stringify(iPOInfo));
				that.fundDXService.deleteIPOInfo(iPOInfo.fundcode).subscribe(data => {
					if(data) {
						window["swal"]("删除成功", "", "success");
						that.searchBody.page = 1;
						that.getIPOInfo(); // 重新加载列表数据
					}
				});
			} else { //	取消
				// window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
			}
		});

	}

	/**
	 * [changeStatus 更新询价状态]
	 * @param {[type]} iPOInfo [{
	 *    fundcode：
	 *    fundname：
	 *    isnewipo：                   
	 * }]
	 */
	addOrUpateIPOInfo(iPOInfo) {
		var that = this;
		if(iPOInfo.fundcode === ""){
			return window["swal"]("提示", "基金代码不能为空！", "info");
		}
		if(iPOInfo.fundname === ""){
			return window["swal"]("提示", "基金名称不能为空！", "info");
		}
		if(iPOInfo.isnewipo === ""){
			return window["swal"]("提示", "是否可参与询价不能为空！", "info");
		}
		if (this.type == "update") {
			window["swal"]({
				title: "提示",
				text: "是否要更新询价信息？",
				type: "info",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "确认",
				cancelButtonText: "取消",
				closeOnConfirm: false,
				closeOnCancel: true,
                showLoaderOnConfirm: true
			},
				function(isConfirm) {
					if (isConfirm) { // 确认
						that.fundDXService.addORUpdateIPOInfo(iPOInfo).subscribe(data => {
							if(data) {
								window["swal"]("更新成功", "", "success");
								that.searchBody.page = 1;
								that.getIPOInfo(); // 重新加载列表数据
								that.closeDxModal();
							}
						});
					} else { // 取消
						//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
					}
				});

		} else {
			window["swal"]({
				title: "",
				text: "是否确定要新增打新配置信息?",
				type: "info",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "确认",
				cancelButtonText: "取消",
				closeOnConfirm: false,
				closeOnCancel: true,
				showLoaderOnConfirm: true
			},
				function(isConfirm) {
					if (isConfirm) { // 确认
						console.log("新增询价信息：" + JSON.stringify(iPOInfo));
						that.fundDXService.addORUpdateIPOInfo(iPOInfo).subscribe(data => {
							if(data) {
								window["swal"]("新增成功", "", "success");
								that.searchBody.page = 1;
								that.getIPOInfo(); // 重新加载列表数据
								that.closeDxModal();
							}
						});
					} else { // 取消
						//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
					}
				});

		}

	}

	public closeDxModal(){
		window["$"]("#dxModal").modal('hide');
		this.iPOInfo = {};
	}

	/**
	 * 根据页码请求查询相关配置列表数据,如果当前活动页码就是目标页码，则不进行任何查询
	 * 直接返回
	 * @param {currentPageNum}
	 */
	public pageNavigation(currentPageNum: number) {
		this.pageInfo.currentPageNum = currentPageNum;
		this.getIPOInfo();
	}

	/**
	 * 改变每页显示记录数
	 * @param {pageSize}
	 */
	public pageSizeChange(pageSize: number) {
		if (pageSize !== this.pageInfo.pageSize) {
		this.pageInfo.pageSize = pageSize;
		this.pageInfo.currentPageNum = 1;
		this.getIPOInfo();
		}
	}

}
