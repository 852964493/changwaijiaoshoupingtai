import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class FundDXService {
	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [getIPOInfo 查询打新列表]
	 * @param {[type]} param [分页]
	 */
	getIPOInfo(page) {
		let postBody = page
		return this.httpClient.get('otc/v1/Newstock/IPOInfo', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * 暂时不用
	 * [updateIPOInfo 更新询价状态]
	 * @param {[type]} iPOInfo [{
	 *    fundcode：
	 *    fundname：
	 *    isnewipo：                   
	 * }]
	 */
	updateIPOInfo(iPOInfo) {
		let postBody = {
			fundname: iPOInfo.fundname,
			isnewipo: iPOInfo.isnewipo
		}
		return this.httpClient.put('otc/v1/Newstock/IPOInfo/' + iPOInfo.fundcode, postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [addORUpdateIPOInfo 新增或更新询价，fundcode为空时新增，否则更新]
	 * @param {[type]} iPOInfo [{
	 *    fundcode：
	 *    fundname：
	 *    isnewipo：                   
	 * }]
	 */
	addORUpdateIPOInfo(iPOInfo) {
		let postBody = {
			fundcode: iPOInfo.fundcode,
			fundname: iPOInfo.fundname,
			isnewipo: iPOInfo.isnewipo
		}
		return this.httpClient.post('otc/v1/Newstock/IPOInfo', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [deleteIPOInfo 删除询价]
	 * @param {[type]} fundcode [基金编码]
	 */
	deleteIPOInfo(fundcode){
		let postBody = {
		}
		return this.httpClient.delete('otc/v1/Newstock/IPOInfo/' + fundcode, postBody, {
			isAuthHttp: false
		});
	}

}
