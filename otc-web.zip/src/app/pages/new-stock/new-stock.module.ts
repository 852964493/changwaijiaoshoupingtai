import {NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FileUploadModule} from 'ng2-file-upload';
import {NewStockRoutingModule} from './new-stock-routing.module';
import {PurchaseComponent} from './purchase/purchase.component';
import {WriteInquiryComponent} from './purchase/write-inquiry/write-inquiry.component';
import {IPOListComponent} from './purchase/IPO-list/IPO-list.component';
import {FileUploadNormalComponent} from './purchase/file-upload-normal/file-upload-normal.component';
import {InquiryStatusComponent} from './purchase/inquiry-status/inquiry-status.component';
import {InquiryTempComponent} from './purchase/inquiry-template/inquiry-template.component';
import {PurchaseListComponent} from './purchase/purchase-list/purchase-list.component';
import {PaymentComponent} from './purchase/payment-list/payment-list.component';
import {FundDXComponent} from './fund-dx/fund-dx.component';
import {AllotmentComponent} from './allotment/allotment.component';
import {ConsultingPriceComponent} from './purchase/consulting-price/consulting-price.component'
import {ListedComponent} from './listed/listed.component';
import {LockQueryComponent} from './lock-query/lock-query.component';
import {ZQComponent} from './zq/zq.component';
import {ZQListComponent} from './zq/zq-list/zq-list.component';
import {ZQPaymentComponent} from './zq/zq-payment/zq-payment.component';
import {AlterationComponent} from './zq/alteration/alteration.component';
import {AppPaginationModule} from '../../widgets/pagination/pagination.module';
import {BankRefComponent} from './bank-ref/bank-ref.component';
import {FormsModule} from "@angular/forms";

@NgModule({
  imports: [
    CommonModule,
    NewStockRoutingModule,
    FormsModule,
    FileUploadModule,
    AppPaginationModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  declarations: [PurchaseComponent, ConsultingPriceComponent, WriteInquiryComponent, ListedComponent, LockQueryComponent, ZQComponent, IPOListComponent, FileUploadNormalComponent, InquiryStatusComponent, PurchaseListComponent, FundDXComponent, InquiryTempComponent, AllotmentComponent, PaymentComponent, ZQListComponent, AlterationComponent, BankRefComponent, ZQPaymentComponent]
})
export class NewStockModule {
}
