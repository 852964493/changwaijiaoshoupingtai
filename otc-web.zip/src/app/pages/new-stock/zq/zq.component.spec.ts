import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZQComponent } from './zq.component';

describe('ZQComponent', () => {
  let component: ZQComponent;
  let fixture: ComponentFixture<ZQComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZQComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZQComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
