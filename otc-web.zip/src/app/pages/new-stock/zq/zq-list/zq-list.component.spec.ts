import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZQListComponent } from './zq-list.component';

describe('ZQListComponent', () => {
  let component: ZQListComponent;
  let fixture: ComponentFixture<ZQListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZQListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZQListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
