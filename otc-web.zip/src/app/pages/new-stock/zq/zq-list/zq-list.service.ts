import {Injectable} from '@angular/core';
import {HttpClientService} from '../../../../services/http-client.service';
import {Observable} from "rxjs/Observable";
import {environment} from "../../../../../environments/environment";
@Injectable()
export class ZQListService {

  constructor(public httpClient: HttpClientService) {
  }

  /**
   * [getRemittanceList 会计划款列表]
   * @param {[type]} param [{
	 *		hkInstructionStatus：//划款名称
	 *		zqDateStart: //配售公告日期开始
	 *		zqDateEnd: //配售公告日期结束
	 *		jkDateStart: //缴款日开始
	 *		jkDateEnd: //缴款日结束
	 *    vcFundCode：// 基金代码
	 *    vcNewstockId：// 证券代码
	 * 		vcNewstockName: //证券名称
	 *    page:// 页码
	 *    pageSize: // 每页分页记录数
	 *    type: // 列表类型（1：中签管理，2：已缴款 3：申购中签管理）
	 *    traceDate: // 查询日期（空表示当天）
	 *    isHisData: // 是否历史交易（true：历史，false：当前）
	 * }]
   */
  getRemittanceList(param, page?: string | number, pageSize?: string | number): Observable<any> {
    if (page != null) {
      param.page = page;
    } else {
      param.page = 0;
    }
    if (pageSize != null) {
      param.pageSize = pageSize;
    } else {
      param.pageSize = 0;
    }

    // console.log(JSON.stringify(postBody))
    return this.httpClient.get('otc/v1/Newstock/RemittanceList', param, {
      isAuthHttp: false
    });
  }

  /**
   * 手工到账操作
   * param [{
	 * 		pmkyList: //主键
	 * 		action: //提交的到账状态
	 * }]
   */
  manualTransferredConfirm(param): Observable<any> {
    return this.httpClient.put('otc/v1/Newstock/DZ?' + 'pmkyList=' + param.pmkyList + '&action=' + param.action, {
      isAuthHttp: false
    });
  }

  /**
   * 标记中签操作
   */
  markZQHandle(param): Observable<any> {
    return this.httpClient.put('otc/v1/Newstock/ZQFlag', param.lConfirmNo, {
      isAuthHttp: false,
      headers:[{'Content-Type':'application/json'}]
    });
  }
}
