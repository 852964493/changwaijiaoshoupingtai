import { TestBed, inject } from '@angular/core/testing';

import { ZQListService } from './zq-list.service';

describe('ZQListService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [ZQListService]
		});
	});

	it('should ...', inject([ZQListService], (service: ZQListService) => {
		expect(service).toBeTruthy();
	}));
});
