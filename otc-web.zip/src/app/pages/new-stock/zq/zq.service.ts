import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';
import { environment } from "../../../../environments/environment"
@Injectable()
export class ZQService {

	constructor(
		public httpClient: HttpClientService
	) { }
}