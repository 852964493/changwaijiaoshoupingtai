import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZQPaymentComponent } from './zq-payment.component';

describe('ZQPaymentComponent', () => {
  let component: ZQPaymentComponent;
  let fixture: ComponentFixture<ZQPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZQPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZQPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
