import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';

@Injectable()
export class ZQPaymentService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [transferMoney 发起确认]
	 * @param {[type]} param [[{
	 *    lNewstockNo:
	 *    vcFundCode":
	 * }]]]
	 */
	transferMoney(param,opt?){
		let postBody = param;
		return this.httpClient.post(`otc/v1/Newstock/TransferMoney?check=${opt.check}&recover=${opt.recover}`, postBody, {
			isAuthHttp: false,
			isReturnOriginal:true,
			headers:[{'Content-Type':'application/json'}]
		});
	}

}
