import { Component, ElementRef, Input, OnInit, ViewChild, Injectable, Output, EventEmitter } from '@angular/core';
import { AlterationService } from "./alteration.service";
import { Util } from "../../../../common/util";
import * as _ from 'lodash'


/**
 * 中签管理-变更匹配
 */
@Component({
  selector: 'new-stock-zq-alteration',
  templateUrl: './alteration.component.html',
  styleUrls: ['./alteration.component.scss'],
  providers: [AlterationService]
})
export class AlterationComponent implements OnInit {

  // O3中签列表
  public O3DetailList: Array<any>;
  // 要做变更的基金实例对象
  public remittance: any = {};

  // 是否需要刷新父组件
  public needReflesh: boolean = false;

  @Output()
  needRefleshUpper: EventEmitter<boolean> = new EventEmitter<boolean>();

  public modalStatus: boolean;

  @ViewChild("modal")
  public modal: ElementRef;

  constructor(public alterationService: AlterationService) {

  }


  ngOnInit() {
  }

  /**
   * [init 初始化页面数据]
   * @param {[type]} remittance [实例对象]
   */
  init(remittance) {
    this.remittance = remittance;
    this.getO3Detail({ fundCode: remittance.vcFundCode, stockId: remittance.vcNewstockId });
  }

  public openModal(): void {
    this.modalStatus = true;
    Util.$(this.modal.nativeElement).modal('show');
  }

  public closeModal(): void {
    this.needRefleshUpper.emit(this.needReflesh); // 关闭后触发上层刷新事件
    this.modalStatus = false;
    Util.$(this.modal.nativeElement).modal('hide');
  }

  public toggleModal(): void {
    this.modalStatus = !this.modalStatus;
    Util.$(this.modal.nativeElement).modal('toggle');
  }

  /**
   * [getO3Detail 获得O3中签数据]
   * @param {[type]} param [{
   *      fundCode: // 基金代码
   *      stockId: // 证券代码
   * }]
   */
  public getO3Detail(param) {
    this.alterationService.getO3Detail(param).subscribe(data => {
      if (data) {
        this.O3DetailList = data;
        _.forEach(this.O3DetailList, function(O3Detail) { // 添加选择状态
          O3Detail.isChecked = false;
        })
      }
    });
  }

  /**
   * [updateMatch 变更匹配中签数据]
   * @param {[type]} param [{
   *     detailNo: // 匹配数据主键id
   *     fundCode: // 基金代码
   *     stockId: // 证券代码
   * }]
   */
  public updateMatch() {
    var that = this;
    // 获得变更匹配的数据，O3
    var checkedO3Detail = _.find(this.O3DetailList, { isChecked: true });

    if (checkedO3Detail) { // 有选择数据
      window["swal"]({
        title: "",
        text: "是否进行变更匹配?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        closeOnConfirm: false,
        closeOnCancel: true,
      showLoaderOnConfirm: true
      },
        function(isConfirm) {
          if (isConfirm) {
            var param = {
              lConfirmNo: checkedO3Detail.lConfirmNo, // 确认编号
              pmkyNum: checkedO3Detail.vcFundCode, // 基金代码
            }
            
            that.alterationService.updateMatch(param).subscribe(data => {
              console.log("变更匹配更新返回数据：" + data);
              if (data) {
                that.needReflesh = true; // 需刷新父组件
                window["swal"]("提示", "变更匹配更新成功!", "success");
                that.closeModal();
              }
            });
          } else {
            //window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
          }
        });
    } else { // 没选择
      window["swal"]("", "请选择一笔中签数据再做变更匹配", "info");
    }


  }

  /**
   * [checked 列表选择状态]
   * @param {[type]} O3Detail [O3中签实例]
   */
  checked(O3Detail) {
    if (O3Detail.isChecked) {
      _.forEach(this.O3DetailList, data => { // 单选控制
        data.isChecked = false;
      })

      O3Detail.isChecked = true;
    }
  }

}
