import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { Observable } from "rxjs/Observable";

@Injectable()
export class AlterationService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [getO3Detail 根据基金代码和证券代码查询o3中签数据]
	 * @param {[type]} param [{
	 *      fundCode: // 基金代码
	 *      stockId: // 证券代码
	 * }]
	 */
	getO3Detail(param){
		var postBody = {
			vcFundCode: param.fundCode,
			vcNewstockId: param.stockId
		}

		return this.httpClient.get('otc/v1/Newstock/O3Detail', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [updateMatch 变更匹配中签数据]
	 * @param {[type]} param [{
	 *    detailNo: // 匹配数据主键id
	 *    fundCode: // 基金代码
	 *    stockId: // 证券代码
	 * }}]
	 */
	updateMatch(param){
		return this.httpClient.put('otc/v1/Newstock/UpdateMatch?'+'pmkyNum=' + param.pmkyNum + "&lConfirmNo=" + param.lConfirmNo, {
			isAuthHttp: false
		});
	}
}
