import { TestBed, inject } from '@angular/core/testing';

import { ZQService } from './zq.service';

describe('ZQService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [ZQService]
		});
	});

	it('should ...', inject([ZQService], (service: ZQService) => {
		expect(service).toBeTruthy();
	}));
});
