import { Component, ElementRef, Input, OnInit, ViewChild, Injectable } from '@angular/core';
import { InquiryStatusService } from "./inquiry-status.service";
import { Util } from "../../../../common/util";
import * as _ from 'lodash'


/**
 * 新股更新下一处理状态
 */
@Component({
  selector: 'new-stock-purchase-inquiry-status',
  templateUrl: './inquiry-status.component.html',
  styleUrls: ['./inquiry-status.component.scss'],
  providers: [InquiryStatusService]
})
export class InquiryStatusComponent implements OnInit {

  @Input()
  // {
  //   lNewstockNo: "", // 实例Id
  //   vcNewstockStatus: "", // 当前业务状态
  //   checkWorkItem: "", // 是否校验待办
  //   currEditor: "", // 当前办理人
  //   nextEditors: "", // 下一办理人
  //   vcNextStatus:"" // 下一状态
  // };
  public parameter: any;

  public modalStatus: boolean;

  // 选择的状态
  public selStatus = "";
  // 状态选项
  public statusOption = [
      {
        value: "1",
        name: "发起询价"
      },{
        value: "2",
        name: "导入询价数据"
      },{
        value: "3",
        name: "基金经理确认"
      },{
        value: "4",
        name: "风控审核"
      },{
        value: "5",
        name: "交易员执行询价"
      },{
        value: "6",
        name: "确认入围基金"
      },{
        value: "7",
        name: "基金经理下达申购"
      },{
        value: "8",
        name: "交易员执行申购"
      },{
        value: "9",
        name: "确认申购信息"
      },{
        value: "10",
        name: "导入中签数据"
      },{
        value: "11",
        name: "会计划款"
      },{
        value: "12",
        name: "缴款确认"
      },
  ];

  @ViewChild("modal")
  public modal: ElementRef;

  constructor(public inquiryStatusService: InquiryStatusService) {

  }

  ngOnInit() {
  }

  /**
   * [updateStatus 更新状态]
   */
  public updateStatus(){
    this.parameter.vcNextStatus = this.selStatus;
    console.log("更新下一处理状态：" + JSON.stringify(this.parameter));
    this.inquiryStatusService.updateStatus(this.parameter).subscribe(data =>{
      if(data){
        alert("更新成功！");
      }
    })
  }

  public openModal(): void {
    this.modalStatus = true;
    Util.$(this.modal.nativeElement).modal('show');
  }

  public closeModal(): void {
    this.modalStatus = false;
    Util.$(this.modal.nativeElement).modal('hide');
  }

  public toggleModal(): void {
    this.modalStatus = !this.modalStatus;
    Util.$(this.modal.nativeElement).modal('toggle');
  }

}
