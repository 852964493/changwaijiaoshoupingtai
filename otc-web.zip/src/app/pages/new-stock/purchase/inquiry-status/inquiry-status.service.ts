import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { Observable } from "rxjs/Observable";

@Injectable()
export class InquiryStatusService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [newstockInfoList 新股列表]
	 * @param {[type]} parameter [参数]
	 * {
		lNewstockNo: "", // 实例Id
 		vcNewstockStatus: "", // 当前业务状态
 		checkWorkItem: "", // 是否校验待办
		currEditor: "", // 当前办理人
		nextEditors: "", // 下一办理人
		vcNextStatus:"" // 下一状态
		};
	 */
	updateStatus(parameter) {
		let postBody = {}
		// otc/v1/Newstock/Status/1000270?vcNewstockStatus=2&checkWorkItem&currEditor&nextEditors&vcNextStatus=3
		return this.httpClient.put('otc/v1/Newstock/Status/' + parameter.lNewstockNo + '?vcNewstockStatus=' + parameter.vcNewstockStatus + '&checkWorkItem=' + parameter.checkWorkItem + '&currEditor=' + parameter.currEditor + '&nextEditors=' + parameter.nextEditors + '&vcNextStatus=' + parameter.vcNextStatus, postBody, {
			isAuthHttp: false
		});
	}
}
