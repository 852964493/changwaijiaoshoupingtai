import {Injectable} from '@angular/core';
import {HttpClientService} from '../../../../services/http-client.service';
import {Observable} from "rxjs/Observable";

@Injectable()
export class WriteInquiryService {

  constructor(public httpClient: HttpClientService) {
  }


  // 获取股票下拉
  public getStockSelectData(param): Observable<any> {
    return this.httpClient.get("otc/v1/trd/wind/newstock", param, {
      isAuthHttp: false
    });
  }

  // 获取新股信息
  public getNewstockInfo(param): Observable<any> {
    return this.httpClient.get("otc/v1/Newstock/NewstockInfo/" + param, null, {
      isAuthHttp: false
    });
  }

  // 获取基金列表
  public getFundList(param): Observable<any> {
    return this.httpClient.get("otc/v1/Newstock/FundList", param, {
      isAuthHttp: false
    });
  }

  // 撤销
  public deleteInquiryList(param): Observable<any> {
    return this.httpClient.delete("otc/v1/Newstock/deleteinquirylist", param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * [updateNewStock 更新询价信息]
   * @param {[type]} param [新股数据模型]
   */
  updateNewStock(param) { // TODO
    return this.httpClient.put('otc/v1/Newstock/' + param.lNewstockNo, param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  saveAndSubmit(param) {
    return this.httpClient.post('otc/v1/Newstock/saveAndCommitNewstock', param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }
}
