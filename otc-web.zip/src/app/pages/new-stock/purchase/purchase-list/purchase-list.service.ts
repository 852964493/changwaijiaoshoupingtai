import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { Observable } from "rxjs/Observable";
import { environment } from "../../../../../environments/environment"


@Injectable()
export class PurchaseListService {

      constructor(
            public httpClient: HttpClientService
      ) { }

      /**
       * [getNewstockList 网下新股申购（列表）]
       * @param {[type]} param [
       *     vcNewstockId: "", // 证券代码
       *     vcNewstockStatus: "", // 状态
       *     page: "" // 页码
       *     }]
       */
      getNewstockList(param) {
             let postBody = {
                  vcNewstockId: param.vcNewstockId,
                  vcNewstockStatus: param.vcNewstockStatus,
                  page: param.page,
                  pageSize: environment.pageSize,
                  type: "2" // 列表类型（1，询价；2、申购）
            }
            return this.httpClient.get('otc/v1/Newstock', postBody, {
                  isAuthHttp: false
            });
      }

      /**
       * [getSGList 申购明细列表]
       * @param {[type]} param [查询条件{
       *    page: "1",
       *    pageSize: environment.pageSize,
       *    vcOperaterId: "",
       *    vcFundmrgId: ""
       *    }]
       * @param {[type]} lNewstockNo [实例Id]
       */
      getSGList(param,lNewstockNo) {
            let postBody = {
              page:  param.page,
              pageSize: param.pageSize
              // vcOperaterId: param.vcOperaterId,
              // vcFundmrgId: param.vcFundmrgId
            }
            return this.httpClient.get('otc/v1/Newstock/SGList/' + lNewstockNo, postBody, {
                  isAuthHttp: false
            });
      }

      /**
       * [getZQList 中签明细列表]
       * @param {[type]} param [查询条件{
       *    page: "1",
       *    pageSize: environment.pageSize,
       *    vcOperaterId: "",
       *    vcFundmrgId: ""
       *    }]
       * @param {[type]} lNewstockNo [实例Id]
       */
      getZQList(param,lNewstockNo){
            let postBody = {
                  page:  param.page,
                  pageSize: param.pageSize,
                  vcOperaterId: param.vcOperaterId,
                  vcFundmrgId: param.vcFundmrgId
            }
            return this.httpClient.get('otc/v1/Newstock/ZQList/' + lNewstockNo, postBody, {
                  isAuthHttp: false
            });
      }

      /**
       * [initSG 初始化申购数据]
       * @param {[type]} param [{
       *     lNewstockNo:  // 实例Id
       * }]
       */
      initSG(param){
            let postBody = {}

            return this.httpClient.put('otc/v1/Newstock/SGList/' + param.lNewstockNo, postBody, {
                  isAuthHttp: false
            });
      }

      /**
       * [getStatus 获取业务状态字典]
       * @param {[type]} type [阶段分类（1、询价；2、申购、3、其他）]
       */
      getStatusDir(type){
             let postBody = {}

            return this.httpClient.get('otc/v1/Newstock/Status', postBody, {
                  isAuthHttp: false
            });
      }
      

}