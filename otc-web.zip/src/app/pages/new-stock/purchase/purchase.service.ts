import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';

@Injectable()
export class PurchaseService {

	constructor(
		public httpClient: HttpClientService
	) { }
}
