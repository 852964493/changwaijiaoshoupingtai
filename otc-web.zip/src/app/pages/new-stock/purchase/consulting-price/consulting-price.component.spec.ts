import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultingPriceComponent } from './consulting-price.component';

describe('ConsultingPriceComponent', () => {
  let component: ConsultingPriceComponent;
  let fixture: ComponentFixture<ConsultingPriceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultingPriceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultingPriceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
