import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { Observable } from "rxjs/Observable";

@Injectable()
export class ConsultingPriceService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [getNewstockInfoList 新股列表]
	 * @param {[type]} param [{
	 *    pageSize: 0,
	 *    page: 0
	 * }]
	 */
	public getNewstockInfoList(param) {
		let postBody = param;
		return this.httpClient.get('otc/v1/trd/wind/newstock', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [getNewstockInfo 根据证券代码获取证券信息]
	 * @param {[type]} vcNewstockId [证券代码]
	 */
	public getNewstockInfo(vcNewstockId) {
		let postBody = {
			// "vcNewstockId" : vcNewstockId
		}
		return this.httpClient.get('otc/v1/Newstock/NewstockInfo/' + vcNewstockId, postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [getNewstockInfoByNo description]
	 * @param {[type]} lNewstockNo [实例ID]
	 */
	public getNewstockInfoByNo(lNewstockNo) {
		let postBody = {
			// "vcNewstockId" : vcNewstockId
		}
		return this.httpClient.get('otc/v1/Newstock/' + lNewstockNo, postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [getInquiryList 根据实例Id（lNewstockNo）查询询价明细信息。操作员Id和基金经理Id作为过滤条件]
	 * @param {[type]} operaterId [操作员]
	 * @param {[type]} fundmrgId  [基金经理ID]
	 */
	public getInquiryList(lNewstockNo) {
		let postBody = {

		}
		return this.httpClient.get('otc/v1/Newstock/InquiryList/' + lNewstockNo, postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [addNewStock 新增新股询价]
	 * @param {[type]} newStockModel [新股数据模型]
	 */
	public addNewStock(newStockModel) {
		let postBody = newStockModel;
		console.log("新增：" + JSON.stringify(newStockModel));
		
		return this.httpClient.post('otc/v1/Newstock', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [updateNewStock 更新询价信息]
	 * @param {[type]} newStockModel [新股数据模型]
	 */
	public submitNewStock(newStockModel) { // TODO
		let postBody = newStockModel;
		return this.httpClient.put('otc/v1/Newstock/newinquirylist?lNewStockNo=' + newStockModel.lNewstockNo, postBody, {
			isAuthHttp: false,
			isReturnOriginal: true,
			headers:[{'Content-Type':'application/json'}]
		});
	}

	/**
	 * [updateNewStock 更新询价信息]
	 * @param {[type]} newStockModel [新股数据模型]
	 */
	public updateNewStock(newStockModel) { // TODO
		let postBody = newStockModel;
		return this.httpClient.put('otc/v1/Newstock/' + newStockModel.lNewstockNo, postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [saveInqurify 保存询价明细]
	 * @param {[type]} inqurify [询价明细实例]
	 * @param check 需不需要check
	 */
	public saveInqurify(inqurify,check) {
		return this.httpClient.put('otc/v1/Newstock/InquiryList/' + inqurify[0].lNewstockNo + '?check=' + check , inqurify, {
			isAuthHttp: false,
			isReturnOriginal: true
		});
	}

	// 基金选择模态框内基金列表
	public searchFundList(param):Observable<any>{
		return this.httpClient.get("otc/v1/Newstock/FundList",param,{
			isAuthHttp: false
		});
	}

	// 获取手工录入询价基金的询价信息
	public InquiryFundInfo(param):Observable<any>{
		return this.httpClient.get("otc/v1/Newstock/InquiryFundInfo",param,{
			isAuthHttp: false,
			isReturnOriginal: true
		})
	}


	// 保存手工录入基金
	public saveInquiryFundInfo(param,check):Observable<any>{
		return this.httpClient.post('otc/v1/Newstock/InquiryFundInfo/'+param.lNewstockNo+'?check='+check,param.data,{
			isAuthHttp: false,
			isReturnOriginal: true,
			headers:[{'Content-Type':'application/json'}]
		})
	}

	// 删除询价明细
	public deleteInqurify(param){
		return this.httpClient.delete('otc/v1/Newstock/NewStockDetail?pmkyList=' +param.pmkyList ,param,{
			isAuthHttp: false,
			isReturnOriginal: true
		})
	}
}
