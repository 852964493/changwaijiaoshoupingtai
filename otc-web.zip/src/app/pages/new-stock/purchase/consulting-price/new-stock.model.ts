export var newStockModel = {
  "lNewstockNo": null,
  "dtCreateDate": null,
  "dtUpdateDate": null,
  "vcUserId": null,
  // 证券代码
  "vcNewstockId": null,
  // 证券名称
  "vcNewstockName": null,
  // 交易所
  "vcMarket": null,
  "vcLeadUnderwriter": null, // 保荐人（主承销商）
  "vcIndustry": null,
  // 发行数量
  "enIssuesStock": null,
  "enPreipoassets": null,
  "enPreipoincome": null,
  "lIpoStock": null,
  "enDiforecast": null,
  "lWebipoStock": null,
  "enCirculateStock": null,
  "enMinBuy": null,
  "enMaxBuy": null,
  "enPredictRate": null,
  "enTotalRate": null,
  // 发行价格
  "enIssuePrice": null,
  "enInquiryPrice": null,
  "dtHkDate": null, // 缴款时间
  "lJkDate":null,
  "dtHkTime": null,
  "dtInquiryStartdate": null,
  "dtWxsgDate": null,
  "enMinivalue": null,
  "cInquiryStart": null,
  "cInputXjxx": null,
  "cConfirmXj": null,
  "cFkXj": null,
  "cOrderXj": null,
  "cInputRw": null,
  "cConfirmSg": null,
  "cOrderSg": null,
  "cGetorders": null,
  "cInputZq": null,
  "cHk": null,
  "cJk": null,
  "vcNewstockStatus": null,
  "bostitle": null,
  "bosid": null,
  "orgid": null,
  "empid": null,
  "bosdate": null,
  "bostime": null,
  "titleid": null,
  "nreserved3": null,
  "cValidFlag": null,
  //"lFundsCount": null,
  "vcErrMsg": null
  // // 保荐人
  // "sponsor": "", // TODO  跟接口还没对应上
  // // 委托对象
  // "consignor": "" // TODO  跟接口还没对应上
};