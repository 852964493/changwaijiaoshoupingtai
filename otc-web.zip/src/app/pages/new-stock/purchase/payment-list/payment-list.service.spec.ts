import { TestBed, inject } from '@angular/core/testing';

import { PaymentListService } from './zq.service';

describe('PaymentListService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [PaymentListService]
		});
	});

	it('should ...', inject([PaymentListService], (service: PaymentListService) => {
		expect(service).toBeTruthy();
	}));
});
