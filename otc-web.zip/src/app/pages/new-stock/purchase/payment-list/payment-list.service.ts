import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { environment } from "../../../../../environments/environment"
@Injectable()
export class PaymentListService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [getRemittanceList 会计划款列表]
	 * @param {[type]} param [{
	 *      vcFundCode：// 基金代码
	 *      vcNewstockId：// 证券代码
	 *      page:// 页码
	 *      pageSize: // 每页分页记录数
	 *      type: // 列表类型（1：中签管理，2：已缴款）
	 *      traceDate: // 查询日期（空表示当天）
	 *      isHisData: // 是否历史交易（true：历史，false：当前）
	 * }]
	 */
	getRemittanceList(param){
		let postBody = {
			vcFundCode: param.vcFundCode,
			vcNewstockId: param.vcNewstockId,
			page: param.page,
			pageSize: param.pageSize,
			type: "2",
			traceDate: param.traceDate,
			isHisData: param.isHisData
		}
		return this.httpClient.get('otc/v1/Newstock/RemittanceList', postBody, {
			isAuthHttp: false
		});
	}

	/**
	 * [transferMoney 缴款确认]
	 * @param {[type]} param [[{
	 *    lNewstockNo:
	 *    vcFundCode":
	 * }]]]
	 */
	transferMoney(param){
		let postBody = param;

		return this.httpClient.post('otc/v1/Newstock/TransferMoney', postBody, {
			isAuthHttp: false
		});
	}

}
