import { Component, OnInit, ViewChild } from '@angular/core';
import { FileUploadNormalComponent } from '../../purchase/file-upload-normal/file-upload-normal.component';
import { PaymentListService } from './payment-list.service';
import { AppPaginationComponent, PaginationModel } from '../../../../widgets/pagination/pagination.component';
import { environment } from "../../../../../environments/environment"

import * as moment from 'moment';
import * as _ from 'lodash'

@Component({
	selector: 'new-stock-payment-list',
	templateUrl: './payment-list.component.html',
	styleUrls: ['./payment-list.component.scss'],
	providers: [PaymentListService]
})
export class PaymentComponent implements OnInit {


	public isShowBallot = true;

	// 列表
	public remittanceList: Array<any>;

	// 列表当前页全选标记
	public isCheckedAll = false;

	// 查询条件
	public searchBody = {
		vcFundCode: "", // 基金代码
		vcNewstockId: "", // 证券代码
		page: 1,// 页码
		pageSize: environment.pageSize, // 每页分页记录数
		traceDate: "",// 查询日期（空表示当天）
		isHisData: false // 是否历史交易（true：历史，false：当前）
	}

	// 导入配售对象
	@ViewChild(FileUploadNormalComponent)
	public fileUploadNormalComponent: FileUploadNormalComponent;

	// 分页配置
	public pageInfo: PaginationModel = {
		currentPageNum: 1,
		totalPages: 1,
		total: 0 // 总记录数
	}

	// 分页组件
	@ViewChild(AppPaginationComponent)
	public paginationComponent: AppPaginationComponent;

	// 文件上传modal配置信息
	public fileUploadModal = {
		modalTile: "", // modal title
		title: "", // titel
		url: "", // url
		method: "", // POST OR GET
		itemAlias: "", // file alias
		formDatas: [] // POST 参数
	};

	constructor(
		public paymentListService: PaymentListService
	) {
		this.getRemittanceList(1);
	}

	changeBallotStatus() {
		this.isShowBallot = !this.isShowBallot;
	}

	/**
	 * [search 查询]
	 */
	search() {
		this.getRemittanceList(1);
	}

	/**
	 * [resetSearch 重置查询条件]
	 */
	resetSearch() {
		this.searchBody.vcFundCode = "";
		this.searchBody.vcNewstockId = "";
		this.searchBody.page = 1;
		this.searchBody.pageSize = environment.pageSize;
		this.searchBody.traceDate = "";
	}

	ngOnInit() {
	}

	/**
	 * [checkedAll 列表当前页全选]
	 */
	checkedAll() {
		if (this.isCheckedAll) { // 更新为全选
			_.forEach(this.remittanceList, item => {
				item.isChecked = true;
			})
		} else { // 更新为不全选
			_.forEach(this.remittanceList, item => {
				item.isChecked = false;
			})
		}
	}

	/**
	 * [checked 是否需要更新全选]
	 * @param {[type]} remittance [实例对象]
	 */
	checked(remittance) {
		if (remittance.isChecked) {
			var temp = _.find(this.remittanceList, { isChecked: false });
			if (!temp) { // 全选重置为 true
				this.isCheckedAll = true;
			}
		} else { // 全选重置为 false
			this.isCheckedAll = false;
		}
	}

	/**
	 * [getRemittanceList 会计划款列表]
	 */
	getRemittanceList(pageNum) {
		// 设置查询条件页码
		this.searchBody.page = pageNum;

		this.paymentListService.getRemittanceList(this.searchBody).subscribe(data => {
			if (data) {
				// 添加是否选择状态， 默认否
				_.forEach(data.list, item => {
					item.isChecked = false;
				})

				this.remittanceList = data.list;

				// 构建分页
				this.pageInfo.currentPageNum = data.pageNum;
				this.pageInfo.totalPages = data.pages;
				this.pageInfo.total = data.total; // 总记录数
			}
		});
	}

	/**
	 * [transferMoney 缴款确认]
	 */
	transferMoney() {
		var that = this;
		var needTMObj = _.filter(this.remittanceList, { isChecked: true });
		console.log("已选择要缴款确认的数据：" + JSON.stringify(needTMObj));
		if (needTMObj.length == 0) {
			window["swal"]("", "请选择需要缴款确认的证劵", "info");
		} else {
			window["swal"]({
				title: "",
				text: "是否进行缴款确认?",
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "确认",
				cancelButtonText: "取消",
				closeOnConfirm: false,
				closeOnCancel: true,
				showLoaderOnConfirm: true
			},
				function(isConfirm) {
					if (isConfirm) {
						var _needTMObj = [];

						// 构建缴款确认的数据，数组对象{lNewstockNo，vcFundCode}
						_.forEach(needTMObj, item => {
							let temp = {
								lNewstockNo: item.lNewstockNo,
								vcFundCode: item.vcFundCode
							}
							_needTMObj.push(temp);
						})

						//console.log("经过构建后的缴款确认数据：" + JSON.stringify(_needTMObj));
						that.paymentListService.transferMoney(_needTMObj).subscribe(data => {
							if (data) {
								//console.log("缴款确认返回数据：" + JSON.stringify(data));
								window["swal"]("缴款确认!", "", "success");
							}
						});

					} else {
						//window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
					}
				});
		}

	}

	/**
	 * [swtichInstructionStatus 交款单状态]
	 * @param {[type]} num [description]
	 */
	swtichInstructionStatus(num) {
		var retVal = "";
		switch (num) {
			case "1":
				retVal = "待确认";
				break;
			case "2":
				retVal = "待初审";
				break;
			case "3":
				retVal = "待复审";
				break;
			case "4":
				retVal = "待发送";
				break;
			case "5":
				retVal = "已发送";
				break;
			case "6":
				retVal = "已到账";
				break;
			case "7":
				retVal = "待撤销";
				break;
		}

		return retVal;
	}


	/**
	 * [toggleDZModalOpen 导入到账文件]
	 */
	toggleDZModalOpen() {
		// 配置导入文件信息
		this.fileUploadModal = {
			modalTile: "导入到账文件",
			title: "请选择上传的到账文件",
			url: environment.server + "otc/v1/Newstock/DZList",
			method: "POST",
			itemAlias: "file",
			formDatas: []
		};

		this.fileUploadNormalComponent.openModal();
	}

	/**
	 * [reflesh 刷新当前页面]
	 * @param {[type]} event [是否刷新]
	 */
	reflesh(event?) {
		if (event) {
			this.resetSearch();
			this.getRemittanceList(1);
		}
	}
}
