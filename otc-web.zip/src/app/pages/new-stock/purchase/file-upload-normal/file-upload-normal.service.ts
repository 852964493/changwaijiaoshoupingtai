import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { Observable } from "rxjs/Observable";

@Injectable()
export class FileUploadNormalService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [newstockInfoList 新股列表]
	 */
	uploadFile(file) {
		let postBody = {
			file : file
    	}
		return this.httpClient.get('otc/v1/Newstock/RationCode', postBody, {
			isAuthHttp: false
		});
  }
}
