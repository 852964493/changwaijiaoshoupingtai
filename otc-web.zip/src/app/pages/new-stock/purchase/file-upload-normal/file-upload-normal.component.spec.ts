import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileUploadNormalComponent } from './file-upload-normal.component';

describe('FileUploadNormalComponent', () => {
  let component: FileUploadNormalComponent;
  let fixture: ComponentFixture<FileUploadNormalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileUploadNormalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileUploadNormalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
