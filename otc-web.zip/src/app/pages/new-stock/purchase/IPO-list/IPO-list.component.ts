import {Component, ElementRef, Input, OnInit, ViewChild, Injectable} from '@angular/core';
import {IPOlistService} from "./IPO-list.service";
import {InquiryStatusComponent} from "../inquiry-status/inquiry-status.component";
import {ConsultingPriceComponent} from "../consulting-price/consulting-price.component";
import {AppPaginationComponent, PaginationModel} from '../../../../widgets/pagination/pagination.component';
import {environment} from '../../../../../environments/environment';
import {Util} from "../../../../common/util";
import * as _ from 'lodash'

/**
 *
 */
@Component({
  selector: 'new-stock-purchase-IPO-list',
  templateUrl: './IPO-list.component.html',
  styleUrls: ['./IPO-list.component.scss'],
  providers: [IPOlistService]
})
export class IPOListComponent implements OnInit {
  _ = _;

  @Input()
  public data: Array<any>;

  public modalStatus: boolean;

  // 新股列表
  public newStockList: Array<any> = [];

  // 新股操作权限表
  public operateList: any = [];

  // 列表是否全选
  public isCheckedAll = false;

  // 查询条件
  public searchBody = {
    vcNewstockId: "", // 证券代码
    vcNewstockStatus: "", // 状态
    page: 1, // 页码
    pageSize: environment.pageSize
  }

  // 新股询价基金列表 key- 实例ID，value- 询价详情列表
  // [{
  //   lNewstockNo: 询价详情数组:[]
  // }]
  public inquiryList: any = {}

  // 分页数据模型
  public pageInfo: PaginationModel = {
    currentPageNum: 1,
    pageSize: 10,
    totalPages: 1,
    total: 0,
    pagesShow: 5,
    startRow: 0,
    endRow: 0,
    pageList: [5, 10, 25, 50, 100]
  };

  // 分页组件
  @ViewChild("newStockPag")
  //@ViewChild(AppPaginationComponent)
  public paginationComponent: AppPaginationComponent;

  // 询价
  @ViewChild(ConsultingPriceComponent)
  public consultingPriceComponent: ConsultingPriceComponent;

  // 新股发起询价的新股ID
  public lNewstockNoPara: any = "";

  // 下一处理状态
  @ViewChild(InquiryStatusComponent)
  public inquiryStatusComponent: InquiryStatusComponent;

  public inquiryPageInfo: any = {}

  // 询价分页配置
  @ViewChild("inquiryPag")
  public inquiryPagComponent: AppPaginationComponent;

  // 询价列表查询条件
  public inquirySearchBody = {
    page: "1",
    pageSize: environment.pageSize,
    vcOperaterId: "",
    vcFundmrgId: ""
  }

  @ViewChild("modal")
  public modal: ElementRef;

  // 新股状态
  public newStockStatus: any;

  constructor(public iPOlistService: IPOlistService) {
    this.getStatusDir();
    this.getNewstockIPOList();
  }

  ngOnInit() {
    //Util.$('#example').popover("show")
  }

  /**
   * [checkedAll 列表当前页全选]
   * @param lNewstockNo 当前列表的新股编号
   */
  checkedAll(lNewstockNo) {
    if (this.isCheckedAll) { // 更新为全选
      _.forEach(this.inquiryList[lNewstockNo], item => {
        item.isChecked = true;
      });
    } else { // 更新为不全选
      _.forEach(this.inquiryList[lNewstockNo], item => {
        item.isChecked = false;
      });
    }
  }

  /**
   * [checked 是否需要更新全选]
   * @param {[type]} remittance [实例对象]
   * @param lNewstockNo 当前列表的新股编号
   */
  checked(remittance,lNewstockNo) {
    if (remittance.isChecked) {
      const temp = _.find(this.inquiryList[lNewstockNo], { isChecked: false });
      if (!temp) { // 全选重置为 true
        this.isCheckedAll = true;
      }
    } else { // 全选重置为 false
      this.isCheckedAll = false;
    }
  }


  public openModal(): void {
    this.modalStatus = true;
    Util.$(this.modal.nativeElement).modal('show');
  }

  public closeModal(): void {
    this.modalStatus = false;
    Util.$(this.modal.nativeElement).modal('hide');
  }

  public toggleModal(): void {
    this.modalStatus = !this.modalStatus;
    Util.$(this.modal.nativeElement).modal('toggle');
  }

  /**
   * [search 查询]
   */
  search() {
    this.getNewstockIPOList();
  }

  /**
   * [resetSearch 重置查询条件]
   */
  resetSearch() {
    this.searchBody = {
      vcNewstockId: "", // 证券代码
      vcNewstockStatus: "", // 状态
      page: 1, // 页码
      pageSize: environment.pageSize
    }
  }

  sildeToggle(index){
    window["$"]("#ipo"+index).slideToggle();
  }

  /**
   * [getOperateByStatus 根据新股状态获得操作权限]
   * @param {[type]} operateId [1、编辑询价 2、导入询价 3、询价确认
   *    4、编辑询价明细 5、编辑风控 6、代确认 7、申购确认 8、提交]
   * @param {[type]} vcNewstockStatus [新股状态]
   * TODO: 还可以再优化
   */
  canOperate(operateId, vcNewstockStatus) {
    var retVale = false;

    let item: any = _.find(this.operateList, {vcItemKey: operateId});
    if (item && item.vcExtValue2) {
      if (_.indexOf(_.split(item.vcExtValue2, ","), vcNewstockStatus) > -1) {
        retVale = true;
      }
    }
    return true;
  }

  /**
   * [getNewstockIPOList 新股列表]
   */
  public getNewstockIPOList() {
    this.searchBody.page = this.pageInfo.currentPageNum;

    this.iPOlistService.getNewstockIPOList(this.searchBody).subscribe(data => {
      this.inquiryList = {}; // 重置
      if (data) {
        this.newStockList = data.list;
        // 添加是否选择属性
        _.forEach(this.newStockList, data => {
          data.isChecked = false;
          data.isOpen = false;
        });
        // 构建分页
        this.pageInfo.startRow = data.startRow;
        this.pageInfo.endRow = data.endRow;
        this.pageInfo.totalPages = data.pages;
        this.pageInfo.total = data.total; // 总记录数
      }
    });
  }

  /**
   * [getInquiryListById 新股询价列表]
   * @param {[type]} lNewstockNoAndPageNum [格式：实例ID'-'选择的页码]
   * @param closeList  关闭列表
   */
  public getInquiryListById(lNewstockNoAndPageNum,index,closeList) {
    var oNAndNumList = _.split(lNewstockNoAndPageNum, '-');
    var lNewstockNo = oNAndNumList[0]; // 实例ID
    var pageNum = "1";

    // 修改选择状态
    var newStock = _.find(this.newStockList, {"lNewstockNo": _.parseInt(lNewstockNo)});

    if(closeList){
      window["$"]("#ipo"+index).slideToggle();
      newStock.isOpen = !newStock.isOpen;
    }

    // 展开状态
    if (newStock.isOpen == true) {
      if (oNAndNumList.length > 1) {
        this.inquirySearchBody.page = oNAndNumList[1]; //选择的页码
      }

      // 获得新股列表
      this.iPOlistService.getInquiryList(this.inquirySearchBody, lNewstockNo).subscribe(data => {
        if (data) {
          this.inquiryList[lNewstockNo] = data.list;
          _.forEach(this.inquiryList[lNewstockNo], data => {
            // 为每条询价详细添加是否可编辑状态
            data.isEdited = false;
            // 备份询价价格, 用于询价详细取消修改恢复原来的值
            data.enPriceOld = data.enPrice;
            // 备份询价数量, 用于询价详细取消修改恢复原来的值
            data.lSharesOld = data.lShares;
            data.isChecked = false;
          });
          // 构建分页
          var temp = {
            currentPageNum: data.pageNum,
            totalPages: data.pages,
          };
          this.inquiryPageInfo[lNewstockNo] = temp;
        }
      });
    }
  }


  /**
   * [getInquiryCurPage 获得询价详情列表当前页码]
   * @param {[type]} lNewstockNo [description]
   */
  getInquiryCurPage(lNewstockNo) {
    if (!this.inquiryPageInfo[lNewstockNo]) {
      this.inquiryPageInfo[lNewstockNo] = {
        currentPageNum: 1,
        totalPages: 1,
      };
    }

    return this.inquiryPageInfo[lNewstockNo].currentPageNum;
  }

  /**
   * [getInquiryTotalPage 获得询价详情列表总页数]
   * @param {[type]} lNewstockNo [description]
   */
  getInquiryTotalPage(lNewstockNo) {
    if (!this.inquiryPageInfo[lNewstockNo]) {
      this.inquiryPageInfo[lNewstockNo] = {
        currentPageNum: 1,
        totalPages: 1,
      };
    }

    return this.inquiryPageInfo[lNewstockNo].totalPages;
  }

  /**
   * 提交确认
   * @param item 点击行的数据
   */
  public submitConfirm(item) {
    const that = this;
    // 定义查询参数
    // vcNewstockStatus 当前行的业务状态
    // lNewstockNo  当前行的证券代码
    const param = {
      lNewstockNo: item.lNewstockNo,
      pmkyList:[],
      cDataStatus:[]
    };
    var checkedData:any = _.filter(that.inquiryList[item.lNewstockNo],{ isChecked:true });
    if(that.validateCanSubmit(checkedData)){
      if(checkedData.length === 0 || item.isOpen === false){
          window["swal"]({
              title: "提示",
              text: `默认提交全部，继续提交数据?`,
              type: "info",
              showCancelButton: true,
              confirmButtonColor: "#DD6B55",
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              closeOnConfirm: false,
              closeOnCancel: true,
              showLoaderOnConfirm: true
            },
            function (isConfirm) {
              if (isConfirm) {
                // 更新新股业务状态
                that.iPOlistService.upDateDataStatus(param).subscribe(result => {
                  if (result) {
                    if (result.code === 0) {
                      window["swal"]("成功", "提交成功", "success");
                      that.search();
                    }
                  }
                });
              } else {
                // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
              }
        });
      }else{
        window["swal"]({
          title: "提示",
          text: `选择了${checkedData.length}条数据，是否继续操作`,
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          closeOnConfirm: false,
          closeOnCancel: true,
          showLoaderOnConfirm: true
        },
        function (isConfirm) {
          checkedData.forEach((item) => {
            param.pmkyList.push(item.pmkyNum);
          });
          that.iPOlistService.upDateDataStatus(param).subscribe(result => {
            if (result) {
              if (result.code === 0) {
                window["swal"]("成功", "提交成功", "success");
                that.search();
              }
            }
          });
        });
      }
    }
  }

  // 校验是否符合资格提交确认
  validateCanSubmit(data){
    var answer = true;
    data.forEach((item)=>{
      if(item.cDataStatusName!=="未提交"){
        window["swal"]("提示", "非未提交的数据不能做提交确认操作", "info");
        answer = false;
      }
    })
    return answer;
  }

  /**
   * 执行询价
   * @param item 点击行的数据
   */
  public confirmInquiry(item) {
    const that = this;
    // 定义查询参数
    // vcNewstockStatus 当前行的业务状态
    // lNewstockNo  当前行的证券代码
    const param = {
      vcNewstockStatus: item.vcNewstockStatus,
      lNewstockNo: item.lNewstockNo,
      pmkyList:[],
      cDataStatus:[]
    };
    var checkedData:any = _.filter(that.inquiryList[item.lNewstockNo],{ isChecked:true });
    if(that.validateCanInquiry(checkedData)){
      if(checkedData.length === 0 || item.isOpen === false){
          window["swal"]({
              title: "提示",
              text: `默认提交全部，继续执行询价?`,
              type: "info",
              showCancelButton: true,
              confirmButtonColor: "#DD6B55",
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              closeOnConfirm: false,
              closeOnCancel: true,
              showLoaderOnConfirm: true
            },
            function (isConfirm) {
              if (isConfirm) {
                // 更新新股业务状态
                that.iPOlistService.confirmInquiry(param).subscribe(result => {
                  if (result) {
                    if (result.code === 0) {
                      window["swal"]("成功", "执行询价成功", "success");
                      that.search();
                    }
                  }
                });
              } else {
                // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
              }
        });
      }else{
        window["swal"]({
          title: "提示",
          text: `选择了${checkedData.length}条数据，是否继续操作`,
          type: "info",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          closeOnConfirm: false,
          closeOnCancel: true,
          showLoaderOnConfirm: true
        },
        function (isConfirm) {
          if (isConfirm) {
            checkedData.forEach((item) => {
              param.pmkyList.push(item.pmkyNum);
            });
            that.iPOlistService.confirmInquiry(param).subscribe(result => {
              if (result) {
                if (result.code === 0) {
                  window["swal"]("成功", "执行询价成功", "success");
                  that.search();
                }
              }
            });
          }
        });
      }
    }
  }

  // 校验是否符合资格执行询价
  validateCanInquiry(data){
    var answer = true;
    data.forEach((item)=>{
      if(item.cDataStatusName!=="待询价"){
        window["swal"]("提示", "非待询价的数据不能做执行询价操作", "info");
        answer = false;
      }
    })
    return answer;
  }

  /**
   * 批量入围
   * @param item 点击股票的数据
   */
  public confirmRW(item) {
    const that = this;
    var checkedData:any = _.filter(that.inquiryList[item.lNewstockNo],{ isChecked:true });
    if(that.validateCanRW(checkedData)){
      window["swal"]({
        title: "提示",
        text: `确认入围操作？`,
        type: "info",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        closeOnConfirm: false,
        closeOnCancel: true,
        showLoaderOnConfirm: true
      },
      function (isConfirm) {
        if (isConfirm) {
          var param = [];
          checkedData.forEach((item) => {
            param.push({
              pmkyNum:item.pmkyNum,
              vcFundCode:item.vcFundCode,
              cIsrw:1,
              lNewstockNo:item.lNewstockNo,
              cDataStatus:5
            })
          });
          that.iPOlistService.confirmRW(item.lNewstockNo,param).subscribe(result => {
            if (result) {
              if (result.code === 0) {
                window["swal"]("成功", "确认入围操作成功", "success");
                that.search();
              }
            }
          });
        }
      });
    }
  }

  /**
   * 单行操作入围
   * @param item 当前行数据
   */
  public singleConfirmRW(item) {
    const that = this;
      if(item.cDataStatusName!=="询价中"){
        return window["swal"]("提示", "非询价中的数据不能做执行入围操作", "info");
      }
    window["swal"]({
      title: "提示",
      text: `确认入围操作？`,
      type: "info",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      closeOnConfirm: false,
      closeOnCancel: true,
      showLoaderOnConfirm: true
    },
    function (isConfirm) {
      if (isConfirm) {
        var param = [];
        param.push({
            pmkyNum:item.pmkyNum,
            vcFundCode:item.vcFundCode,
            cIsrw:1,
            lNewstockNo:item.lNewstockNo,
            cDataStatus:5
          })
        that.iPOlistService.confirmRW(item.lNewstockNo,param).subscribe(result => {
          if (result) {
            if (result.code === 0) {
              window["swal"]("成功", "确认入围操作成功", "success");
              that.search();
            }
          }
        });
      }
    });
  }

  // 校验是否符合资格批量入围
  validateCanRW(data){
    var answer = true;
    if(data.length === 0 ){
      answer = false;
      window["swal"]("提示", "请选择数据进行入围操作", "info");
      return answer;
    }
    data.forEach((item)=>{
      if(item.cDataStatusName!=="询价中"){
        window["swal"]("提示", "非询价中的数据不能做执行入围操作", "info");
        answer = false;
      }
    })
    return answer;
  }

  // 撤销入围
  public recallRW(item){
    const that = this;
    var checkedData:any = _.filter(that.inquiryList[item.lNewstockNo],{ isChecked:true });
    if(that.validateCanRecallRW(checkedData)){
      window["swal"]({
        title: "提示",
        text: `确认撤销入围操作？`,
        type: "info",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        closeOnConfirm: false,
        closeOnCancel: true,
        showLoaderOnConfirm: true
      },
      function (isConfirm) {
        if (isConfirm) {
          var param = [];
          checkedData.forEach((item) => {
            param.push({
              pmkyNum:item.pmkyNum,
              vcFundCode:item.vcFundCode,
              cIsrw:0,
              lNewstockNo:item.lNewstockNo,
              cDataStatus:4
            })
          });
          that.iPOlistService.confirmRecallRW(item.lNewstockNo,param).subscribe(result => {
            if (result) {
              if (result.code === 0) {
                window["swal"]("成功", "撤销入围操作成功", "success");
                that.search();
              }
            }
          });
        }
      });
    }
  }

  // 校验是否符合资格批量撤销入围
  validateCanRecallRW(data){
    var answer = true;
    if(data.length === 0 ){
      answer = false;
      window["swal"]("提示", "请选择数据进行撤销入围操作", "info");
      return answer;
    }
    data.forEach((item)=>{
      if(item.cDataStatusName!=="已入围"){
        window["swal"]("提示", "非已入围的数据不能做执行撤销入围操作", "info");
        answer = false;
      }
    })
    return answer;
  }

  /**
   * 单行操作撤销入围
   * @param item 当前行数据
   */
  public singleConfirmRecallRW(item) {
    const that = this;
      if(item.cDataStatusName!=="已入围"){
        return window["swal"]("提示", "非已入围的数据不能做执行入围操作", "info");
      }
    window["swal"]({
      title: "提示",
      text: `确认撤销入围操作？`,
      type: "info",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      closeOnConfirm: false,
      closeOnCancel: true,
      showLoaderOnConfirm: true
    },
    function (isConfirm) {
      if (isConfirm) {
        var param = [];
        param.push({
            pmkyNum:item.pmkyNum,
            vcFundCode:item.vcFundCode,
            cIsrw:0,
            lNewstockNo:item.lNewstockNo,
            cDataStatus:4
          })
        that.iPOlistService.confirmRecallRW(item.lNewstockNo,param).subscribe(result => {
          if (result) {
            if (result.code === 0) {
              window["swal"]("成功", "撤销入围操作成功", "success");
              that.search();
            }
          }
        });
      }
    });
  }

  // 结束询价
  public stopInquiry(item){
    const that = this;
    window["swal"]({
      title: "提示",
      text: `是否继续结束询价`,
      type: "info",
      showCancelButton: true,
      confirmButtonColor: "#DD6B55",
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      closeOnConfirm: false,
      closeOnCancel: true,
      showLoaderOnConfirm: true
    },
    function (isConfirm) {
      if (isConfirm) {
        that.iPOlistService.stopInquiry(item.lNewstockNo).subscribe(result => {
          if (result) {
            if (result.code === 0) {
              window["swal"]("成功", "结束询价操作成功", "success");
              that.search();
            }
          }
        });
      }
    });
  }


  /**
   * [toggleConsultingPriceModalOpen 发起询价]
   * @param {[type]} lNewstockNo [实例id]
   */
  toggleConsultingPriceModalOpen(lNewstockNo) {
    console.log("实例id" + lNewstockNo);
    this.lNewstockNoPara = lNewstockNo;
    this.consultingPriceComponent.openModal('1',lNewstockNo);
  }

  /**
   * [changeInquiryStatus 新股更新至下一处理状态]
   * @param {[type]} lNewstockNo [实例id]
   */
  public changeInquiryStatus(lNewstockNo) {
    var that = this;

    var newStock = _.find(this.newStockList, {"lNewstockNo": lNewstockNo});

    // 获得下一处理状态
    var nextStatusParam = {
      lNewstockNo: lNewstockNo, // 实例Id
      vcNewstockStatus: newStock.vcNewstockStatus // 当前新股状态
    }

    // 下一处理状态
    this.iPOlistService.getNextStatus(nextStatusParam).subscribe(data => {
      if (data) {
        var vcNewstockStatusName = data.vcNewstockStatusName; // 下一处理状态
        var vcNewstockStatus = data.vcNewstockStatus; // 下一处理状态编码

        window["swal"]({
            title: "提示",
            text: "是否确定要更新到下一处理状态：" + vcNewstockStatusName + "?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "更新",
            cancelButtonText: "取消",
            closeOnConfirm: false,
            closeOnCancel: true,
            showLoaderOnConfirm: true
          },
          function (isConfirm) {
            if (isConfirm) {
              // 更新状态
              that.iPOlistService.updateInquiryStatus(newStock).subscribe(data => {
                if (data) {
                  // 将新股状态置为下一处理状态
                  newStock.vcNewstockStatus = vcNewstockStatus;
                  window["swal"]("提示", "更新成功！", "success");
                  that.getNewstockIPOList();
                }
              });
            } else {
              // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
            }
          });
      }
    });
  }

  /**
   * [inquiryConfirm 基金经理确认]
   * @param {[type]} lNewstockNo [实例id]
   */
  public inquiryConfirm(lNewstockNo) {
    var that = this;

    var newStock = _.find(this.newStockList, {"lNewstockNo": lNewstockNo});

    var vcfundCodeList = _.map(this.inquiryList[newStock.lNewstockNo], "vcFundCode");

    var param = {
      lNewstockNo: lNewstockNo,
      vcfundCodeList: vcfundCodeList
    };

    // 获得下一处理状态
    var nextStatusParam = {
      lNewstockNo: lNewstockNo, // 实例Id
      vcNewstockStatus: newStock.vcNewstockStatus // 当前新股状态
    };

    // 下一处理状态
    this.iPOlistService.getNextStatus(nextStatusParam).subscribe(data => {
      if (data) {
        var vcNewstockStatusName = data.vcNewstockStatusName; // 下一处理状态
        var vcNewstockStatus = data.vcNewstockStatus; // 下一处理状态编码

        window["swal"]({
            title: "提示",
            text: "是否确认要参与询价?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "更新",
            cancelButtonText: "取消",
            closeOnConfirm: false,
            closeOnCancel: true,
            showLoaderOnConfirm: true
          },
          function (isConfirm) {
            if (isConfirm) {
              // 基金经理确认
              that.iPOlistService.inquiryConfirm(param).subscribe(data => {
                if (data) {
                  // 将新股状态置为下一处理状态
                  newStock.vcNewstockStatus = vcNewstockStatus;

                  // 更新列表确认状态为 已确认
                  _.forEach(that.inquiryList[newStock.lNewstockNo], data => {
                    data.cXjConfirm = 1;
                  });

                  window["swal"]("提示", "询价确认成功", "success");
                }
              });
            } else {
              // window["swal"]("Cancelled", "Your imaginary file is safe :)", "error");
            }
          });
      }
    });
  }

  /**
   * [toEdit 置询价明细为修改状态]
   * @param {[type]} inquiry [询价明细实例]
   */
  toEdit(inquiryList) {
    this.consultingPriceComponent.toEdit(inquiryList);
  }


  /**
   * [saveInqurify 保存询价明细]
   * @param {[type]} inquiry [询价明细实例列表]
   */
  saveInqurify(inquiryList) {
    if (this.hasCheckedInqurify(inquiryList)) {
      this.consultingPriceComponent.saveInqurify(inquiryList);
    }
  }


  /**
   * [cancelEdit 取消修改]
   * @param {[type]} inquiryList [询价明细实例列表]
   */
  cancelEdit(inquiryList) {
    if (this.hasCheckedInqurify(inquiryList)) {
      this.consultingPriceComponent.cancelEdit(inquiryList);
    }
  }


  /**
   * [hasCheckedInqurify 判断明细列表是否有编辑状态的数据，有返回true否则false]
   * @param {[type]} inquiryList [询价明细实例列表]
   */
  hasCheckedInqurify(inquiryList) {
    var retVal = false;
    if (_.find(inquiryList, {isEdited: true})) {
      retVal = true;
    }

    return retVal;
  }


  /**
   * [calculateEnMoney 计算询价金额]
   * @param {[type]} inquiry [询价明细实例]
   */
  calculateEnMoney(inquiry) {
    return this.consultingPriceComponent.calculateEnMoney(inquiry);
  }

  /**
   * [calculateEnPredictMoney 计算预计冻结金额]
   * @param {[type]} inquiry       [询价明细实例]
   * @param {[type]} enPredictRate [预计中签率]
   */
  calculateEnPredictMoney(inquiry, enInquiryPrice, enPredictRate) {
    return this.consultingPriceComponent.calculateEnPredictMoney(inquiry, enPredictRate);
  }

  /**
   * [switchNewStockStatus 根据新股状态码，返回中文]
   * @param {[type]} num [新股状态码]
   */
  switchNewStockStatus(num) {
    var retVal = "";

    var status: any = _.find(this.newStockStatus, {vcItemKey: num});
    if (status) {
      retVal = status.vcItemValue;
    }

    return retVal;
  }

  /**
   * [getStatusDir 获取业务状态字典]
   */
  getStatusDir() {
    this.iPOlistService.getStatusDir({}).subscribe(data => {
      this.newStockStatus = data;
    });
  }

  /**
   * [reflesh 刷新列表]
   * @param {[type]} event [description]
   */
  reflesh(event?) {
    if (event) {
      // 重置询价详情
      // this.inquiryList = {}
      this.resetSearch();
      this.getNewstockIPOList();
    }
  }

  /**
   * [showConfirmFundMrg 显示确认未确认基金经理]
   * @param {[type]} id [元素ID]
   */
  showConfirmFundMrg(id) {
    Util.$('#' + id).popover("show");
  }

  /**
   * [hideConfirmFundMrg 隐藏确认未确认基金经理]
   * @param {[type]} id [元素ID]
   */
  hideConfirmFundMrg(id) {
    Util.$('#' + id).popover("hide");
  }

  /**
   * 根据页码请求查询相关配置列表数据,如果当前活动页码就是目标页码，则不进行任何查询
   * 直接返回
   * @param {currentPageNum}
   */
  public pageNavigation(currentPageNum: number) {
    this.pageInfo.currentPageNum = currentPageNum;
    this.getNewstockIPOList();
  }

  /**
   * 改变每页显示记录数
   * @param {pageSize}
   */
  public pageSizeChange(pageSize: number) {
    if (pageSize !== this.pageInfo.pageSize) {
      this.pageInfo.pageSize = pageSize;
      this.pageInfo.currentPageNum = 1;
      this.getNewstockIPOList();
    }
  }

}
