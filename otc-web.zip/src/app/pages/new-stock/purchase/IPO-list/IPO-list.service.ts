import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';
import { Observable } from "rxjs/Observable";
import { environment } from "../../../../../environments/environment"


@Injectable()
export class IPOlistService {

  constructor(
    public httpClient: HttpClientService
  ) { }

  /**
   * [getNewstockIPOList 网下新股申购（列表）]
   * @param {[type]} param [
   *     vcNewstockId: "", // 证券代码
   *     vcNewstockStatus: "", // 状态
   *     page: "" // 页码
   *     }]
   */
  getNewstockIPOList(param) {
    let postBody = {
      vcNewstockId: param.vcNewstockId,
      vcNewstockStatus: param.vcNewstockStatus,
      page: param.page,
      pageSize: param.pageSize,
      type: "1" // 列表类型（1，询价；2、申购）
    }
    return this.httpClient.get('otc/v1/Newstock', postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [getInquiryList vcNewstockId]
   * @param {[type]} param [{
   *     vcNewstockId: "", // 证券代码
   *     vcNewstockStatus: "", // 状态
   *     page: 1, // 页码
   *     pageSize: environment.pageSize
   * }]
   * @param {[type]} lNewstockNo [新股Id]
   */
  getInquiryList(param, vcNewstockId) {
    let postBody = {
      page: param.page,
      pageSize: param.pageSize,
      vcOperaterId: param.vcOperaterId,
      vcFundmrgId: param.vcFundmrgId
    }
    return this.httpClient.get('otc/v1/Newstock/InquiryList/' + vcNewstockId, postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [updateStatus 根据实例Id（lNewstockNo）更新状态]
   * @param {[type]} lNewstockNo [实例Id]
   */
  public updateStatus(param) {
    let postBody = {

    }
    return this.httpClient.get('otc/v1/Newstock/Status/' + param.lNewstockNo, postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [updateInquiryStatus 更新至下一处理节点]
   * @param {[type]} parameter [参数]
   * {
      lNewstockNo: "", // 实例Id
       vcNewstockStatus: "", // 当前业务状态
       checkWorkItem: "", // 是否校验待办
      currEditor: "", // 当前办理人
      nextEditors: "", // 下一办理人
      vcNextStatus:"" // 下一状态
      };
   */
  public updateInquiryStatus(param) {
    let postBody = {}
    // otc/v1/Newstock/Status/1000270?vcNewstockStatus=2&checkWorkItem&currEditor&nextEditors&vcNextStatus=3
    return this.httpClient.put('otc/v1/Newstock/Status/' + param.lNewstockNo + '?vcNewstockStatus=' + param.vcNewstockStatus, postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [getNextStatus 获取下一处理状态]
   * @param {[type]} param [{
   *     lNewstockNo: // 实例Id
   *     vcNewstockStatus: // 当前新股状态
   * }}]
   */
  public getNextStatus(param) {
    let postBody = {
      vcNewstockStatus: param.vcNewstockStatus
    }
    return this.httpClient.get('otc/v1/Newstock/Status/' + param.lNewstockNo, postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [inquiryConfirm 基金经理确认]
   * @param {[type]} param [{
   *     lNewstockNo:;
   *     vcfundCodeList: []
   * }]
   */
  public inquiryConfirm(param) {
    let postBody = param.vcfundCodeList;
    return this.httpClient.put('otc/v1/Newstock/InquiryConfirm/' + param.lNewstockNo, postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [getOperate 根据角色和业务状态，获取操作编号]
   * @param {[type]} role [新股业务状态]
   */
  public getOperate(role) {
    let postBody = {
      role: role,
      vcNewstockStatus: "" // 业务状态
    }
    return this.httpClient.get('otc/v1/Newstock/Operate', postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [getStatus 获取业务状态字典]
   * @param {[type]} type [阶段分类（1、询价；2、申购、3、其他）]
   */
  public getStatusDir(type) {
    let postBody = {}

    return this.httpClient.get('otc/v1/Newstock/Status', postBody, {
      isAuthHttp: false
    });
  }

  /**
   * 确认提交——再次确认到下一个流程
   * @param param 当前点击行的数据
   */
  public flowHandle(param): Observable<any> {
    if(param.pmkyList.length !== 0){
      param.pmkyList = param.pmkyList.join(",");
    }
    return this.httpClient.put('otc/v1/Newstock/flowHandle/' + param.lNewstockNo + "?vcNewstockStatus=" + param.vcNewstockStatus + "&pmkyList=" + param.pmkyList, null, {
      isAuthHttp: false,
      isReturnOriginal: true
    })
  }

  // 确认提交（补）提交到下一状态
  public upDateDataStatus(param): Observable<any>{
    return this.httpClient.put('otc/v1/Newstock/DataStatus/' + param.lNewstockNo + "?cDataStatus=1&pmkyList=" + param.pmkyList, null ,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  // 执行询价
  public confirmInquiry(param): Observable<any>{
    return this.httpClient.put('otc/v1/Newstock/DataStatus/' + param.lNewstockNo + "?cDataStatus=3&pmkyList=" + param.pmkyList, null ,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * 批量入围
   * @param lNewstockNo 新股编号
   * @param param 选择行数据
   */
  public confirmRW(lNewstockNo,param): Observable<any>{
    return this.httpClient.put('otc/v1/Newstock/RW/'+lNewstockNo, param ,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  /**
   * 撤销入围
   * @param {any} lNewstockNo 
   * @param {any} param 
   * @returns {Observable<any>} 
   * @memberof IPOlistService
   */
  public confirmRecallRW(lNewstockNo,param): Observable<any>{
    return this.httpClient.put('otc/v1/Newstock/RW/'+lNewstockNo, param ,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  public stopInquiry(lNewstockNo): Observable<any>{
    return this.httpClient.put('otc/v1/Newstock/flowHandle/'+ lNewstockNo +'?pmkyList=&vcNewstockStatus=5', null ,{
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }
}

