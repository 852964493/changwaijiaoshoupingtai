import { Component, ElementRef, Input, Output, EventEmitter, OnInit, ViewChild, Injectable } from '@angular/core';
import { InquiryTempService } from "./inquiry-template.service";
import { Util } from "../../../../common/util";
import * as _ from 'lodash'
import { FileUploader } from 'ng2-file-upload';
import { environment } from "../../../../../environments/environment";
import { FileUploadNormalComponent } from '../file-upload-normal/file-upload-normal.component';


/**
 * 网下新股发起询价
 */
@Component({
  selector: 'new-stock-purchase-inquiry-template',
  templateUrl: './inquiry-template.component.html',
  styleUrls: ['./inquiry-template.component.scss'],
  providers: [InquiryTempService]
})
export class InquiryTempComponent implements OnInit {

  @Input()
  // 新股代码
  public vcNewstockId: any;
  // 询价价格
  public enIssuePrice: any = "";
  // 当前用户Id
  public currUserid: any ="";
  // 现在连接
  public fileHref: any ="";
  // 新股基本信息列表
  public newStockInfoList: Array<any>;

  // 文件上传组件
  @ViewChild(FileUploadNormalComponent)
  public fileUploadNormalComponent: FileUploadNormalComponent;

  // 文件上传modal配置信息
  public fileUploadModal = {
    modalTile: "", // modal title
    title: "", // titel
    url: "", // url
    method: "", // POST OR GET
    itemAlias: "", // file alias
    formDatas: [] // POST 参数
  };

  @Output()
  close:EventEmitter<string> = new EventEmitter<string>();

  public modalStatus: boolean;

  @ViewChild("modal")
  public modal: ElementRef;

  constructor(public inquiryTempService: InquiryTempService) {

  }

  ngOnInit() {
  }

  downloadFile(){
    // console.log("构建连接：" + environment.server + "otc/v1/Newstock/InquiryFundList?vcNewstockId="+ this.vcNewstockId +"&enIssuePrice="+ this.enIssuePrice+"&currUserid=" + this.currUserid);
    // this.fileHref = environment.server +  "otc/v1/Newstock/InquiryFundList?vcNewstockId="+ this.vcNewstockId +"&enIssuePrice="
    // + this.enIssuePrice+"&currUserid=" + this.currUserid;
    // 为了测试加 token ,上线要改
    this.fileHref = environment.server +  "otc/v1/Newstock/InquiryFundList?vcNewstockId="+ this.vcNewstockId +"&enIssuePrice="
    + this.enIssuePrice+"&currUserid=" + this.currUserid +"&token=" + sessionStorage.getItem('username');
    window.location.href=this.fileHref;
  }

  public openModal(): void {
    this.modalStatus = true;
    this.select2PluginInit();
    Util.$(this.modal.nativeElement).modal('show');
  }

  public closeModal(): void {
    this.close.emit(); // 关闭后触发上层刷新事件
    this.modalStatus = false;
    // 重置
    this.vcNewstockId = "";
    this.enIssuePrice = "";

    Util.$(this.modal.nativeElement).modal('hide');
  }

  public toggleModal(): void {
    this.modalStatus = !this.modalStatus;
    Util.$(this.modal.nativeElement).modal('toggle');
  }


  /**
   * 初始化select2插件搜索下拉框
   */
  public select2PluginInit() {
    var that = this;
    var param = {
      pageSize: 0,
      page: 0
    }
    this.inquiryTempService.getNewstockInfoList(param)
      .subscribe((data) => {
        let vcNewstockIdList = [];
        if (data) {
          this.newStockInfoList = data.list;

          _.forEach(this.newStockInfoList, newStock => {
            let temp = {
              id: newStock.vcNewstockId,
              text: newStock.vcNewstockId
            }
            vcNewstockIdList.push(temp);
          })

        }

        //var data1 = [{ id: 0, text: 'enhancement' }, { id: 1, text: 'bug' }, { id: 2, text: 'duplicate' }, { id: 3, text: 'invalid' }, { id: 4, text: 'wontfix' }];
        Util.$('.vcNewstockId').select2({
          data: vcNewstockIdList,
          multiple: false,
          closeOnSelect: false
        });

        // 选项发生修改
        Util.$('.vcNewstockId').on("select2:select", function(evt) {
          that.vcNewstockId = evt.params.data.id;
        })

      });

  }


  /**
   * [toggleconfigurationSaleModalOpen 打开导入询价modal]
   */
  toggleconfigurationSaleModalOpen() {
    // 配置导入文件信息
    this.fileUploadModal = {
      modalTile: "导入询价",
      title: "请选择上传询价",
      // url: environment.server + "otc/v1/Newstock/InquiryList/" + this.newStockModel.lNewstockNo, // 这里要改造
      url: environment.server + "otc/v1/Newstock/InquiryList" , // 这里要改造
      method: "POST",
      itemAlias: "file",
      formDatas: []
    };

    this.fileUploadNormalComponent.openModal();
  }

  reflesh(event){}

}
