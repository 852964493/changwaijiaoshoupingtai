import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../../services/http-client.service';

@Injectable()
export class InquiryTempService {

	constructor(
		public httpClient: HttpClientService
	) { }

	/**
	 * [getNewstockInfoList 新股列表]
	 * @param {[type]} param [{
	 *    pageSize: 0,
	 *    page: 0
	 * }]
	 */
	getNewstockInfoList(param) {
		let postBody = param;
		return this.httpClient.get('otc/v1/trd/wind/newstock', postBody, {
			isAuthHttp: false
		});
	}

}
