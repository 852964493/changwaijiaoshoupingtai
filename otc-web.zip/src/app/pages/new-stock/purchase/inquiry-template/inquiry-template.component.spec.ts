import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InquiryTempComponent } from './inquiry-template.component';

describe('InquiryTempComponent', () => {
  let component: InquiryTempComponent;
  let fixture: ComponentFixture<InquiryTempComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InquiryTempComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InquiryTempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
