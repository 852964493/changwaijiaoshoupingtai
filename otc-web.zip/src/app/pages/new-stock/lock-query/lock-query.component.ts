import { Component, OnInit, Inject , ViewChild, ElementRef} from '@angular/core';
import {NgForm} from '@angular/forms';
import { LockQueryService } from './lock-query.service';
import { Util } from "../../../common/util";
import { AppPaginationComponent, PaginationModel } from '../../../widgets/pagination/pagination.component';
import { environment } from '../../../../environments/environment';
import * as _ from 'lodash'
@Component({
	selector: 'app-new-stock-lock-query',
	templateUrl: './lock-query.component.html',
	styleUrls: ['./lock-query.component.scss'],
  	providers: [LockQueryService]
})
export class LockQueryComponent implements OnInit {
	private $ = window['$'];

	list: any[] = [];
	pageIndex:number = 5;

	constructor(private lockQueryService: LockQueryService){}

	// 查询条件
	public searchBody:any = {
		page: 1, // 页码
		pageSize: environment.pageSize,
		vcFundCode:"",	//	组合代码
		vcFundName: "", //	组合名称
		vcStockName: "", //	股票名称
		vcStockCode:"",	//	股票代码
		zqStartDate:"",
		zqEnDate:""
	}
	/**
	 * [resetSearch 重置查询条件]
	 */
	resetSearch() {
		this.searchBody = {
			page: 1, // 页码
			pageSize: environment.pageSize,
			vcFundCode:"",	//	组合代码
			vcFundName: "", //	组合名称
			vcStockName: "", //	股票名称
			vcStockCode:"",	//	股票代码
			zqStartDate:"",
			zqEnDate:""
		};
		this.$("#reservation").val("");
	}

	// 分页数据模型
	public pageInfo: PaginationModel = {
		currentPageNum: 1,
		pageSize: 10,
		totalPages: 1,
		total: 0,
		pagesShow: 5,
		startRow: 0,
		endRow: 0,
		pageList: [5, 10, 25, 50, 100]
	};

	// 分页组件
	@ViewChild(AppPaginationComponent)
	public paginationComponent: AppPaginationComponent;
	ngOnInit() {
		this.getLockQueryList();
		
		// 日期控件
		Util.daterangepickerPluginInit("#reservation");
	}

	toggleModal() {
		this.$('#lockTimeModal').modal('toggle');
	}

	submitXj(){
		this.toggleModal();
	}

	selectPage(i:number):void{
		this.pageIndex = i;
	console.log(this.pageIndex)
	}

	/**
	 * [getBankRefList 查询自愿锁列表]
	 */
	getLockQueryList() {
		const $item = Util.$("#reservation");
		const pickerValue = $item.val();
		const daterangepicker = $item.data('daterangepicker');

		// 设置查询条件页码
		this.searchBody.page = this.pageInfo.currentPageNum;
		this.searchBody.pageSize = this.pageInfo.pageSize;
		this.searchBody.zqStartDate = (pickerValue != null && pickerValue.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "";
		this.searchBody.zqEnDate = (pickerValue != null && pickerValue.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "";
		this.lockQueryService.getLockQueryList(this.searchBody).subscribe(result => {
			if (result) {
				this.list = _.pull(result.list, null);

				// 构建分页
				this.pageInfo.totalPages = result.pages;
				this.pageInfo.total = result.total;
				this.pageInfo.startRow = result.startRow;
				this.pageInfo.endRow = result.endRow;
			}
		});
	}

	/**
	 * 根据页码请求查询相关配置列表数据,如果当前活动页码就是目标页码，则不进行任何查询
	 * 直接返回
	 * @param {currentPageNum}
	 */
	public pageNavigation(currentPageNum: number) {
		this.pageInfo.currentPageNum = currentPageNum;
		this.getLockQueryList();
	}

	/**
	 * 改变每页显示记录数
	 * @param {pageSize}
	 */
	public pageSizeChange(pageSize: number) {
		if (pageSize !== this.pageInfo.pageSize) {
		this.pageInfo.pageSize = pageSize;
		this.pageInfo.currentPageNum = 1;
		this.getLockQueryList();
		}
	}
}
