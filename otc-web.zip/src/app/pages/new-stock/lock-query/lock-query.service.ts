import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';
@Injectable()
export class LockQueryService {

  constructor(
  public httpClient: HttpClientService) {
  }

  // 获取自愿锁定期查询列表
  getLockQueryList(param) {
    // let postBody = param;
    let postBody: any = param;
    return this.httpClient.get('otc/v1/trd/wind/allocateddetailByCode', postBody, {
			isAuthHttp: false
		});
  }
}
