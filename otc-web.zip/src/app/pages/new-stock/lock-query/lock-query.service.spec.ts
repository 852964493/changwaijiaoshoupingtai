import { TestBed, inject } from '@angular/core/testing';

import { LockQueryService } from './lock-query.service';

describe('LockQueryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LockQueryService]
    });
  });

  it('should ...', inject([LockQueryService], (service: LockQueryService) => {
    expect(service).toBeTruthy();
  }));
});
