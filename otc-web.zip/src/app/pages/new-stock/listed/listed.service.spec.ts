import { TestBed, inject } from '@angular/core/testing';

import { ListedService } from './listed.service';

describe('ListedService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ListedService]
    });
  });

  it('should ...', inject([ListedService], (service: ListedService) => {
    expect(service).toBeTruthy();
  }));
});
