import {Component,AfterViewInit, OnInit, ViewChild, Inject} from '@angular/core';
import {NgForm} from '@angular/forms';
import {environment} from '../../../../environments/environment';
import {ListedService} from './listed.service';
import {AppPaginationComponent, PaginationModel} from '../../../widgets/pagination/pagination.component';
import {Util} from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-new-stock-listed',
  templateUrl: './listed.component.html',
  styleUrls: ['./listed.component.scss'],
  providers: [ListedService]
})
export class ListedComponent implements OnInit,AfterViewInit {
  // 请求后获取的列表数据
  list: any = [];

  // 模态框列表数据
  modalList: any = [];

  // 数据长度
  voucherListLength: number = 1;

  public $ = window['$'];

  // 查询条件
  public searchBody = {
    // 股票名称
    vcNewstockName: "",
    // 股票代码
    vcNewstockId: "",
    // 上市日期（开始）
    vcListingDateStart: "",
    // 上市日期（结束）
    vcListingDateEnd: "",
    page: 1, // 页码
    pageSize: environment.pageSize
  };

  // 询价表单
  private xjModel = {
    stockId: "1", // 证券代码
    stockName: "2", // 证券名称
    stockExchange: "3", // 交易所
    sponsor: "4", // 保荐人
    issuePrice: "5", // 发行价格
    offVol: "", // 发行数量
    consignor: "" // 委托对象
  };

  // 分页配置
  public pageInfo: PaginationModel = {
    currentPageNum: 1,
    totalPages: 1
  };

  // 分页组件
  @ViewChild(AppPaginationComponent)
  public paginationComponent: AppPaginationComponent;

  constructor(private listedService: ListedService) {

  }  
  
  ngOnInit() {
    // 搜索
    this.search();
  }
  
  ngAfterViewInit(): void {
    //  调用时间插件
    Util.daterangepickerPluginInit(".daterangepicker-plugin");
  }

  resetSearch() {
    this.searchBody = {
      vcNewstockName: "",
      vcNewstockId: "",
      vcListingDateStart: "",
      vcListingDateEnd: "",
      page: this.pageInfo.currentPageNum, // 页码
      pageSize: environment.pageSize
    };
    this.$("#reservation").val("");
  }


  // 发送搜索条件搜索
  search() {
    const param = this.wrapperSearchModule();
    this.listedService.getListed(param).subscribe(result => {
      if (result) {
        this.list = result.list;
      }
    });
  }

  wrapperSearchModule() {
    const $item = Util.$("#reservation");
    const pickerValue = $item.val();
    const daterangepicker = $item.data('daterangepicker');
    const param: any = {
      vcNewstockName: this.searchBody.vcNewstockName,
      vcNewstockId: this.searchBody.vcNewstockId,
      vcListingDateStart: (pickerValue != null && pickerValue.length > 0) ? daterangepicker.startDate.format('YYYYMMDD') : "",
      vcListingDateEnd: (pickerValue != null && pickerValue.length > 0) ? daterangepicker.endDate.format('YYYYMMDD') : "",
      page: this.pageInfo.currentPageNum,
      pageSize: environment.pageSize
    };
    return param;
  }

  /**
   * html中传入的x变量,代表当前行数据
   * @param {any} [item]
   * @memberof ListedComponent
   */
  toggleModal(item?) {
    this.$('#voucherStatusModal').modal('toggle');
    this.$("#reservation").daterangepicker();
    this.modalList = item;
    this.voucherListLength = item.voucherList.length;
  }

  // submitXj(){
  // 	console.log("############submit");
  // 	this.toggleModal();
  // }

  /**
   * 根据页码请求查询相关配置列表数据,如果当前活动页码就是目标页码，则不进行任何查询
   * 直接返回
   * @param {currentPageNum}
   */
  public pageNavigation(currentPageNum: number) {
    this.pageInfo.currentPageNum = currentPageNum;
    this.search();
  }

}
