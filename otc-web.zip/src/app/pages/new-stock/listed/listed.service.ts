import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';
@Injectable()
export class ListedService {

  constructor(public httpClient: HttpClientService) { }


  // 获取新股上市管理列表
  getListed(param) {
    return this.httpClient.get('otc/v1/Newstock/NewstockListed', param, {
      isAuthHttp: false
    });
  }
}
