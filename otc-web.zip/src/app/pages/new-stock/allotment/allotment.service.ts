import { Injectable } from '@angular/core';
import { HttpClientService } from '../../../services/http-client.service';
import { Observable } from "rxjs/Observable";

@Injectable()
export class AllotmentService {

  constructor(public httpClient: HttpClientService) {
  }

  // 复核配售对象
  public checkRation(param) {
    return this.httpClient.put('otc/v1/Newstock/checkRation/?vcRationCode=' + param, null, {
      isAuthHttp: false,
      isReturnOriginal:true
    })
  }

  /**
   * [addAllotmentObj 新增配售对象]
   * @param {[type]} param [{
	 *     vcRationCode:"", // 配售对象编码
	 *     vcRationName:"", // 配售对象名称
	 *     vcFundCode:"", // 所属基金
	 *     vcXiehuiCode:"" // 协会编码
	 * }]
   */
  addAllotmentObj(param) {
    let postBody = [param];
    return this.httpClient.post('otc/v1/trd/newStockAllotment', postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [updateAllotmentObj 更新配售对象]
   * @param {[type]} param [{
	 *     vcRationCode:"", // 配售对象编码
	 *     vcRationName:"", // 配售对象名称
	 *     vcFundCode:"", // 所属基金
	 *     vcXiehuiCode:"" // 协会编码
	 * }]
   */
  updateAllotmentObj(param) {
    let postBody = param;
    return this.httpClient.put('', postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [getAllotmentObjList 根据查询条件，查配售对象列表]
   * @param {[type]} param [{ // 查询条件
	 *     targetname: // 按配售对象名称模糊查询
	 *     targetcode: // 按配售对象查询
	 *     fundCode: // 按所属基金查询
	 *     page: //
	 *     pageSize: //
	 * }]
   */
  getAllotmentObjList(param) {
    let postBody = param;
    return this.httpClient.get('otc/v1/trd/newStockAllotment', postBody, {
      isAuthHttp: false
    });
  }

  /**
   * [deleteAllotmentObj 删除配售对象]
   * @param {[type]} vcRationCode [配售对象编码]
   */
  deleteAllotmentObj(param) {
    const postBody = {
      vcRationCodeList: param
    };
    return this.httpClient.delete('otc/v1/trd/newStockAllotment?vcRationCodeList=' + param, postBody, {
      isAuthHttp: false
    });
  }

  // 获取基金列表
  public getFundInfo(param): Observable<any> {
    return this.httpClient.get('otc/v1/trd/fundinfo', param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

  // 获取万德列表
  public getWindInfo(param): Observable<any> {
    return this.httpClient.get('otc/v1/Newstock/Ration/windOrg', param, {
      isAuthHttp: false,
      isReturnOriginal: true
    });
  }

}
