import { TestBed, inject } from '@angular/core/testing';

import { AllotmentService } from './allotment.service';

describe('AllotmentService', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [AllotmentService]
		});
	});

	it('should ...', inject([AllotmentService], (service: AllotmentService) => {
		expect(service).toBeTruthy();
	}));
});
